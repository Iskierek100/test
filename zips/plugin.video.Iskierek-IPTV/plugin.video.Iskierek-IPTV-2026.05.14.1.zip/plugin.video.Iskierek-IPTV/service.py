# -*- coding: utf-8 -*-
import xbmc
import os
import time
from resources.lib import common,config
from resources.lib.providers import provider_api
from resources.lib.recording import recorder

monitor=xbmc.Monitor()

def update_epg_if_needed():
    try:
        portals=config.get_all_portals()
        if not portals:
            return
        portal=portals[0]
        provider=provider_api.get_provider(portal)

        if not common.read_json_safe(common.epg_raw_file):
            provider.update_epg_database(common.addondir)
            return

        try:
            age=time.time()-os.path.getmtime(common.epg_raw_file)
            if age>43200:
                provider.update_epg_database(common.addondir)
        except:
            provider.update_epg_database(common.addondir)
    except Exception as e:
        xbmc.log(f"[Iskierek IPTV Full] service EPG error: {e}",xbmc.LOGERROR)

def process_scheduled_recordings_if_needed():
    try:
        recorder.process_scheduled_recordings()
    except Exception as e:
        xbmc.log(f"[Iskierek IPTV Full] service REC TIMER error: {e}",xbmc.LOGERROR)

if __name__=='__main__':
    xbmc.sleep(5000)
    tick = 0

    while not monitor.abortRequested():
        if tick % 3600 == 0:
            update_epg_if_needed()

        process_scheduled_recordings_if_needed()

        if monitor.waitForAbort(30):
            break

        tick += 30
