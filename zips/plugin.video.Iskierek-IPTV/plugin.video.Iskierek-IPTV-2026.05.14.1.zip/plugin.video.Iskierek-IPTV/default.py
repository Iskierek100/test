# -*- coding: utf-8 -*-
from resources.lib import main
