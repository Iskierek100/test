# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import urllib.parse
import threading

from resources.lib import common,navigation,actions
from resources.lib.providers import provider_api
from resources.lib.menu import home_menu,provider_menu,settings_menu
from resources.lib.tv import groups as tv_groups,live as tv_live,epg as tv_epg
from resources.lib.vod import movies as vod_movies,series as vod_series
from resources.lib.tools import cache_tools,provider_manager,media_tools,providers_backup,keymap_tools,search
from resources.lib.downloads import exporters,downloader
from resources.lib.recording import recorder
from resources.lib.core import polish_settings
from resources.lib.tv import channel_switch
from resources.lib.tv import channel_overlay
from resources.lib.vod import vod_overlay, vod_switch
from resources.lib.tv import guide as tv_guide
from resources.lib.tv import guide_overlay

portal = common.get_current_portal()
mode = common.args.get('mode', None)

if portal:
    xbmcplugin.setPluginFanart(common.addon_handle, common.fanart)


def get_portal_from_args_or_current():
    current_portal = portal
    portal_arg = common.args.get('portal', [None])[0]
    if portal_arg:
        try:
            current_portal = json.loads(portal_arg)
        except:
            pass
    return current_portal

def recordTVProgram():
    current_portal = get_portal_from_args_or_current()
    recorder.start_recording_tv_program(current_portal)

def recordTVSchedule():
    current_portal = get_portal_from_args_or_current()
    recorder.add_scheduled_recording(current_portal)

def recordTVScheduleDelete():
    cmd = common.args.get('cmd', [''])[0]
    start_ts = common.args.get('start_ts', ['0'])[0]
    stop_ts = common.args.get('stop_ts', ['0'])[0]

    removed = recorder.delete_scheduled_recording_by_data(cmd, start_ts, stop_ts)
    if removed:
        xbmcgui.Dialog().notification(common.addonname, 'Usunięto nagranie z programatora', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification(common.addonname, 'Nie znaleziono wpisu w programatorze', xbmcgui.NOTIFICATION_ERROR)

def get_provider():
    return provider_api.get_provider(portal)

def start_playback_timeout(title, timeout=12):
    def _watch():
        player = xbmc.Player()
        waited = 0

        while waited < timeout * 10:
            xbmc.sleep(100)

            try:
                if player.isPlaying():
                    return
            except:
                return

            waited += 1

        try:
            if not player.isPlaying():
                player.stop()
                xbmcgui.Dialog().notification(
                    common.addonname,
                    f"Nie udało się uruchomić kanału: {title}",
                    xbmcgui.NOTIFICATION_ERROR,
                    4000
                )
        except:
            pass

    import threading
    t = threading.Thread(target=_watch)
    t.daemon = True
    t.start()

def playTV():
    provider = get_provider()

    title = common.args.get('title', ['TV'])[0]
    cmd = common.args.get('cmd', [''])[0]
    logo = common.args.get('logo_url', [''])[0]
    plot_desc = common.args.get('plot', [''])[0]
    program_name = common.args.get('program', [''])[0]
    common.write_json_safe(common.playback_state_file, {'type': 'tv'})

    try:
        idx=common.args.get('channel_index',[''])[0]
        if str(idx).isdigit():
            state=common.read_json_safe(common.channel_state_file)
            channels=state.get('channels',[])
            state_portal=state.get('portal',portal)
            channel_switch.save_channel_state(channels,int(idx),state_portal)
    except:
        pass

    if portal.get('use_f4m', False):
        xbmc.log(f"[Iskierek IPTV Full] Wymuszono f4mTester dla: {title}", xbmc.LOGINFO)
        play_f4m()
        return

    pd = xbmcgui.DialogProgressBG()
    pd.create(common.addonname, "Pobieranie TV...")

    try:
        if portal.get('type') == 'm3u':
            stream_url = cmd
            headers = f"User-Agent={provider.USER_AGENT}"

        elif portal.get('type') == 'xtream':
            stream_url = provider.getLinkTV(portal, cmd)
            headers = f"User-Agent={provider.USER_AGENT}"

        else:
            stream_url = provider.getLinkTV(portal['mac'], portal['url'], portal['serial'], cmd)
            headers = f"User-Agent={provider.USER_AGENT}&Referer={portal['url']}&Cookie=mac={portal['mac']}; stb_lang=en; timezone=Europe%2FWarsaw;"

        pd.close()

    except Exception as e:
        pd.close()
        xbmcgui.Dialog().notification(common.addonname, "Błąd TV: " + str(e), xbmcgui.NOTIFICATION_ERROR)
        li = xbmcgui.ListItem(title)
        xbmcplugin.setResolvedUrl(handle=common.addon_handle, succeeded=False, listitem=li)
        return

    if program_name:
        display_title_osd = f"{title} : [COLOR yellow]{program_name}[/COLOR]"
    else:
        display_title_osd = title

    if portal.get('type') == 'm3u' and str(stream_url).startswith('plugin://'):
        dummy = xbmcgui.ListItem(display_title_osd)
        xbmcplugin.setResolvedUrl(handle=common.addon_handle, succeeded=True, listitem=dummy)
        xbmc.sleep(150)
        xbmc.executebuiltin(f'PlayMedia({stream_url})')
        return

    li = xbmcgui.ListItem(display_title_osd)
    li.setPath(stream_url)
    li.setArt({'icon': logo, 'thumb': logo})
    li.setInfo('video', {
        'Title': display_title_osd,
        'Plot': plot_desc,
        'PlotOutline': program_name,
        'tvshowtitle': program_name,
        'mediatype': 'channel'
    })

    li.setProperty('IsPlayable', 'true')
    li.setContentLookup(False)

    if portal.get('type') == 'm3u':
        pass
    else:
        li.setProperty('inputstream', 'inputstream.ffmpegdirect')
        li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
        li.setProperty('inputstream.ffmpegdirect.stream_headers', headers)
        li.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
        li.setProperty('inputstream.ffmpegdirect.infinite_buffer', 'false')
        li.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')

    xbmcplugin.setResolvedUrl(handle=common.addon_handle, succeeded=True, listitem=li)
    start_playback_timeout(title, timeout=12)


def playTVIndexed():
    idx=common.args.get('channel_index',[''])[0]
    try:
        if str(idx).isdigit():
            state=common.read_json_safe(common.channel_state_file)
            channels=state.get('channels',[])
            state_portal=state.get('portal',portal)
            channel_switch.save_channel_state(channels,int(idx),state_portal)
    except:
        pass
    playTV()

def play_f4m():
    provider = get_provider()

    f4m_id = None
    possible_ids = ["plugin.video.f4mTester", "plugin.video.f4mtester", "plugin.video.shani"]

    for aid in possible_ids:
        if xbmc.getCondVisibility(f'System.HasAddon("{aid}")'):
            f4m_id = aid
            break
        try:
            xbmcaddon.Addon(id=aid)
            f4m_id = aid
            break
        except:
            pass

    if not f4m_id:
        xbmcgui.Dialog().notification(common.addonname, "Brak wtyczki f4mTester! Zainstaluj ją.", xbmcgui.NOTIFICATION_ERROR)
        return

    title = common.args.get('title', ['TV'])[0]
    cmd = common.args.get('cmd', [''])[0]
    logo = common.args.get('logo_url', [''])[0]

    try:
        if portal.get('type') == 'xtream':
            stream_url = provider.getLinkTV(portal, cmd)
        else:
            stream_url = provider.getLinkTV(portal['mac'], portal['url'], portal['serial'], cmd)
    except Exception as e:
        xbmcgui.Dialog().notification(common.addonname, "Błąd f4mTester: " + str(e), xbmcgui.NOTIFICATION_ERROR)
        return

    if ".ts" in stream_url:
        stream_url = stream_url.replace(".ts", ".m3u8")
    elif ".mp4" in stream_url:
        stream_url = stream_url.replace(".mp4", ".m3u8")
    elif ".mkv" in stream_url:
        stream_url = stream_url.replace(".mkv", ".m3u8")
    elif not stream_url.endswith(".m3u8"):
        if "?" in stream_url:
            stream_url = stream_url.replace("?", ".m3u8?")
        else:
            stream_url = stream_url + ".m3u8"

    default_ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36"
    stream_url_with_headers = stream_url + "|User-Agent=" + urllib.parse.quote(default_ua)

    u_url = urllib.parse.quote_plus(stream_url_with_headers)
    u_name = urllib.parse.quote_plus(title)
    u_icon = urllib.parse.quote_plus(logo)

    def close_error_dialogs(delay=5.0, interval=0.2):
        import time
        loops = int(delay / interval)
        for _ in range(loops):
            time.sleep(interval)
            xbmc.executebuiltin("Dialog.Close(error,true)")
            xbmc.executebuiltin("Dialog.Close(ok,true)")

    t = threading.Thread(target=close_error_dialogs, args=(5.0, 0.2))
    t.daemon = True
    t.start()

    dummy_item = xbmcgui.ListItem(label="Start f4mTester...")
    dummy_item.setPath(common.icon0)
    dummy_item.setContentLookup(False)
    dummy_item.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(handle=common.addon_handle, succeeded=True, listitem=dummy_item)

    f4m_path = f"plugin://{f4m_id}/?streamtype=HLSRETRY&name={u_name}&iconImage={u_icon}&url={u_url}"
    xbmc.log(f"[Iskierek IPTV Full] Uruchamiam f4mTester ({f4m_id}): {f4m_path}", xbmc.LOGINFO)
    xbmc.sleep(300)
    xbmc.executebuiltin(f"RunPlugin({f4m_path})")


def playVoD():
    provider = get_provider()

    title = common.args.get('title', ['Film'])[0]
    cmd = common.args.get('cmd', [''])[0]
    logo = common.args.get('logo_url', [''])[0]
    ext = common.args.get('ext', ['mp4'])[0]
    common.write_json_safe(common.playback_state_file, {'type': 'vod'})

    current_portal = portal
    portal_arg = common.args.get('portal', [None])[0]
    if portal_arg:
        try:
            current_portal = json.loads(portal_arg)
        except:
            pass

    pd = xbmcgui.DialogProgressBG()
    pd.create(common.addonname, "Pobieranie Filmu...")

    try:
        if current_portal.get('type') == 'xtream':
            stream_url = provider.getLinkVoD(current_portal, cmd, ext)
            final_url = stream_url + "|User-Agent=vlc&verifypeer=false"
        else:
            stream_url = provider.getLinkVoD(current_portal['mac'], current_portal['url'], current_portal['serial'], cmd)
            final_url = stream_url
        pd.close()
    except Exception as e:
        pd.close()
        xbmcgui.Dialog().notification(common.addonname, "Błąd VOD: " + str(e), xbmcgui.NOTIFICATION_ERROR)
        li = xbmcgui.ListItem(title)
        xbmcplugin.setResolvedUrl(handle=common.addon_handle, succeeded=False, listitem=li)
        return

    li = xbmcgui.ListItem(title)
    li.setPath(final_url)
    li.setArt({'icon': logo, 'thumb': logo})
    li.setInfo('video', {'Title': title})
    li.setProperty('IsPlayable', 'true')
    li.setContentLookup(False)

    if current_portal.get('type') == 'stalker':
        headers = f"User-Agent={provider.USER_AGENT}&Referer={current_portal['url']}&Cookie=mac={current_portal['mac']}; stb_lang=en; timezone=Europe%2FWarsaw;"
        li.setProperty('inputstream', 'inputstream.ffmpegdirect')
        li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'false')
        li.setProperty('inputstream.ffmpegdirect.stream_headers', headers)
        li.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')
        li.setProperty('ResumeTime', '1')
        li.setProperty('TotalTime', '1')

    xbmcplugin.setResolvedUrl(handle=common.addon_handle, succeeded=True, listitem=li)

def playVoDIndexed():
    idx=common.args.get('vod_index',[''])[0]
    try:
        if str(idx).isdigit():
            state=common.read_json_safe(common.vod_state_file)
            items=state.get('items',[])
            state_portal=state.get('portal',portal)
            content_type=state.get('content_type','vod')
            vod_switch.save_vod_state(items,int(idx),state_portal,content_type)
    except:
        pass
    playVoD()

def playSeriesIndexed():
    idx=common.args.get('vod_index',[''])[0]
    try:
        if str(idx).isdigit():
            state=common.read_json_safe(common.vod_state_file)
            items=state.get('items',[])
            state_portal=state.get('portal',portal)
            content_type=state.get('content_type','series')
            vod_switch.save_vod_state(items,int(idx),state_portal,content_type)
    except:
        pass
    playSeries()

def open_any_overlay():
    playback_state = common.read_json_safe(common.playback_state_file)
    ptype = playback_state.get('type', '')

    if ptype == 'tv':
        channel_overlay.open_overlay()
        return

    if ptype in ['vod', 'series']:
        vod_overlay.open_overlay()
        return

    tv_state = common.read_json_safe(common.channel_state_file)
    vod_state = common.read_json_safe(common.vod_state_file)

    if vod_state.get('items'):
        vod_overlay.open_overlay()
        return
    if tv_state.get('channels'):
        channel_overlay.open_overlay()
        return

    xbmcgui.Dialog().notification(common.addonname, 'Brak zapisanej listy do overlay', xbmcgui.NOTIFICATION_ERROR)

def playSeries():
    provider = get_provider()

    title = common.args.get('title', ['Serial'])[0]
    cmd = common.args.get('cmd', [''])[0]
    episode = common.args.get('episode', ['1'])[0]
    logo = common.args.get('logo_url', [''])[0]
    ext = common.args.get('ext', ['mp4'])[0]
    common.write_json_safe(common.playback_state_file, {'type': 'series'})

    current_portal = portal
    portal_arg = common.args.get('portal', [None])[0]
    if portal_arg:
        try:
            current_portal = json.loads(portal_arg)
        except:
            pass

    pd = xbmcgui.DialogProgressBG()
    pd.create(common.addonname, f"Pobieranie Odc. {episode}...")

    try:
        if current_portal.get('type') == 'xtream':
            stream_url = provider.getLinkSeries(current_portal, cmd, ext)
            final_url = stream_url + "|User-Agent=vlc&verifypeer=false"
        else:
            stream_url = provider.getLinkSeries(current_portal['mac'], current_portal['url'], current_portal['serial'], cmd, episode)
            final_url = stream_url
        pd.close()
    except Exception as e:
        pd.close()
        xbmcgui.Dialog().notification(common.addonname, "Błąd Serialu: " + str(e), xbmcgui.NOTIFICATION_ERROR)
        li = xbmcgui.ListItem(title)
        xbmcplugin.setResolvedUrl(handle=common.addon_handle, succeeded=False, listitem=li)
        return

    li = xbmcgui.ListItem(title)
    li.setPath(final_url)
    li.setArt({'icon': logo, 'thumb': logo})
    li.setInfo('video', {'Title': title})
    li.setProperty('IsPlayable', 'true')
    li.setContentLookup(False)

    if current_portal.get('type') == 'stalker':
        headers = f"User-Agent={provider.USER_AGENT}&Referer={current_portal['url']}&Cookie=mac={current_portal['mac']}; stb_lang=en; timezone=Europe%2FWarsaw;"
        li.setProperty('inputstream', 'inputstream.ffmpegdirect')
        li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'false')
        li.setProperty('inputstream.ffmpegdirect.stream_headers', headers)
        li.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')
        li.setProperty('ResumeTime', '1')
        li.setProperty('TotalTime', '1')

    xbmcplugin.setResolvedUrl(handle=common.addon_handle, succeeded=True, listitem=li)


if mode is None:
    home_menu.homeLevel()

else:
    mode_key = mode[0]

    routes={
        'sel':lambda:provider_menu.SelectLevel(portal),
        'cache':cache_tools.ClearLevel,
        'refresh_list':lambda:xbmc.executebuiltin('Container.Refresh'),

        'channels':lambda:tv_live.channelLevel(portal),
        'play_tv':playTV,
        'polish_groups_menu':lambda:tv_groups.PolishGroupsLevel(portal),
        'my_groups_view':lambda:actions.MyGroupsLevel(portal),
        'manage_groups_menu':lambda:actions.ManageGroupsMenu(portal),
        'open_group_select':lambda:actions.OpenGroupSelectDialog(portal),
        'manage_groups_list':lambda:actions.OpenGroupSelectDialog(portal),
        'toggle_group':lambda:actions.OpenGroupSelectDialog(portal),
        'rename_channel':lambda:actions.renameChannel(portal),
        'hide_channel':lambda:actions.hideChannel(portal),
        'hidden_manager':lambda:actions.HiddenManagerLevel(portal),
        'restore_channel':lambda:actions.restoreChannel(portal),
        'account_info':lambda:tv_epg.AccountInfoLevel(portal),
        'show_epg':tv_epg.ShowEPG,

        'vodgen':lambda:vod_movies.vodgenreLevel(portal),
        'vod':lambda:vod_movies.vodLevel(portal),
        'play_vod':playVoD,
        'sergen':lambda:vod_series.SeriesGenre(portal),
        'seriescat':lambda:vod_series.SeriesLevel(portal),
        'season':lambda:vod_series.SeasonLevel(portal),
        'episode':lambda:vod_series.EpisodeLevel(portal),
        'play_series':playSeries,

        'edit_pl_supergroup':lambda:actions.OpenPolishGroupSelectDialog(portal),
        'unlock_adult':lambda:navigation.unlock_adult(portal) and xbmc.executebuiltin('Container.Refresh'),
        'lock_adult':lambda:(navigation.lock_adult(portal),xbmc.executebuiltin('Container.Refresh')),

        'providers_manager':provider_manager.ProvidersManagerLevel,
        'provider_add':provider_manager.AddProvider,
        'provider_edit_menu':provider_manager.ProviderEditMenu,
        'provider_toggle_enabled':provider_manager.ToggleProviderEnabled,
        'provider_edit_name':provider_manager.EditProviderName,
        'provider_edit_url':provider_manager.EditProviderUrl,
        'provider_edit_mac':provider_manager.EditProviderMac,
        'provider_edit_username':provider_manager.EditProviderUsername,
        'provider_edit_password':provider_manager.EditProviderPassword,
        'provider_edit_f4m':provider_manager.EditProviderF4M,
        'provider_edit_serial':provider_manager.EditProviderSerial,
        'provider_edit_m3u_path':provider_manager.EditProviderM3UPath,
        'provider_edit_m3u_source_type':provider_manager.EditProviderM3USourceType,
        'provider_delete':provider_manager.DeleteProvider,
        'providers_export':providers_backup.export_providers,
        'providers_import':providers_backup.import_providers,
        'providers_sorting_export':providers_backup.export_sorting,
        'providers_sorting_import':providers_backup.import_sorting,
        'export_polish_m3u':lambda:exporters.export_polish_m3u(portal),
        'export_group_m3u':lambda:exporters.export_group_m3u(portal),
        'download_vod':lambda:downloader.download_vod(portal),
        'download_series':lambda:downloader.download_series(portal),
        'record_tv_start':lambda:recorder.start_recording_tv(portal),
        'record_tv_stop':recorder.stop_recording_tv,
        'recording_info':recorder.show_recording_info,
        'media_manager':media_tools.MediaManagerLevel,
        'play_local_file':media_tools.PlayLocalFile,
        'delete_local_file':media_tools.DeleteLocalFile,
        'provider_settings':lambda:settings_menu.ProviderSettingsLevel(portal),
        'provider_settings_provider':lambda:settings_menu.ProviderEditSettingsLevel(portal),
        'provider_settings_groups':lambda:settings_menu.GroupsSettingsLevel(portal),
        'provider_settings_recording':lambda:settings_menu.RecordingSettingsLevel(portal),
        'provider_settings_tools':lambda:settings_menu.ToolsSettingsLevel(portal),
        'polish_settings':polish_settings.PolishSettingsLevel,
        'polish_settings_export':polish_settings.export_settings,
        'polish_settings_import':polish_settings.import_settings,
        'polish_settings_reset':polish_settings.reset_settings,
        'polish_settings_prefixes':polish_settings.PrefixesLevel,
        'polish_settings_suffixes':polish_settings.SuffixesLevel,
        'polish_settings_fixes':polish_settings.FixesLevel,
        'polish_settings_prefix_add':polish_settings.AddPrefix,
        'polish_settings_prefix_del':polish_settings.DeletePrefix,
        'polish_settings_suffix_add':polish_settings.AddSuffix,
        'polish_settings_suffix_del':polish_settings.DeleteSuffix,
        'polish_settings_fix_add':polish_settings.AddFix,
        'polish_settings_fix_del':polish_settings.DeleteFix,
        'play_next_channel':channel_switch.play_next_channel,
        'play_prev_channel':channel_switch.play_prev_channel,
        'install_keymap':keymap_tools.install_keymap,
        'remove_keymap':keymap_tools.remove_keymap,
        'play_tv_indexed':playTVIndexed,
        'open_channel_overlay':open_any_overlay,
        'play_vod_indexed':playVoDIndexed,
        'play_series_indexed':playSeriesIndexed,
        'open_vod_overlay':vod_overlay.open_overlay,
        'play_next_vod':vod_switch.play_next,
        'play_prev_vod':vod_switch.play_prev,
        'polish_settings_group_keywords':polish_settings.GroupKeywordsLevel,
        'polish_settings_group_keyword_add':polish_settings.AddGroupKeyword,
        'polish_settings_group_keyword_del':polish_settings.DeleteGroupKeyword,
        'global_search':search.GlobalSearchMenu,
        'global_search_results':search.GlobalSearchResults,
        'parental_change_pin':navigation.change_parental_pin,
        'parental_manager':provider_manager.ParentalManagerLevel,
        'parental_toggle_global':provider_manager.ToggleGlobalParental,
        'tv_guide':tv_guide.open_guide,
        'record_tv_program':recordTVProgram,
        'record_tv_schedule':recordTVSchedule,
        'record_schedule_manager':recorder.ScheduledRecordingsLevel,
        'record_schedule_delete':recorder.DeleteScheduledRecording,
        'record_tv_schedule_delete':recordTVScheduleDelete,
    }

    action = routes.get(mode_key)
    if action:
        action()
    else:
        xbmcgui.Dialog().notification(common.addonname, f'Nieznany tryb: {mode_key}', xbmcgui.NOTIFICATION_ERROR)
