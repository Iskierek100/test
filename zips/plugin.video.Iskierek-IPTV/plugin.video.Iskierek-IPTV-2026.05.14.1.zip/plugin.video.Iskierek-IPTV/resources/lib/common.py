# -*- coding: utf-8 -*-
import sys
import os
import json
import urllib.parse
import xbmc
import xbmcaddon
import xbmcvfs
import unicodedata
import re
import hashlib
from resources.lib import config

try:
    base_url = sys.argv[0]
    addon_handle = int(sys.argv[1])
    args = urllib.parse.parse_qs(sys.argv[2][1:])
except:
    base_url = ""
    addon_handle = -1
    args = {}

addon = xbmcaddon.Addon('plugin.video.Iskierek-IPTV')
addonname = addon.getAddonInfo('name')
addondir = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
addon_path = xbmcvfs.translatePath(addon.getAddonInfo('path'))

cachedir = os.path.join(addondir, 'cache')
epgdir = os.path.join(addondir, 'epg')

recording_state_file = os.path.join(addondir, 'recording_state.json')
selected_groups_file = os.path.join(addondir, 'selected_groups.json')
hidden_channels_file = os.path.join(addondir, 'hidden_channels.json')
custom_names_file = os.path.join(addondir, 'custom_names.json')
user_sorting_file = os.path.join(addondir, 'user_sorting.json')
epg_raw_file = os.path.join(epgdir, 'epg_raw.json')
providers_file = os.path.join(addondir, 'providers.json')
channel_state_file=os.path.join(addondir,'channel_state.json')
vod_state_file = os.path.join(addondir, 'vod_state.json')
playback_state_file = os.path.join(addondir, 'playback_state.json')
search_history_file = os.path.join(addondir, 'search_history.json')
parental_file = os.path.join(addondir, 'parental_config.json')
scheduled_recordings_file = os.path.join(addondir, 'scheduled_recordings.json')

fanart = os.path.join(addon_path, 'fanart.jpg')
if not os.path.exists(fanart):
    fanart = os.path.join(addon_path, 'fanart.png')

icon0 = os.path.join(addon_path, 'icon.png')
icon_reset = icon0
icon_info = icon0
icon1 = icon0
icon2 = icon0
icon3 = icon0
icon4 = icon0
icon11 = icon0


def check_folders():
    if not os.path.exists(addondir):
        try:
            os.makedirs(addondir)
        except:
            pass

    if not os.path.exists(cachedir):
        try:
            os.makedirs(cachedir)
        except:
            pass

    if not os.path.exists(epgdir):
        try:
            os.makedirs(epgdir)
        except:
            pass


def read_json_safe(path):
    if not os.path.exists(path):
        return {}
    try:
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            return json.load(f)
    except:
        return {}


def write_json_safe(path, data):
    check_folders()
    try:
        with open(path, 'w', encoding='utf-8', errors='ignore') as f:
            json.dump(data, f, indent=4, ensure_ascii=True)
    except:
        pass


def build_url(query):
    clean_query = {k: (str(v) if v is not None else "") for k, v in query.items()}
    return base_url + '?' + urllib.parse.urlencode(clean_query)


def get_current_portal():
    portal_arg = args.get('portal', None)
    if portal_arg:
        try:
            return json.loads(portal_arg[0])
        except:
            return None
    else:
        try:
            return config.portalConfig('1')
        except:
            return None


def get_portal_key(p_data):
    if not p_data:
        return "default"

    try:
        ptype = str(p_data.get('type', '')).lower()

        if ptype == 'xtream':
            parsed = urllib.parse.urlparse(p_data.get('url', ''))
            clean_url = parsed.netloc + parsed.path
            username = p_data.get('username', '')
            return f"{clean_url}@{username}"

        parsed = urllib.parse.urlparse(p_data.get('url', ''))
        clean_url = parsed.netloc + parsed.path
        mac = p_data.get('mac', '')
        return f"{clean_url}@{mac}"

    except:
        return "unknown_portal"


def clean_bad_chars(text):
    if not text:
        return ""
    text = str(text)
    return "".join(ch for ch in text if unicodedata.category(ch)[0] != "C").replace('"', "'").strip()


def clean_channel_name(name):
    if not name:
        return ""

    name = name.lower()
    replacements = [
        ("ą", "a"), ("ć", "c"), ("ę", "e"), ("ł", "l"),
        ("ń", "n"), ("ó", "o"), ("ś", "s"), ("ź", "z"),
        ("ż", "z"), ("é", "e"), ("è", "e")
    ]
    for old, new in replacements:
        name = name.replace(old, new)

    name = name.replace("+", "plus")

    junk = [
        "pl -", "pl-", "pl:", "pl :", "pl ",
        "uk -", "uk-", "uk:", "uk :", "uk ",
        "de -", "de-", "de:", "de :", "de ",
        "(pl)", "[pl]", "|pl|",
        "fhd", "uhd", "4k", "vip", "hevc",
        "h.265", "h265", "raw", "premium",
        "backup", "zapas", "(na)", "[na]",
        " hd", " sd"
    ]

    for j in junk:
        name = name.replace(j, "")

    name = re.sub(r'[^a-z0-9]', '', name)

    if name.startswith("pl") and len(name) > 2:
        name = name[2:]

    return name


def read_providers():
    data = read_json_safe(providers_file)
    if isinstance(data, list):
        return data
    return []


def write_providers(data):
    if not isinstance(data, list):
        data = []
    write_json_safe(providers_file, data)


def generate_provider_id():
    import uuid
    return str(uuid.uuid4())


def get_provider_by_id(provider_id):
    providers = read_providers()
    for p in providers:
        if p.get('id') == provider_id:
            return p
    return None

def _hash_pin(pin):
    import hashlib
    return hashlib.sha256(str(pin).encode('utf-8')).hexdigest()

def get_parental_config():
    data = read_json_safe(parental_file)
    if not isinstance(data, dict):
        return {'enabled': False}
    if 'enabled' not in data:
        data['enabled'] = False
    return data

def save_parental_config(data):
    if not isinstance(data, dict):
        data = {'enabled': False}
    if 'enabled' not in data:
        data['enabled'] = False
    write_json_safe(parental_file, data)

def is_parental_enabled():
    cfg = get_parental_config()
    return bool(cfg.get('enabled', False))

def set_parental_enabled(enabled):
    cfg = get_parental_config()
    cfg['enabled'] = bool(enabled)
    save_parental_config(cfg)

def has_parental_pin():
    cfg = get_parental_config()
    return bool(cfg.get('pin_hash'))

def verify_parental_pin(pin):
    cfg = get_parental_config()
    saved_hash = cfg.get('pin_hash', '')
    if not saved_hash:
        return False
    return _hash_pin(str(pin).strip()) == saved_hash

def set_parental_pin(pin):
    cfg = get_parental_config()
    cfg['pin_hash'] = _hash_pin(str(pin).strip())
    save_parental_config(cfg)