# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import json
import time
from resources.lib import common
from resources.lib.tv import channel_switch
from resources.lib.recording import recorder


class ProgramInfoDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__()
        self.channel = kwargs.get('channel', {})
        self.portal = kwargs.get('portal', {})
        self.channel_index = kwargs.get('channel_index', -1)

    def _is_future_program(self):
        try:
            start_ts = int(float(self.channel.get('start_ts', 0)))
            return start_ts > int(time.time())
        except:
            return False

    def _has_timer(self):
        return recorder.has_scheduled_recording(
            self.channel.get('cmd', ''),
            self.channel.get('start_ts', 0),
            self.channel.get('stop_ts', 0)
        )

    def onInit(self):
        title = self.channel.get('title', 'Kanał')
        program_now = self.channel.get('program_now', '')
        program_now_time = self.channel.get('program_now_time', '')
        program_next = self.channel.get('program_next', '')
        program_next_time = self.channel.get('program_next_time', '')
        plot = self.channel.get('plot', 'Brak opisu.')
        logo = self.channel.get('logo_url', '')

        try:
            self.getControl(10).setLabel(title)
        except:
            pass

        try:
            now_label = f"{program_now_time}  {program_now}".strip()
            self.getControl(11).setLabel(now_label if now_label else 'Brak danych programu')
        except:
            pass

        try:
            next_label = f"{program_next_time}  {program_next}".strip()
            self.getControl(12).setLabel(next_label if next_label else 'Brak danych o następnym programie')
        except:
            pass

        try:
            self.getControl(13).setText(plot or 'Brak opisu.')
        except:
            pass

        try:
            self.getControl(14).setImage(logo)
        except:
            pass

        try:
            if self._is_future_program():
                if self._has_timer():
                    self.getControl(22).setLabel('Usuń nagranie')
                else:
                    self.getControl(22).setLabel('Ustaw nagranie')
            else:
                self.getControl(22).setLabel('Nagraj do końca programu')
        except:
            pass

    def onAction(self, action):
        aid = action.getId()
        if aid in [9, 10, 13, 92]:
            self.close()
            return

    def onClick(self, controlId):
        if controlId == 21:
            if self.channel_index >= 0:
                channel_switch.save_channel_state(
                    common.read_json_safe(common.channel_state_file).get('channels', []),
                    self.channel_index,
                    self.portal
                )
                channel_switch.play_index(self.channel_index)
            self.close()

        elif controlId == 22:
            cmd = self.channel.get('cmd', '')
            title = self.channel.get('title', 'Kanał')
            logo = self.channel.get('logo_url', '')
            start_ts = self.channel.get('start_ts', 0)
            stop_ts = self.channel.get('stop_ts', 0)

            if self._is_future_program():
                if self._has_timer():
                    xbmc.executebuiltin(
                        f'RunPlugin({common.build_url({"mode":"record_tv_schedule_delete","cmd":cmd,"start_ts":start_ts,"stop_ts":stop_ts})})'
                    )
                    xbmcgui.Dialog().notification(common.addonname, 'Usunięto nagranie z programatora', xbmcgui.NOTIFICATION_INFO)
                else:
                    xbmc.executebuiltin(
                        f'RunPlugin({common.build_url({"mode":"record_tv_schedule","cmd":cmd,"title":title,"logo_url":logo,"portal":json.dumps(self.portal),"start_ts":start_ts,"stop_ts":stop_ts})})'
                    )
                    xbmcgui.Dialog().notification(common.addonname, 'Ustawiono nagranie programu', xbmcgui.NOTIFICATION_INFO)
            else:
                xbmc.executebuiltin(
                    f'RunPlugin({common.build_url({"mode":"record_tv_program","cmd":cmd,"title":title,"logo_url":logo,"portal":json.dumps(self.portal),"start_ts":start_ts,"stop_ts":stop_ts})})'
                )
                xbmcgui.Dialog().notification(common.addonname, 'Wysłano polecenie nagrywania programu', xbmcgui.NOTIFICATION_INFO)

            self.close()

        elif controlId == 23:
            xbmc.executebuiltin(
                f'RunPlugin({common.build_url({"mode":"recording_info","portal":json.dumps(self.portal)})})'
            )

        elif controlId == 24:
            self.close()


def open_program_info(channel, portal, channel_index):
    win = ProgramInfoDialog(
        'program_info.xml',
        common.addon_path,
        'default',
        '1080i',
        channel=channel,
        portal=portal,
        channel_index=channel_index
    )
    win.doModal()
    del win