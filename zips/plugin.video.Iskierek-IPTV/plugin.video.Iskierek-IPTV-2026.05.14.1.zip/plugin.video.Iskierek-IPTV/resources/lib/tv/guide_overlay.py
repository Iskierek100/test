# -*- coding: utf-8 -*-
import json
import time
from datetime import datetime

import xbmc
import xbmcgui

from resources.lib import common
from resources.lib.recording import recorder


ACTION_MOVE_LEFT = 1
ACTION_MOVE_RIGHT = 2
ACTION_MOVE_UP = 3
ACTION_MOVE_DOWN = 4
ACTION_PAGE_UP = 5
ACTION_PAGE_DOWN = 6
ACTION_SELECT_ITEM = 7
ACTION_PARENT_DIR = 9
ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92
ACTION_MOUSE_LEFT_CLICK = 100
ACTION_MOUSE_DOUBLE_CLICK = 103
ACTION_CONTEXT_MENU = 117
ACTION_ENTER = 135
ACTION_SELECT = 136


class GuideOverlayWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__()
        self.portal = kwargs.get('portal', {})
        self.overlay_mode = kwargs.get('overlay_mode', 'recording_info')
        self.items = []
        self.list_ctrl = None
        self._block_activate_until = 0.0
        self._closing = False

    def onInit(self):
        try:
            self.list_ctrl = self.getControl(100)
        except Exception:
            self.list_ctrl = None

        self._render()

        if self.list_ctrl and self.items:
            try:
                self.setFocusId(100)
            except Exception:
                pass
        else:
            try:
                self.setFocusId(900)
            except Exception:
                pass

        self._block_clicks(0.45)

    def _block_clicks(self, seconds=0.35):
        self._block_activate_until = time.time() + float(seconds)

    def _can_activate(self):
        return time.time() >= self._block_activate_until and not self._closing

    def _set_label(self, cid, text):
        try:
            self.getControl(cid).setLabel(text)
        except Exception:
            pass

    def _safe_close(self):
        self._closing = True
        self._block_clicks(999.0)

        try:
            if self.list_ctrl:
                self.list_ctrl.setVisible(False)
        except Exception:
            pass

        xbmc.sleep(120)
        self.close()

    def _refresh_guide(self):
        """
        Nie otwieramy guide bezpośrednio z overlay,
        tylko prosimy aktualny guide, żeby zamknął się i otworzył ponownie.
        Dzięki temu nie robi się guide na guide.
        """
        try:
            xbmcgui.Window(10000).setProperty('IskierekGuideReopen', '1')
        except Exception:
            pass

        self._safe_close()

    def _focus_list(self):
        try:
            self.setFocusId(100)
            return True
        except Exception:
            return False

    def _focus_back(self):
        try:
            self.setFocusId(900)
            return True
        except Exception:
            return False

    def _render(self):
        if self.overlay_mode == 'recording_info':
            self._render_recording_info()
        elif self.overlay_mode == 'schedule_manager':
            self._render_schedule_manager()
        elif self.overlay_mode == 'provider_settings':
            self._render_provider_settings()

        if self.overlay_mode == 'provider_settings':
            self._set_label(900, 'Odśwież')
        else:
            self._set_label(900, 'Powrót')

    def _render_recording_info(self):
        self._set_label(10, 'Info o nagrywaniu')
        self.items = []

        state = recorder._load_recording_state()
        if not state.get('active'):
            self.items.append({
                'label': '[COLOR grey]Brak aktywnego nagrywania[/COLOR]',
                'action': None
            })
        else:
            title = state.get('title', '')
            backend = state.get('backend', '').upper()
            started = state.get('started', '')
            mode_label = state.get('mode_label', '')
            file_path = state.get('file', '')
            stop_at = state.get('stop_at', 0)

            self.items.append({
                'label': f'[B]Nagrywanie:[/B] [COLOR orange]ON ({backend})[/COLOR]',
                'action': None
            })

            if title:
                self.items.append({'label': f'[B]Kanał:[/B] {title}', 'action': None})
            if started:
                self.items.append({'label': f'[B]Start:[/B] {started}', 'action': None})
            if mode_label:
                self.items.append({'label': f'[B]Tryb:[/B] {mode_label}', 'action': None})
            if stop_at:
                try:
                    stop_txt = datetime.fromtimestamp(int(stop_at)).strftime('%d.%m.%Y %H:%M:%S')
                    self.items.append({'label': f'[B]Koniec:[/B] {stop_txt}', 'action': None})
                except Exception:
                    pass
            if file_path:
                self.items.append({'label': f'[B]Plik:[/B] {file_path}', 'action': None})

            self.items.append({
                'label': '[COLOR red][B]Stop nagrywania[/B][/COLOR]',
                'action': 'record_tv_stop'
            })

        self._fill_list()

    def _render_schedule_manager(self):
        self._set_label(10, 'Programator nagrań')
        self.items = []

        timers = recorder._load_scheduled_recordings()
        if not timers:
            self.items.append({
                'label': '[COLOR grey]Brak zaplanowanych nagrań[/COLOR]',
                'action': None
            })
        else:
            status_colors = {
                'scheduled': 'yellow',
                'started': 'orange',
                'done': 'lime',
                'expired': 'grey'
            }

            status_labels = {
                'scheduled': 'ZAPLANOWANE',
                'started': 'URUCHOMIONE',
                'done': 'ZAKOŃCZONE',
                'expired': 'WYGASŁE'
            }

            timers.sort(key=lambda x: x.get('start_ts', 0))

            for item in timers:
                title = item.get('title', 'Kanał TV')
                status = item.get('status', 'scheduled')
                color = status_colors.get(status, 'white')
                status_text = status_labels.get(status, status.upper())

                start_ts = int(item.get('start_ts', 0) or 0)
                stop_ts = int(item.get('stop_ts', 0) or 0)

                start_txt = datetime.fromtimestamp(start_ts).strftime('%d.%m %H:%M') if start_ts else '?'
                stop_txt = datetime.fromtimestamp(stop_ts).strftime('%d.%m %H:%M') if stop_ts else '?'

                rid = item.get('id', '')

                self.items.append({
                    'label': f'[B]{title}[/B]  [COLOR {color}]{status_text}[/COLOR]  {start_txt} - {stop_txt}',
                    'action': None
                })

                if rid:
                    self.items.append({
                        'label': '    [COLOR red]Usuń z programatora[/COLOR]',
                        'action': 'record_schedule_delete',
                        'record_id': rid
                    })

        self._fill_list()

    def _render_provider_settings(self):
        self._set_label(10, 'Ustawienia')
        self.items = [
            {
                'label': '[B]Edytuj Wszystkie Polskie[/B]',
                'action': 'run_plugin',
                'mode': 'edit_pl_supergroup'
            },
            {
                'label': '[B]Zarządzaj grupami TV[/B]',
                'action': 'run_plugin',
                'mode': 'open_group_select',
                'extra': {'g_type': 'tv'}
            },
            {
                'label': '[B]Zarządzaj grupami VOD[/B]',
                'action': 'run_plugin',
                'mode': 'open_group_select',
                'extra': {'g_type': 'vod'}
            },
            {
                'label': '[B]Zarządzaj grupami Seriali[/B]',
                'action': 'run_plugin',
                'mode': 'open_group_select',
                'extra': {'g_type': 'ser'}
            },
            {
                'label': '[B][COLOR red]Skasuj cache[/COLOR][/B]',
                'action': 'run_plugin',
                'mode': 'cache'
            },
        ]
        self._fill_list()

    def _fill_list(self):
        if not self.list_ctrl:
            return

        self.list_ctrl.reset()
        listitems = []

        for item in self.items:
            li = xbmcgui.ListItem(item.get('label', ''))
            li.setProperty('overlay_action', item.get('action') or '')
            li.setProperty('record_id', item.get('record_id', ''))
            li.setProperty('mode', item.get('mode', ''))
            listitems.append(li)

        if listitems:
            self.list_ctrl.addItems(listitems)
            try:
                self.list_ctrl.selectItem(0)
            except Exception:
                pass

    def _delete_schedule_by_id(self, record_id):
        if not record_id:
            return False

        try:
            timers = recorder._load_scheduled_recordings()
            if not isinstance(timers, list):
                timers = []

            before = len(timers)
            new_timers = []

            for t in timers:
                if str(t.get('id', '')) != str(record_id):
                    new_timers.append(t)

            if len(new_timers) == before:
                return False

            recorder._save_scheduled_recordings(new_timers)
            xbmc.sleep(100)

            refreshed = recorder._load_scheduled_recordings()
            xbmc.log(
                f'[GuideOverlay] deleted schedule id={record_id}, before={before}, after={len(refreshed)}',
                xbmc.LOGINFO
            )
            return True

        except Exception as e:
            xbmc.log(f'[GuideOverlay] delete schedule error: {e}', xbmc.LOGERROR)
            return False

    def _activate_selected(self):
        if not self._can_activate():
            return

        if not self.list_ctrl:
            return

        pos = self.list_ctrl.getSelectedPosition()
        if pos < 0 or pos >= len(self.items):
            return

        item = self.items[pos]
        action = item.get('action')

        if not action:
            return

        self._block_clicks(0.45)

        if action == 'record_tv_stop':
            xbmc.executebuiltin(
                f'RunPlugin({common.build_url({"mode": "record_tv_stop"})})'
            )
            xbmc.sleep(250)
            self._render()
            self._focus_list()
            return

        if action == 'record_schedule_delete':
            record_id = item.get('record_id', '')
            if record_id:
                removed = self._delete_schedule_by_id(record_id)
                if removed:
                    xbmc.sleep(100)
                    self._render_schedule_manager()
                    self._block_clicks(0.30)
                    self._focus_list()
            return

        if action == 'run_plugin':
            params = {
                'mode': item.get('mode', ''),
                'portal': json.dumps(self.portal)
            }
            extra = item.get('extra', {})
            if isinstance(extra, dict):
                params.update(extra)

            xbmc.executebuiltin(f'RunPlugin({common.build_url(params)})')
            xbmc.sleep(300)
            return

    def onFocus(self, controlId):
        return

    def onClick(self, controlId):
        if self._closing:
            return

        if controlId == 900:
            if self.overlay_mode == 'provider_settings':
                self._refresh_guide()
            else:
                self._safe_close()
            return

        if controlId == 100:
            if self._can_activate():
                self._activate_selected()
            return

    def onAction(self, action):
        if self._closing:
            return

        aid = action.getId()

        if aid in [ACTION_PREVIOUS_MENU, ACTION_PARENT_DIR, ACTION_NAV_BACK]:
            self._safe_close()
            return

        if aid in [ACTION_SELECT_ITEM, ACTION_MOUSE_LEFT_CLICK, ACTION_MOUSE_DOUBLE_CLICK, ACTION_ENTER, ACTION_SELECT]:
            try:
                focused = self.getFocusId()
            except Exception:
                focused = -1

            if focused == 100 and self._can_activate():
                self._activate_selected()
            elif focused == 900:
                if self.overlay_mode == 'provider_settings':
                    self._refresh_guide()
                else:
                    self._safe_close()
            return

        if aid == ACTION_MOVE_UP:
            try:
                if self.getFocusId() == 900:
                    self._focus_list()
                    return
            except Exception:
                pass

        if aid == ACTION_MOVE_DOWN:
            try:
                if self.getFocusId() == 100 and self.list_ctrl:
                    pos = self.list_ctrl.getSelectedPosition()
                    if pos >= len(self.items) - 1:
                        self._focus_back()
                        return
            except Exception:
                pass

        if aid in [104, 105, 106, 107, 601, 602, 603, 604, 605, 614, 615]:
            return


def open_guide_overlay(portal, overlay_mode):
    win = GuideOverlayWindow(
        'guide_overlay.xml',
        common.addon_path,
        'default',
        '1080i',
        portal=portal,
        overlay_mode=overlay_mode
    )
    win.doModal()
    del win