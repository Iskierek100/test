# -*- coding: utf-8 -*-
import json
import time

import xbmc
import xbmcgui

from resources.lib import common
from resources.lib.tv import channel_switch


class ChannelInfoDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__()
        self.heading = kwargs.get('heading', 'Informacje')
        self.text = kwargs.get('text', '')
        self.image = kwargs.get('image', '')

    def onInit(self):
        try:
            self.getControl(100).setLabel(self.heading)
        except Exception:
            pass

        try:
            self.getControl(101).setImage(self.image)
        except Exception:
            pass

        try:
            self.getControl(102).setText(self.text)
        except Exception:
            pass

        try:
            self.setFocusId(103)
        except Exception:
            pass

    def onAction(self, action):
        aid = action.getId()
        if aid in [9, 10, 13, 92]:
            self.close()

    def onClick(self, controlId):
        if controlId == 103:
            self.close()


class ChannelOverlay(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__()
        self.state = common.read_json_safe(common.channel_state_file)
        self.channels = self.state.get('channels', [])
        self.current_index = self.state.get('current_index', -1)

        self.groups = ['WSZYSTKIE']
        self._build_groups()

        self.saved_group = common.addon.getSetting('overlay_group') or 'WSZYSTKIE'
        self.group_mode = common.addon.getSetting('overlay_group_mode') or 'remember'

        self.group_index = 0
        self.visible_channels = self.channels[:]
        self.sticky = common.addon.getSetting('overlay_sticky') == 'true'
        self.list = None

    def _sync_current_index_with_player(self):
        try:
            if not xbmc.Player().isPlaying():
                return

            playing_title = xbmc.getInfoLabel('VideoPlayer.Title') or ''
            playing_title = playing_title.strip()

            if not playing_title:
                return

            if ' : ' in playing_title:
                playing_title = playing_title.split(' : ', 1)[0].strip()

            for i, ch in enumerate(self.channels):
                ch_title = str(ch.get('title', '')).strip()
                if ch_title == playing_title:
                    self.current_index = i
                    self.state['current_index'] = i
                    common.write_json_safe(common.channel_state_file, self.state)
                    return
        except Exception:
            pass

    def _ensure_current_channel_selected(self):
        try:
            self._reload_state()

            if self.group_mode == 'current_channel':
                self._sync_group_to_current_channel()

            self._apply_group_filter()

            if not self.list:
                return

            target_pos = -1
            for pos, ch in enumerate(self.visible_channels):
                gi = int(ch.get('_global_index', -1))
                if gi == self.current_index:
                    target_pos = pos
                    break

            self.fill_list()

            if target_pos >= 0:
                xbmc.sleep(50)
                self.list.selectItem(target_pos)
                self.setFocusId(11)
        except Exception:
            pass

    def _reload_state(self):
        self.state = common.read_json_safe(common.channel_state_file)
        self.channels = self.state.get('channels', [])
        self.current_index = self.state.get('current_index', -1)
        self._build_groups()

    def _build_groups(self):
        group_names = []
        for ch in self.channels:
            group_name = ch.get('group_name', 'POZOSTAŁE').strip()
            if group_name and group_name not in group_names:
                group_names.append(group_name)
        self.groups = ['WSZYSTKIE'] + group_names

    def onInit(self):
        self.list = self.getControl(11)
        self._reload_state()
        self._sync_current_index_with_player()
        self._restore_group_mode()
        self.fill_list()
        self._update_pin()
        self._update_group_icon()

    def _restore_group_mode(self):
        if self.group_mode == 'current_channel':
            self._sync_group_to_current_channel()
        else:
            self._restore_saved_group()

    def _restore_saved_group(self):
        try:
            if self.saved_group in self.groups:
                self.group_index = self.groups.index(self.saved_group)
            else:
                self.group_index = 0
        except Exception:
            self.group_index = 0

    def _save_current_group(self):
        try:
            common.addon.setSetting('overlay_group', self.groups[self.group_index])
        except Exception:
            pass

    def _sync_group_to_current_channel(self):
        try:
            if self.current_index < 0 or self.current_index >= len(self.channels):
                self.group_index = 0
                return

            current_channel = self.channels[self.current_index]
            current_group = current_channel.get('group_name', 'POZOSTAŁE').strip()

            if current_group in self.groups:
                self.group_index = self.groups.index(current_group)
            else:
                self.group_index = 0
        except Exception:
            self.group_index = 0

    def _update_group_icon(self):
        try:
            group_off = self.getControl(35)
            group_on = self.getControl(36)

            if self.group_mode == 'current_channel':
                group_on.setVisible(True)
                group_off.setVisible(False)
            else:
                group_on.setVisible(False)
                group_off.setVisible(True)
        except Exception:
            pass

    def _toggle_group_mode(self):
        if self.group_mode == 'remember':
            self.group_mode = 'current_channel'
        else:
            self.group_mode = 'remember'

        common.addon.setSetting('overlay_group_mode', self.group_mode)

        self._restore_group_mode()
        self._update_group_icon()
        self.fill_list()

        mode_label = (
            '[COLOR lime]wg aktualnego kanału[/COLOR]'
            if self.group_mode == 'current_channel'
            else '[COLOR red]zapamiętaj ostatnią grupę[/COLOR]'
        )

        xbmcgui.Dialog().notification(
            common.addonname,
            f'Ustawianie grupy: {mode_label}',
            xbmcgui.NOTIFICATION_INFO,
            2000
        )

    def _update_pin(self):
        try:
            red_pin = self.getControl(30)
            white_pin = self.getControl(34)

            if self.sticky:
                red_pin.setVisible(True)
                white_pin.setVisible(False)
            else:
                red_pin.setVisible(False)
                white_pin.setVisible(True)
        except Exception:
            pass

    def _toggle_sticky(self):
        self.sticky = not self.sticky
        common.addon.setSetting('overlay_sticky', 'true' if self.sticky else 'false')
        self._update_pin()

        status = '[COLOR lime]WŁ[/COLOR]' if self.sticky else '[COLOR red]WYŁ[/COLOR]'
        xbmcgui.Dialog().notification(
            common.addonname,
            f'Pinezka: {status}',
            xbmcgui.NOTIFICATION_INFO,
            2000
        )

    def _open_tv_guide(self):
        try:
            portal = self.state.get('portal', {})
            if not portal:
                xbmcgui.Dialog().notification(
                    common.addonname,
                    'Brak danych portalu dla przewodnika',
                    xbmcgui.NOTIFICATION_ERROR,
                    2000
                )
                return

            self.close()
            xbmc.sleep(200)

            url = common.build_url({
                'mode': 'tv_guide',
                'custom_order': 'true',
                'filter_group': 'ALL_POLISH',
                'portal': json.dumps(portal),
                'genre_name': 'Wszystkie Polskie',
                'return_to': 'overlay'
            })

            xbmc.executebuiltin(f'PlayMedia({url})')

        except Exception as e:
            xbmcgui.Dialog().notification(
                common.addonname,
                f'Błąd przewodnika TV: {e}',
                xbmcgui.NOTIFICATION_ERROR,
                2500
            )

    def _show_channel_info_by_position(self, pos):
        if pos < 0 or pos >= len(self.visible_channels):
            return

        ch = self.visible_channels[pos]

        title = ch.get('title', 'Kanał')
        program = ch.get('program', '')
        next_program = ch.get('next_program', '')
        plot = ch.get('plot', '') or ch.get('desc', '') or 'Brak opisu programu.'
        start_ts = ch.get('start_ts', 0)
        stop_ts = ch.get('stop_ts', 0)

        image = (
            ch.get('image', '') or
            ch.get('thumb', '') or
            ch.get('poster', '') or
            ch.get('cover', '') or
            ch.get('icon', '') or
            ch.get('logo_url', '')
        )

        time_line = ''
        try:
            if start_ts and stop_ts:
                time_line = (
                    f"{time.strftime('%d.%m.%Y %H:%M', time.localtime(start_ts))}"
                    f" - "
                    f"{time.strftime('%H:%M', time.localtime(stop_ts))}"
                )
        except Exception:
            pass

        lines = []
        if time_line:
            lines.append(time_line)
        if program:
            lines.append(program)
        if next_program:
            lines.append(f'Następny: {next_program}')
        if plot:
            lines.append('')
            lines.append(plot)

        text = '\n'.join(lines).strip()
        if not text:
            text = 'Brak danych programu.'

        dlg = ChannelInfoDialog(
            'channel_info.xml',
            common.addon_path,
            'default',
            '1080i',
            heading=title,
            text=text,
            image=image
        )
        dlg.doModal()
        del dlg

    def _show_channel_info(self):
        if not self.list:
            return

        pos = self.list.getSelectedPosition()
        if pos < 0 or pos >= len(self.visible_channels):
            return

        self._show_channel_info_by_position(pos)

    def _apply_group_filter(self):
        self.visible_channels = []

        if self.group_index == 0:
            for gi, ch in enumerate(self.channels):
                item = dict(ch)
                item['_global_index'] = gi
                self.visible_channels.append(item)
        else:
            gname = self.groups[self.group_index]
            for gi, ch in enumerate(self.channels):
                if ch.get('group_name', 'POZOSTAŁE').strip() == gname:
                    item = dict(ch)
                    item['_global_index'] = gi
                    self.visible_channels.append(item)

    def _find_global_index(self, channel_item):
        return int(channel_item.get('_global_index', -1))

    def fill_list(self):
        self._apply_group_filter()

        if not self.list:
            return

        self.list.reset()
        items = []
        selected_pos = 0
        found_current = False

        for idx, ch in enumerate(self.visible_channels):
            title = ch.get('title', 'Kanał')
            program = ch.get('program', '')
            next_program = ch.get('next_program', '')
            logo = ch.get('logo_url', '')

            try:
                progress_val = int(float(ch.get('progress', 0)))
            except Exception:
                progress_val = 0

            if progress_val < 0:
                progress_val = 0
            elif progress_val > 100:
                progress_val = 100

            progress = str(progress_val)

            global_index = self._find_global_index(ch)
            label = f"{global_index + 1}. {title}" if global_index >= 0 else title

            if global_index == self.current_index:
                selected_pos = idx
                found_current = True

            li = xbmcgui.ListItem(label)
            li.setArt({
                'icon': logo,
                'thumb': logo
            })
            li.setProperty('Program', program)
            li.setProperty('NextTitle', next_program)
            li.setProperty('Progress', progress)
            li.setProperty('GlobalIndex', str(global_index))
            li.setProperty('IsPlaying', 'true' if global_index == self.current_index else '')
            items.append(li)

        self.list.addItems(items)

        if items:
            if found_current and 0 <= selected_pos < len(items):
                self.list.selectItem(selected_pos)
            else:
                self.list.selectItem(0)

        xbmc.sleep(50)
        try:
            self.setFocusId(11)
        except Exception:
            pass

        try:
            self.getControl(21).setLabel(self.groups[self.group_index])
        except Exception:
            pass

    def _group_left(self):
        if self.group_index > 0:
            self.group_index -= 1
            self._save_current_group()
            self.fill_list()

    def _group_right(self):
        if self.group_index < len(self.groups) - 1:
            self.group_index += 1
            self._save_current_group()
            self.fill_list()

    def onAction(self, action):
        aid = action.getId()

        if aid == 102:
            self._show_channel_info()
            return

        if aid in [9, 10, 13, 92]:
            self.close()
            return

        if aid in [1, 169, 521]:
            self._group_left()
            return

        if aid in [2, 168, 520]:
            self._group_right()
            return

        if aid == 117:
            self._context_menu()
            return

    def onClick(self, controlId):
        if controlId in [30, 34]:
            self._toggle_sticky()
            return

        if controlId in [35, 36]:
            self._toggle_group_mode()
            return

        if controlId == 37:
            self._open_tv_guide()
            return

        if controlId == 31:
            self._group_left()
            return

        if controlId == 32:
            self._group_right()
            return

        if controlId != 11:
            return

        pos = self.list.getSelectedPosition()
        if pos < 0 or pos >= len(self.visible_channels):
            return

        ch = self.visible_channels[pos]
        global_index = self._find_global_index(ch)

        if global_index < 0:
            return

        channel_switch.play_index(global_index)

        if self.sticky:
            self.current_index = global_index

            if self.group_mode == 'current_channel':
                self._sync_group_to_current_channel()

            self.fill_list()
        else:
            self.close()

    def _context_menu(self):
        pos = self.list.getSelectedPosition()
        if pos < 0 or pos >= len(self.visible_channels):
            return

        ch = self.visible_channels[pos]
        portal = self.state.get('portal', {})
        title = ch.get('title', 'Kanał')
        cmd = ch.get('cmd', '')
        logo = ch.get('logo_url', '')

        group_mode_status = (
            '[COLOR lime]WŁ[/COLOR]'
            if self.group_mode == 'current_channel'
            else '[COLOR red]WYŁ[/COLOR]'
        )

        sticky_status = '[COLOR lime]WŁ[/COLOR]' if self.sticky else '[COLOR red]WYŁ[/COLOR]'

        options = [
            'Pokaż szczegóły programu',
            f'Ustawianie grupy wg kanału: {group_mode_status}',
            f'Pinezka: {sticky_status}',
            'Przewodnik TV',
            'Nagraj bez limitu',
            'Nagraj do końca programu',
            'Nagraj własny czas',
            'Stop nagrywania',
            'Info o nagrywaniu',
            'Pobrane i nagrane',
            'Ustawienia'
        ]

        choice = xbmcgui.Dialog().select(title, options)
        if choice < 0:
            return

        if choice == 0:
            self._show_channel_info()

        elif choice == 1:
            self._toggle_group_mode()

        elif choice == 2:
            self._toggle_sticky()

        elif choice == 3:
            self._open_tv_guide()

        elif choice == 4:
            xbmc.executebuiltin(
                'RunPlugin({})'.format(common.build_url({
                    "mode": "record_tv_start",
                    "cmd": cmd,
                    "title": title,
                    "logo_url": logo,
                    "portal": json.dumps(portal),
                    "stop_ts": ch.get("stop_ts", 0),
                    "record_mode": "unlimited"
                }))
            )

        elif choice == 5:
            xbmc.executebuiltin(
                'RunPlugin({})'.format(common.build_url({
                    "mode": "record_tv_program",
                    "cmd": cmd,
                    "title": title,
                    "logo_url": logo,
                    "portal": json.dumps(portal),
                    "start_ts": ch.get("start_ts", 0),
                    "stop_ts": ch.get("stop_ts", 0)
                }))
            )

        elif choice == 6:
            xbmc.executebuiltin(
                'RunPlugin({})'.format(common.build_url({
                    "mode": "record_tv_start",
                    "cmd": cmd,
                    "title": title,
                    "logo_url": logo,
                    "portal": json.dumps(portal),
                    "stop_ts": ch.get("stop_ts", 0),
                    "record_mode": "custom"
                }))
            )

        elif choice == 7:
            xbmc.executebuiltin(
                'RunPlugin({})'.format(common.build_url({
                    "mode": "record_tv_stop",
                    "portal": json.dumps(portal)
                }))
            )

        elif choice == 8:
            xbmc.executebuiltin(
                'RunPlugin({})'.format(common.build_url({
                    "mode": "recording_info",
                    "portal": json.dumps(portal)
                }))
            )

        elif choice == 9:
            self.close()
            xbmc.sleep(200)
            xbmc.executebuiltin(
                'ActivateWindow(Videos,{},return)'.format(
                    common.build_url({"mode": "media_manager"})
                )
            )

        elif choice == 10:
            self.close()
            xbmc.sleep(200)
            xbmc.executebuiltin(
                'ActivateWindow(Videos,{},return)'.format(
                    common.build_url({
                        "mode": "provider_settings",
                        "portal": json.dumps(portal)
                    })
                )
            )


def open_overlay():
    state = common.read_json_safe(common.channel_state_file)
    channels = state.get('channels', [])

    if not channels:
        xbmcgui.Dialog().notification(
            common.addonname,
            'Brak zapisanej listy kanałów',
            xbmcgui.NOTIFICATION_ERROR
        )
        return

    win = ChannelOverlay('channel_overlay.xml', common.addon_path, 'default', '1080i')
    win.doModal()
    del win