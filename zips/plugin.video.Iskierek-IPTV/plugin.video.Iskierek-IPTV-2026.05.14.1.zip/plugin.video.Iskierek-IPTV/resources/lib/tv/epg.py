# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcplugin,json,time
from datetime import datetime
from resources.lib import common
from resources.lib.providers import provider_api

def load_epg_cache_fast():
    try:
        raw_data=common.read_json_safe(common.epg_raw_file)
        if not raw_data or not isinstance(raw_data,dict): return {}
        final_epg={};now=time.time()
        for ch_name,events in raw_data.items():
            future_events=[e for e in events if e.get('stop',0)>now]
            if not future_events: continue
            future_events.sort(key=lambda x:x.get('start',0));upcoming=future_events[:3]
            if not upcoming: continue
            full_info="";short_on_list="";current_title="";next_title="";start_ts=0;stop_ts=0;current_prog_img="";chan_logo=""
            for i,evt in enumerate(upcoming):
                s_dt=datetime.fromtimestamp(evt['start']);e_dt=datetime.fromtimestamp(evt['stop']);start_h=s_dt.strftime('%H:%M');stop_h=e_dt.strftime('%H:%M')
                if i==0:
                    is_now=evt['start']<=now<=evt['stop'];color="yellow" if is_now else "white"
                    short_on_list=f"{start_h} : {evt['title']}";current_title=evt['title'];start_ts=evt['start'];stop_ts=evt['stop'];current_prog_img=evt.get('img','');chan_logo=evt.get('chan_logo','')
                    full_info+=f"[B][COLOR {color}]{start_h} - {stop_h} : {evt['title']}[/COLOR][/B]\n"
                    if evt.get('desc'): full_info+=f"{evt['desc']}\n"
                    full_info+="\n[COLOR blue]Następnie:[/COLOR]\n"
                else:
                    if i==1: next_title=f"{start_h} {evt['title']}"
                    full_info+=f"[COLOR white]{start_h}[/COLOR] {evt['title']}\n"
            final_epg[ch_name]={'plot':full_info.strip(),'prog_img':current_prog_img,'chan_logo':chan_logo,'short_info':short_on_list,'epg_current':current_title,'epg_next':next_title,'start_ts':start_ts,'stop_ts':stop_ts}
        return final_epg
    except Exception as e:
        xbmc.log(f"[EPG FAST LOAD ERROR] {str(e)}",xbmc.LOGERROR);return {}

def ShowEPG():
    xbmcplugin.setContent(common.addon_handle,'videos')
    norm_name=common.args.get('norm_name',[''])[0]
    chan_logo=common.args.get('icon',[''])[0]
    cmd=common.args.get('cmd',[''])[0]
    channel_name=common.args.get('channel_name',['Kanał TV'])[0]
    portal_arg=common.args.get('portal',[None])[0]

    if not portal_arg:
        current_p=common.get_current_portal()
        portal_arg=json.dumps(current_p) if current_p else "{}"

    programs=[]
    full_epg=common.read_json_safe(common.epg_raw_file)
    if full_epg:
        programs=full_epg.get(norm_name,[])

    if not programs:
        xbmcgui.Dialog().notification(common.addonname,"Brak danych EPG",common.icon_info)
        return

    now=time.time()
    valid_progs=[p for p in programs if p['stop']>now]
    valid_progs.sort(key=lambda x:x['start'])

    for p in valid_progs:
        s_dt=datetime.fromtimestamp(p['start'])
        e_dt=datetime.fromtimestamp(p['stop'])
        start_time=s_dt.strftime('%H:%M')
        end_time=e_dt.strftime('%H:%M')
        day_str=s_dt.strftime('%d.%m')
        is_current=p['start']<now<p['stop']

        if is_current:
            label=f"[COLOR yellow]► TERAZ ({start_time} - {end_time})[/COLOR]\n[B]{p['title']}[/B]"
        else:
            is_today=s_dt.date()==datetime.today().date()
            prefix=f"[COLOR grey]{start_time}[/COLOR]" if is_today else f"[COLOR grey]{day_str} {start_time}[/COLOR]"
            label=f"{prefix}  {p['title']}"

        li=xbmcgui.ListItem(label)
        plot_info=f"[B]Godzina:[/B] {start_time} - {end_time}\n[B]Data:[/B] {day_str}\n\n{p.get('desc','')}"
        li.setInfo('video',{'title':p['title'],'plot':plot_info,'mediatype':'video','duration':p['stop']-p['start']})

        img=p.get('img')
        img=img if img else chan_logo
        li.setArt({'icon':img,'thumb':img,'fanart':common.fanart})

        if is_current:
            li.select(True)

        if cmd:
            li.setProperty('IsPlayable','true')
            url=common.build_url({
                'mode':'play_tv',
                'cmd':cmd,
                'title':channel_name,
                'logo_url':chan_logo,
                'portal':portal_arg,
                'plot':p.get('desc',''),
                'program':p['title'],
                'stop_ts':p['stop']
            })
            is_folder=False

            record_program_params={
                'mode':'record_tv_program',
                'cmd':cmd,
                'title':channel_name,
                'logo_url':chan_logo,
                'portal':portal_arg,
                'start_ts':p['start'],
                'stop_ts':p['stop']
            }
            li.addContextMenuItems([
                ('[COLOR orange]Nagraj do końca programu[/COLOR]', f'RunPlugin({common.build_url(record_program_params)})')
            ])
        else:
            li.setProperty('IsPlayable','false')
            url=""
            is_folder=False

        xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url,listitem=li,isFolder=is_folder)

    xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True)


def AccountInfoLevel(portal):
    provider=provider_api.get_provider(portal)
    try:
        if portal.get('type')=='xtream': data=provider.getAccountInfo(portal)
        elif portal.get('type')=='m3u': data=provider.getAccountInfo(portal)
        else: data=provider.getAccountInfo(portal['mac'],portal['url'],portal['serial'],common.addondir)
        if not data:
            xbmcgui.Dialog().ok(common.addonname,"Brak danych z serwera.");return
        if portal.get('type')=='xtream':
            status=data.get('status','Active');exp_date=data.get('exp_date','')
            if exp_date and str(exp_date).isdigit(): exp_date=datetime.fromtimestamp(int(exp_date)).strftime('%d.%m.%Y')
            active_conn=data.get('active_cons','0');max_conn=data.get('max_connections','1');username=data.get('username',portal.get('username','User'))
            msg=f"[B]Portal:[/B] {portal.get('name','')}\n[B]Użytkownik:[/B] {username}\n[B]Status:[/B] {status}\n[B]Wygasa:[/B] [COLOR lime]{exp_date}[/COLOR]\n-----------------------------\n[B]Połączenia:[/B] {active_conn} / {max_conn}\n"
        elif portal.get('type')=='m3u':
            msg=f"[B]Portal:[/B] {portal.get('name','')}\n[B]Typ:[/B] M3U\n[B]Źródło:[/B] {portal.get('source_type','url')}\n"
            msg+=f"[B]Plik:[/B] {portal.get('file_path','')}\n" if portal.get('source_type')=='file' else f"[B]URL:[/B] {portal.get('url','')}\n"
        else:
            status=data.get('status') or data.get('state') or data.get('account_status') or 'Aktywne'
            exp_date=data.get('end_date') or data.get('expire_billing_date') or data.get('phone') or ''
            active_conn=data.get('active_cons') or data.get('active_connections') or data.get('online') or ''
            max_conn=data.get('max_connections') or data.get('max_online') or ''
            tariff=data.get('tariff_plan') or data.get('tariff') or data.get('stb_type') or ''
            login=data.get('login') or data.get('ls') or ''
            stb_id=data.get('stb_id') or data.get('stb_mac') or portal.get('mac','')
            msg=f"[B]Portal:[/B] {portal.get('name','')}\n"
            if login: msg+=f"[B]Login:[/B] {login}\n"
            msg+=f"[B]Status:[/B] {status}\n"
            if exp_date: msg+=f"[B]Ważność:[/B] [COLOR lime]{exp_date}[/COLOR]\n"
            if tariff: msg+=f"[B]Plan / Typ:[/B] {tariff}\n"
            if stb_id: msg+=f"[B]MAC / STB:[/B] {stb_id}\n"
            if active_conn or max_conn: msg+=f"-----------------------------\n[B]Połączenia:[/B] {active_conn} / {max_conn}\n"
        xbmcgui.Dialog().ok("Informacje o koncie",msg)
    except Exception as e:
        xbmcgui.Dialog().notification(common.addonname,"Błąd info: "+str(e),xbmcgui.NOTIFICATION_ERROR)
