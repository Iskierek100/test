# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,json
from resources.lib import common
import resources.lib.core.sorting as sorting

def PolishGroupsLevel(portal):
    sorting.reload_config()
    xbmcplugin.setContent(common.addon_handle,'files')
    for group_name,_ in sorting.ORDERED_GROUPS:
        url=common.build_url({'mode':'channels','custom_order':'true','filter_group':group_name,'portal':json.dumps(portal),'genre_name':group_name})
        my_icon=common.icon1
        if "FILM" in group_name: my_icon=common.icon2
        elif "SERIAL" in group_name: my_icon=common.icon3
        elif "SPORT" in group_name: my_icon=common.icon1
        li=xbmcgui.ListItem(group_name);li.setArt({'icon':my_icon,'fanart':common.fanart})
        export_params={'mode':'export_group_m3u','group_name':group_name,'portal':json.dumps(portal)}
        li.addContextMenuItems([('[COLOR yellow]Eksportuj grupę do M3U[/COLOR]',f'RunPlugin({common.build_url(export_params)})')])
        xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url,listitem=li,isFolder=True)
    xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True)
