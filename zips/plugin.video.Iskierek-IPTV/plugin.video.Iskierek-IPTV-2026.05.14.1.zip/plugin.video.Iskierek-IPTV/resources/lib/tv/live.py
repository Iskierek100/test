# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcplugin,json,time
from resources.lib import common
from resources.lib.providers import provider_api
from resources.lib.recording import recorder
from resources.lib.tv import channel_switch
import resources.lib.core.sorting as sorting
from resources.lib.menu.provider_menu import set_portal_title
from resources.lib.tv.epg import load_epg_cache_fast
from resources.lib.navigation import get_progress_bar,is_adult_visible

def _calc_progress(start_ts,stop_ts):
    try:
        now=time.time()
        if not start_ts or not stop_ts or stop_ts<=start_ts: return 0
        val=int(((now-start_ts)/(stop_ts-start_ts))*100)
        if val<0: val=0
        if val>100: val=100
        return val
    except: return 0

def _build_playable_state_for_polish_tv(portal):
    sorting.reload_config()
    provider = provider_api.get_provider(portal)

    portal_key = common.get_portal_key(portal)
    custom_names = common.read_json_safe(common.custom_names_file).get(portal_key, {})
    hidden_channels = common.read_json_safe(common.hidden_channels_file).get(portal_key, [])
    default_icon = common.icon0
    bad_hosts = ['103.176.90.95']

    try:
        if portal.get('type') in ['xtream', 'm3u']:
            sorted_all = sorting.get_smart_sorted_list(provider, portal, None, None, common.addondir)
        else:
            sorted_all = sorting.get_smart_sorted_list(
                provider,
                portal['mac'],
                portal['url'],
                portal['serial'],
                common.addondir
            )
    except Exception as e:
        xbmc.log(f"[POLISH TV STATE ERROR] sorting failed: {str(e)}", xbmc.LOGERROR)
        return []

    if not sorted_all:
        return []

    saved_data = common.read_json_safe(common.selected_groups_file)
    default_groups = [g[0] for g in sorting.ORDERED_GROUPS]
    allowed_groups = saved_data.get('pl_supergroup', default_groups)

    final_list = [
        ch for ch in sorted_all
        if ch.get('_my_group_name') in allowed_groups and ch.get('_my_group_name') != 'OTHER'
    ]

    filtered_final_list = []
    for item in final_list:
        if item.get('is_header'):
            continue

        base_name = str(item.get('display_name', item.get('name', '')))
        item['_original_key'] = base_name

        if base_name in hidden_channels:
            continue

        if base_name in custom_names:
            item['display_name'] = custom_names[base_name]

        filtered_final_list.append(item)

    current_epg_cache = load_epg_cache_fast()
    playable_state = []
    state_index = 0

    for item in filtered_final_list:
        title = item.get('display_name', item.get('name', ''))
        cmd = item.get('cmd', '')

        playable_state.append({
            'title': title,
            'cmd': cmd,
            'logo_url': item.get('logo', ''),
            'plot': '',
            'program': '',
            'next_program': '',
            'progress': 0,
            'start_ts': 0,
            'stop_ts': 0,
            'group_name': item.get('_my_group_name', 'OTHER')
        })

        item['_state_index'] = state_index
        state_index += 1

    for item in filtered_final_list:
        try:
            display_name = item.get('display_name', 'Nieznany')
            norm_name = common.clean_channel_name(display_name)

            plot_desc = "Brak informacji."
            epg_current = ""
            epg_next = ""
            start_ts = 0
            stop_ts = 0
            chosen_logo = None
            e = None

            if norm_name in current_epg_cache:
                e = current_epg_cache[norm_name]
            elif display_name.lower() in current_epg_cache:
                e = current_epg_cache[display_name.lower()]
            else:
                for key in current_epg_cache.keys():
                    if norm_name in key or key in norm_name:
                        e = current_epg_cache[key]
                        break

            if e:
                epg_logo = e.get('chan_logo') or e.get('logo') or e.get('icon')
                if epg_logo and str(epg_logo).startswith('http'):
                    if not any(host in str(epg_logo) for host in bad_hosts):
                        chosen_logo = str(epg_logo)

                plot_desc = e.get('plot', plot_desc)
                epg_current = e.get('epg_current', "")
                epg_next = e.get('epg_next', "")
                start_ts = e.get('start_ts', 0)
                stop_ts = e.get('stop_ts', 0)

            if not chosen_logo:
                portal_logo_raw = item.get("logo", "")
                if portal_logo_raw and str(portal_logo_raw).lower() != 'none':
                    if str(portal_logo_raw).startswith('http'):
                        if not any(host in str(portal_logo_raw) for host in bad_hosts):
                            chosen_logo = str(portal_logo_raw)
                    else:
                        base = portal['url'].split('/c/')[0] if '/c/' in portal['url'] else portal['url'].rstrip('/')
                        chosen_logo = f"{base}/stalker_portal/misc/logos/320/{portal_logo_raw}"

            if not chosen_logo:
                chosen_logo = default_icon

            idx = item.get('_state_index', -1)
            if 0 <= idx < len(playable_state):
                playable_state[idx]['logo_url'] = chosen_logo
                playable_state[idx]['plot'] = plot_desc
                playable_state[idx]['program'] = epg_current
                playable_state[idx]['next_program'] = epg_next
                playable_state[idx]['progress'] = _calc_progress(start_ts, stop_ts)
                playable_state[idx]['start_ts'] = start_ts
                playable_state[idx]['stop_ts'] = stop_ts

        except Exception as e:
            xbmc.log(f"[POLISH TV STATE ERROR] item build failed: {str(e)}", xbmc.LOGERROR)
            continue

    return playable_state


def rebuild_all_polish_channel_state(portal):
    try:
        playable_state = _build_playable_state_for_polish_tv(portal)
        channel_switch.save_channel_state(playable_state, -1, portal)
        xbmc.log(f"[Iskierek IPTV Full] rebuilt ALL_POLISH channel_state, items={len(playable_state)}", xbmc.LOGINFO)
        return True
    except Exception as e:
        xbmc.log(f"[Iskierek IPTV Full] rebuild_all_polish_channel_state error: {str(e)}", xbmc.LOGERROR)
        return False

def channelLevel(portal):
    sorting.reload_config()
    set_portal_title(portal,'TV');provider=provider_api.get_provider(portal)
    xbmcplugin.setContent(common.addon_handle,'episodes')
    genre_name=str(common.args.get('genre_name',[""])[0]);selected_genre_id=str(common.args.get('genre_id',[None])[0]);use_custom_order=str(common.args.get('custom_order',['false'])[0])=='true';filter_group=str(common.args.get('filter_group',[None])[0])
    portal_key=common.get_portal_key(portal);custom_names=common.read_json_safe(common.custom_names_file).get(portal_key,{});hidden_channels=common.read_json_safe(common.hidden_channels_file).get(portal_key,[]);default_icon=common.icon0;bad_hosts=['103.176.90.95']
    genre_lower=(genre_name or '').lower();is_adult_genre=any(w in genre_lower for w in provider.ADULT_KEYWORDS)
    if is_adult_genre and not is_adult_visible(portal):
        xbmcgui.Dialog().ok('Blokada','Ta kategoria jest zablokowana.\nUżyj opcji "Odblokuj 18+" w menu portalu.');return

    if use_custom_order:
        try:
            if portal.get('type') in ['xtream','m3u']: sorted_all=sorting.get_smart_sorted_list(provider,portal,None,None,common.addondir)
            else: sorted_all=sorting.get_smart_sorted_list(provider,portal['mac'],portal['url'],portal['serial'],common.addondir)
        except Exception as e:
            xbmc.log(f"[CHANNEL LEVEL ERROR] use_custom_order failed: {str(e)}",xbmc.LOGERROR);xbmcgui.Dialog().ok(common.addonname,f"Błąd listy kanałów:\n{str(e)}");return
        if not sorted_all: return
        if filter_group=='ALL_POLISH':
            saved_data=common.read_json_safe(common.selected_groups_file);default_groups=[g[0] for g in sorting.ORDERED_GROUPS];allowed_groups=saved_data.get('pl_supergroup',default_groups)
            final_list=[ch for ch in sorted_all if ch.get('_my_group_name') in allowed_groups and ch.get('_my_group_name')!='OTHER']
        elif filter_group and filter_group!='None':
            final_list=[ch for ch in sorted_all if ch.get('_my_group_name')==filter_group and not ch.get('is_header')]
        else:
            final_list=sorted_all
    else:
        try:
            if portal.get('type') in ['xtream','m3u']: data=provider.getAllChannels(portal,common.addondir)
            else: data=provider.getAllChannels(portal['mac'],portal['url'],portal['serial'],common.addondir)
        except: return
        raw_channels=data.get('channels',[]);unique_channels={}
        for ch in raw_channels:
            if selected_genre_id!='None' and selected_genre_id!='*' and str(ch.get("genre_id"))!=selected_genre_id: continue
            clean=str(ch.get('name','Nieznany')).replace('PL:','').strip()
            for suffix in [' FHD',' HD',' VIP',' (NOCONN)',' RAW']: clean=clean.replace(suffix,'')
            clean=clean.strip()
            if clean not in unique_channels: ch['display_name']=clean;unique_channels[clean]=ch
        final_list=list(unique_channels.values());final_list.sort(key=lambda x:x.get('display_name','').lower())

    filtered_final_list=[]
    for item in final_list:
        if item.get('is_header'):
            if not use_custom_order or (filter_group and filter_group!='None'): continue
            filtered_final_list.append(item);continue
        base_name=str(item.get('display_name',item.get('name','')));item['_original_key']=base_name
        if base_name in hidden_channels: continue
        if base_name in custom_names: item['display_name']=custom_names[base_name]
        filtered_final_list.append(item)

    current_epg_cache=load_epg_cache_fast();real_channel_number=1
    playable_state=[];state_index=0

    for item in filtered_final_list:
        if item.get('is_header',False): continue
        title=item.get('display_name',item.get('name',''));cmd=item.get('cmd','')
        playable_state.append({'title':title,'cmd':cmd,'logo_url':item.get('logo',''),'plot':'','program':'','next_program':'','progress':0,'start_ts':0,'stop_ts':0,'group_name':item.get('_my_group_name','OTHER')})
        item['_state_index']=state_index
        state_index+=1

    for i in filtered_final_list:
        try:
            display_name=i.get('display_name','Nieznany')
            if i.get('is_header',False):
                li=xbmcgui.ListItem(f"[COLOR red]<><> {display_name} <><>[/COLOR]");li.setArt({'icon':'DefaultAddonService.png','thumb':'DefaultAddonService.png'})
                xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=common.build_url({'mode':'refresh_list'}),listitem=li,isFolder=False);continue

            cmd=str(i.get("cmd") or "");norm_name=common.clean_channel_name(display_name)
            plot_desc="Brak informacji.";epg_current="";epg_next="";start_ts=0;stop_ts=0;epg_prog_img="";chosen_logo=None;e=None

            if norm_name in current_epg_cache: e=current_epg_cache[norm_name]
            elif display_name.lower() in current_epg_cache: e=current_epg_cache[display_name.lower()]
            else:
                for key in current_epg_cache.keys():
                    if norm_name in key or key in norm_name: e=current_epg_cache[key];break

            if e:
                epg_logo=e.get('chan_logo') or e.get('logo') or e.get('icon')
                if epg_logo and str(epg_logo).startswith('http'):
                    if not any(host in str(epg_logo) for host in bad_hosts): chosen_logo=str(epg_logo)
                plot_desc=e.get('plot',plot_desc);epg_current=e.get('epg_current',"");epg_next=e.get('epg_next',"");epg_prog_img=e.get('prog_img',"");start_ts=e.get('start_ts',0);stop_ts=e.get('stop_ts',0)

            if not chosen_logo:
                portal_logo_raw=i.get("logo","")
                if portal_logo_raw and str(portal_logo_raw).lower()!='none':
                    if str(portal_logo_raw).startswith('http'):
                        if not any(host in str(portal_logo_raw) for host in bad_hosts): chosen_logo=str(portal_logo_raw)
                    else:
                        base=portal['url'].split('/c/')[0] if '/c/' in portal['url'] else portal['url'].rstrip('/')
                        chosen_logo=f"{base}/stalker_portal/misc/logos/320/{portal_logo_raw}"
            if not chosen_logo: chosen_logo=default_icon

            idx=i.get('_state_index',-1)
            if 0<=idx<len(playable_state):
                playable_state[idx]['logo_url']=chosen_logo
                playable_state[idx]['plot']=plot_desc
                playable_state[idx]['program']=epg_current
                playable_state[idx]['next_program']=epg_next
                playable_state[idx]['progress']=_calc_progress(start_ts,stop_ts)
                playable_state[idx]['start_ts']=start_ts
                playable_state[idx]['stop_ts']=stop_ts

            rec_status=recorder.get_recording_status()
            rec_title=str(rec_status.get('title','')).strip().lower()
            channel_title=str(display_name).strip().lower()
            rec_prefix='[COLOR red]● REC[/COLOR] ' if rec_status.get('active') and rec_title==channel_title else ''
            
            ch_num=str(real_channel_number)
            if epg_current:
                bar=get_progress_bar(start_ts,stop_ts);epg_short=epg_current[:55].strip()+".." if len(epg_current)>55 else epg_current;full_label=f"{rec_prefix}[B]{ch_num}. {display_name}[/B]\n{bar} [COLOR yellow]{epg_short}[/COLOR]"
            else:
                full_label=f"{rec_prefix}[B]{ch_num}. {display_name}[/B]"

            url=common.build_url({'mode':'play_tv_indexed','cmd':cmd,'title':display_name,'logo_url':chosen_logo,'portal':json.dumps(portal),'plot':plot_desc,'program':epg_current,'stop_ts':stop_ts,'channel_index':idx})
            li=xbmcgui.ListItem(full_label);final_fanart=epg_prog_img if (epg_prog_img and epg_prog_img.startswith('http')) else common.fanart
            li.setArt({'icon':chosen_logo,'thumb':chosen_logo,'poster':chosen_logo,'fanart':final_fanart,'landscape':final_fanart})
            li.setInfo(type='Video',infoLabels={'title':display_name,'plot':plot_desc,'mediatype':'channel'});li.setProperty('IsPlayable','true')

            orig_key=i.get('_original_key',display_name)
            epg_params={'mode':'show_epg','norm_name':norm_name,'icon':chosen_logo,'cmd':cmd,'channel_name':display_name,'portal':json.dumps(portal)}
            rename_params={'mode':'rename_channel','id_key':orig_key,'current_name':display_name,'portal':json.dumps(portal)}
            hide_params={'mode':'hide_channel','id_key':orig_key,'portal':json.dumps(portal)}
            settings_params={'mode':'provider_settings','portal':json.dumps(portal)}
            record_unlimited_params={'mode':'record_tv_start','cmd':cmd,'title':display_name,'logo_url':chosen_logo,'portal':json.dumps(portal),'stop_ts':stop_ts,'record_mode':'unlimited'}
            record_program_params={'mode':'record_tv_program','cmd':cmd,'title':display_name,'logo_url':chosen_logo,'portal':json.dumps(portal),'start_ts':start_ts,'stop_ts':stop_ts}
            record_custom_params={'mode':'record_tv_start','cmd':cmd,'title':display_name,'logo_url':chosen_logo,'portal':json.dumps(portal),'stop_ts':stop_ts,'record_mode':'custom'}
            record_stop_params={'mode':'record_tv_stop','portal':json.dumps(portal)}
            record_info_params={'mode':'recording_info','portal':json.dumps(portal)}
            guide_params={
                'mode':'tv_guide',
                'custom_order':common.args.get('custom_order',['false'])[0],
                'filter_group':common.args.get('filter_group',[''])[0],
                'genre_id':common.args.get('genre_id',[''])[0],
                'genre_name':common.args.get('genre_name',[''])[0],
                'portal':json.dumps(portal)
            }

            context_items=[
                ('[COLOR orange]Pełny przewodnik TV[/COLOR]',f'RunPlugin({common.build_url(guide_params)})'),
                ('[COLOR lime]Nagraj bez limitu[/COLOR]',f'RunPlugin({common.build_url(record_unlimited_params)})'),
                ('[COLOR orange]Nagraj do końca programu[/COLOR]',f'RunPlugin({common.build_url(record_program_params)})'),
                ('[COLOR yellow]Nagraj własny czas[/COLOR]',f'RunPlugin({common.build_url(record_custom_params)})'),
                ('[COLOR yellow]Zmień nazwę[/COLOR]',f'RunPlugin({common.build_url(rename_params)})'),
                ('[COLOR yellow]Ukryj kanał[/COLOR]',f'RunPlugin({common.build_url(hide_params)})'),
                ('[COLOR orange]Ustawienia[/COLOR]',f'Container.Update({common.build_url(settings_params)})')
            ]

            if recorder.is_recording_active():
                context_items.append(('[COLOR orange]Info o nagrywaniu[/COLOR]',f'RunPlugin({common.build_url(record_info_params)})'))
                context_items.append(('[COLOR red]Stop nagrywania[/COLOR]',f'RunPlugin({common.build_url(record_stop_params)})'))

            context_items.append(('[COLOR lime]Odśwież listę[/COLOR]','Container.Refresh'))
            li.addContextMenuItems(context_items)

            xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url,listitem=li,isFolder=False);real_channel_number+=1
        except: continue

    channel_switch.save_channel_state(playable_state,-1,portal)
    xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=False)