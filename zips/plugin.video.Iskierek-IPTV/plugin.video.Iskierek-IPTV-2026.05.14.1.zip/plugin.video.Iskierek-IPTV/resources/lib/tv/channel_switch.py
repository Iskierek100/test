# -*- coding: utf-8 -*-
import json,xbmc,xbmcgui
from resources.lib import common

def save_channel_state(channels,current_index,portal):
    common.write_json_safe(common.channel_state_file,{'channels':channels,'current_index':current_index,'portal':portal})

def load_channel_state():
    data=common.read_json_safe(common.channel_state_file)
    if not isinstance(data,dict): return {'channels':[],'current_index':-1,'portal':{}}
    return {'channels':data.get('channels',[]),'current_index':data.get('current_index',-1),'portal':data.get('portal',{})}

def play_index(idx):
    state=load_channel_state();channels=state['channels'];portal=state['portal']
    if not channels:
        xbmcgui.Dialog().notification(common.addonname,'Brak listy kanałów',xbmcgui.NOTIFICATION_ERROR);return
    if idx<0 or idx>=len(channels):
        xbmcgui.Dialog().notification(common.addonname,'Brak kolejnego kanału',xbmcgui.NOTIFICATION_ERROR);return
    ch=channels[idx]
    save_channel_state(channels,idx,portal)
    url=common.build_url({'mode':'play_tv_indexed','cmd':ch.get('cmd',''),'title':ch.get('title',''),'logo_url':ch.get('logo_url',''),'portal':json.dumps(portal),'plot':ch.get('plot',''),'program':ch.get('program',''),'stop_ts':ch.get('stop_ts',0),'channel_index':idx})
    xbmc.Player().play(url)

def play_next_channel():
    state=load_channel_state();idx=state['current_index']
    if idx<0:
        xbmcgui.Dialog().notification(common.addonname,'Nieznany aktualny kanał',xbmcgui.NOTIFICATION_ERROR);return
    play_index(idx+1)

def play_prev_channel():
    state=load_channel_state();idx=state['current_index']
    if idx<0:
        xbmcgui.Dialog().notification(common.addonname,'Nieznany aktualny kanał',xbmcgui.NOTIFICATION_ERROR);return
    play_index(idx-1)
