# -*- coding: utf-8 -*-
import os
import re
import json
import signal
import shutil
import subprocess
import threading
import time
import urllib.request
import ssl
from datetime import datetime

import xbmc
import xbmcgui,xbmcplugin

from resources.lib import common
from resources.lib.providers import provider_api


_recording_threads = {}


def safe_filename(name):
    if not name:
        return "nagranie"
    name = re.sub(r'[\\/:*?"<>|]+', '_', str(name))
    name = name.strip().strip('.')
    return name or "nagranie"


def get_ffmpeg_binary():
    custom_path = common.addon.getSetting('ffmpeg_path').strip()
    if custom_path:
        if os.path.exists(custom_path):
            return custom_path
        return None
    return shutil.which('ffmpeg')


def get_media_dir():
    media_dir = common.addon.getSetting('recordings_dir').strip()
    if media_dir and os.path.exists(media_dir):
        return media_dir

    selected = xbmcgui.Dialog().browseSingle(
        0,
        'Wybierz folder nagrań i pobrań',
        'files'
    )
    return selected


def _build_record_path(title, out_dir):
    now_str = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    filename = f"{safe_filename(title)}_{now_str}.ts"
    return os.path.join(out_dir, filename)


def _get_stream_url(portal, cmd):
    provider = provider_api.get_provider(portal)

    if portal.get('type') == 'm3u':
        return cmd

    if portal.get('type') == 'xtream':
        return provider.getLinkTV(portal, cmd)

    return provider.getLinkTV(portal['mac'], portal['url'], portal['serial'], cmd)


def _save_recording_state(data):
    common.write_json_safe(common.recording_state_file, data)


def _load_recording_state():
    data = common.read_json_safe(common.recording_state_file)
    if isinstance(data, dict):
        return data
    return {}


def is_recording_active():
    state = _load_recording_state()
    return state.get('active', False)


def get_recording_status():
    state = _load_recording_state()
    if not state.get('active'):
        return {
            'active': False,
            'label': 'OFF'
        }

    backend = state.get('backend', '').upper()
    title = state.get('title', '')
    mode_label = state.get('mode_label', '')
    started = state.get('started', '')

    label = f"ON ({backend})"
    if title:
        label += f" - {title}"
    if mode_label:
        label += f" [{mode_label}]"

    return {
        'active': True,
        'title': title,
        'backend': backend,
        'file': state.get('file', ''),
        'started': started,
        'mode_label': mode_label,
        'label': label
    }


def _notify_recording_worker():
    try:
        interval_str = common.addon.getSetting('record_notify_interval').strip()
        interval = int(interval_str) if interval_str else 0
    except:
        interval = 0

    if interval <= 0:
        return

    while True:
        xbmc.sleep(interval * 60 * 1000)
        state = _load_recording_state()
        if not state.get('active'):
            return

        title = state.get('title', 'Kanał TV')
        xbmcgui.Dialog().notification(
            common.addonname,
            f"[REC] Trwa nagrywanie: {title}",
            xbmcgui.NOTIFICATION_INFO,
            4000
        )


def _file_size_safe(path):
    try:
        if path and os.path.exists(path):
            return os.path.getsize(path)
    except:
        pass
    return 0


def _recording_watchdog_worker():
    xbmc.sleep(7000)

    state = _load_recording_state()
    if not state.get('active'):
        return

    backend = state.get('backend', '')
    file_path = state.get('file', '')
    pid = state.get('pid', 0)

    size1 = _file_size_safe(file_path)
    if size1 <= 0:
        size1 = _file_size_safe(file_path + '.part')

    alive = True

    if backend == 'ffmpeg' and pid:
        try:
            os.kill(pid, 0)
        except:
            alive = False

    xbmc.sleep(5000)

    state2 = _load_recording_state()
    if not state2.get('active'):
        return

    size2 = _file_size_safe(file_path)
    if size2 <= 0:
        size2 = _file_size_safe(file_path + '.part')

    growing = size2 > size1

    if backend == 'ffmpeg' and pid:
        try:
            os.kill(pid, 0)
            alive = True
        except:
            alive = False

    if not alive or not growing:
        xbmc.log(f"[Recorder] watchdog failed alive={alive} growing={growing} file={file_path}", xbmc.LOGERROR)
        _save_recording_state({'active': False})
        xbmcgui.Dialog().notification(
            common.addonname,
            'Nagrywanie nie wystartowało poprawnie',
            xbmcgui.NOTIFICATION_ERROR,
            5000
        )
        xbmc.executebuiltin('Container.Refresh')


def _start_recording_watchdog():
    t = threading.Thread(target=_recording_watchdog_worker)
    t.daemon = True
    t.start()


def _python_record_worker(stream_url, output_path):
    state = _load_recording_state()
    stop_token = state.get('stop_token', '')

    temp_path = output_path + '.part'
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    try:
        req = urllib.request.Request(stream_url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, context=ctx, timeout=30) as response:
            with open(temp_path, 'wb') as f:
                while True:
                    state_now = _load_recording_state()

                    if not state_now.get('active', False):
                        break

                    if state_now.get('stop_token', '') != stop_token:
                        break

                    if state_now.get('stop_at', 0) and time.time() >= state_now.get('stop_at', 0):
                        break

                    chunk = response.read(1024 * 512)
                    if not chunk:
                        break

                    f.write(chunk)

        if os.path.exists(temp_path):
            if os.path.exists(output_path):
                try:
                    os.remove(output_path)
                except:
                    pass
            os.rename(temp_path, output_path)

    except Exception as e:
        xbmc.log(f"[Recorder Python] worker error: {str(e)}", xbmc.LOGERROR)
        try:
            if os.path.exists(temp_path):
                os.remove(temp_path)
        except:
            pass

    finally:
        state_end = _load_recording_state()
        if state_end.get('backend') == 'python':
            _save_recording_state({'active': False})
        xbmc.log("[Recorder Python] recording finished", xbmc.LOGINFO)


def _start_python_recording(stream_url, output_path, title, portal_name, stop_at, mode_label):
    stop_token = str(time.time())

    state = {
        'active': True,
        'backend': 'python',
        'title': title,
        'file': output_path,
        'portal_name': portal_name,
        'stop_token': stop_token,
        'stop_at': stop_at,
        'started': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'mode_label': mode_label
    }
    _save_recording_state(state)

    t = threading.Thread(target=_python_record_worker, args=(stream_url, output_path))
    t.daemon = True
    t.start()
    _recording_threads['python'] = t

    n = threading.Thread(target=_notify_recording_worker)
    n.daemon = True
    n.start()

    _start_recording_watchdog()

    xbmc.log(f"[Recorder] Python recording started: {output_path}", xbmc.LOGINFO)


def _start_ffmpeg_recording(ffmpeg_bin, stream_url, output_path, title, portal_name, duration_seconds, mode_label):
    cmdline = [
        ffmpeg_bin,
        '-y',
        '-i', stream_url,
        '-c', 'copy'
    ]

    if duration_seconds > 0:
        cmdline.extend(['-t', str(duration_seconds)])

    cmdline.append(output_path)

    xbmc.log(f"[Recorder] FFmpeg cmd: {' '.join(cmdline)}", xbmc.LOGINFO)

    proc = subprocess.Popen(
        cmdline,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )

    stop_at = int(time.time()) + duration_seconds if duration_seconds > 0 else 0

    state = {
        'active': True,
        'backend': 'ffmpeg',
        'pid': proc.pid,
        'title': title,
        'file': output_path,
        'portal_name': portal_name,
        'stop_at': stop_at,
        'started': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'mode_label': mode_label
    }
    _save_recording_state(state)

    n = threading.Thread(target=_notify_recording_worker)
    n.daemon = True
    n.start()

    _start_recording_watchdog()

    xbmc.log(f"[Recorder] FFmpeg recording started PID={proc.pid}", xbmc.LOGINFO)


def _get_remaining_minutes_from_stop_ts(stop_ts):
    try:
        stop_ts = int(float(stop_ts))
        now_ts = int(time.time())

        if stop_ts <= now_ts:
            return 0

        remaining = int((stop_ts - now_ts) / 60)
        if remaining < 1:
            return 1
        return remaining
    except:
        return 0


def _ask_custom_minutes():
    kb = xbmc.Keyboard('', 'Podaj czas nagrywania w minutach')
    kb.doModal()

    if not kb.isConfirmed():
        return 0

    txt = kb.getText().strip()
    if not txt.isdigit():
        return 0

    minutes = int(txt)
    if minutes <= 0:
        return 0

    return minutes


def _is_local_proxy_stream(url):
    u = str(url or '').lower()
    return (
        '127.0.0.1' in u or
        'localhost' in u or
        ':6878/' in u or
        'acestream' in u
    )


def _wait_for_stream_ready(stream_url, retries=8, delay=1.5):
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    for attempt in range(retries):
        try:
            req = urllib.request.Request(stream_url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, context=ctx, timeout=10) as response:
                code = getattr(response, 'status', 200)
                if code in [200, 206]:
                    return True
        except Exception as e:
            xbmc.log(f"[Recorder] stream not ready attempt {attempt+1}/{retries}: {e}", xbmc.LOGWARNING)

        time.sleep(delay)

    return False


def start_recording_tv(portal):
    if is_recording_active():
        xbmcgui.Dialog().ok(common.addonname, "Nagrywanie już trwa.\nNajpierw zatrzymaj aktywne nagranie.")
        return

    out_dir = get_media_dir()
    if not out_dir:
        return

    title = common.args.get('title', ['Kanał TV'])[0]
    cmd = common.args.get('cmd', [''])[0]
    record_mode = common.args.get('record_mode', ['unlimited'])[0]
    stop_ts = common.args.get('stop_ts', ['0'])[0]

    if not cmd:
        xbmcgui.Dialog().notification(common.addonname, "Brak komendy kanału", xbmcgui.NOTIFICATION_ERROR)
        return

    duration_seconds = 0
    stop_at = 0
    mode_label = 'bez limitu'

    if record_mode == 'epg':
        remaining_minutes = _get_remaining_minutes_from_stop_ts(stop_ts)
        if remaining_minutes <= 0:
            xbmcgui.Dialog().ok(common.addonname, "Brak danych EPG dla aktualnego programu.")
            return
        duration_seconds = remaining_minutes * 60
        stop_at = int(time.time()) + duration_seconds
        mode_label = f"do końca programu ({remaining_minutes} min)"

    elif record_mode == 'custom':
        minutes = _ask_custom_minutes()
        if minutes <= 0:
            xbmcgui.Dialog().notification(common.addonname, "Nieprawidłowy czas", xbmcgui.NOTIFICATION_ERROR)
            return
        duration_seconds = minutes * 60
        stop_at = int(time.time()) + duration_seconds
        mode_label = f"{minutes} min"

    try:
        stream_url = _get_stream_url(portal, cmd)
    except Exception as e:
        xbmcgui.Dialog().ok(common.addonname, f"Błąd pobierania linku:\n{str(e)}")
        return

    if not stream_url:
        xbmcgui.Dialog().notification(common.addonname, "Nie udało się uzyskać linku streamu", xbmcgui.NOTIFICATION_ERROR)
        return

    if _is_local_proxy_stream(stream_url):
        ok = _wait_for_stream_ready(stream_url, retries=10, delay=1.5)
        if not ok:
            xbmcgui.Dialog().ok(common.addonname, "Stream lokalny / AceStream nie jest jeszcze gotowy do nagrywania.")
            return

    output_path = _build_record_path(title, out_dir)
    ffmpeg_bin = get_ffmpeg_binary()

    try:
        if ffmpeg_bin:
            if _is_local_proxy_stream(stream_url):
                time.sleep(1.0)

            _start_ffmpeg_recording(
                ffmpeg_bin,
                stream_url,
                output_path,
                title,
                portal.get('name', ''),
                duration_seconds,
                mode_label
            )
            xbmcgui.Dialog().ok(common.addonname, f"Rozpoczęto nagrywanie przez ffmpeg:\n{title}\n\nTryb: {mode_label}\nPlik:\n{output_path}")
        else:
            _start_python_recording(
                stream_url,
                output_path,
                title,
                portal.get('name', ''),
                stop_at,
                mode_label
            )
            xbmcgui.Dialog().ok(common.addonname, f"Rozpoczęto nagrywanie wewnętrzne:\n{title}\n\nTryb: {mode_label}\nPlik:\n{output_path}\n\n(ffmpeg nie został znaleziony)")

        xbmc.executebuiltin('Container.Refresh')
    except Exception as e:
        xbmcgui.Dialog().ok(common.addonname, f"Błąd startu nagrywania:\n{str(e)}")


def stop_recording_tv():
    state = _load_recording_state()

    if not state.get('active'):
        xbmcgui.Dialog().ok(common.addonname, "Brak aktywnego nagrywania.")
        return

    backend = state.get('backend')
    title = state.get('title', '')
    output_path = state.get('file', '')

    if backend == 'ffmpeg':
        pid = state.get('pid')
        try:
            if pid:
                os.kill(pid, signal.SIGTERM)
        except Exception as e:
            xbmc.log(f"[Recorder] ffmpeg stop error: {str(e)}", xbmc.LOGERROR)

    elif backend == 'python':
        state['active'] = False
        _save_recording_state(state)
        xbmc.sleep(1000)

    _save_recording_state({'active': False})

    xbmc.log(f"[Recorder] stop backend={backend}", xbmc.LOGINFO)
    xbmcgui.Dialog().ok(common.addonname, f"Zatrzymano nagrywanie:\n{title}\n\nPlik:\n{output_path}")
    xbmc.executebuiltin('Container.Refresh')


def show_recording_info():
    state = _load_recording_state()

    if not state.get('active'):
        xbmcgui.Dialog().ok(common.addonname, "Brak aktywnego nagrywania.")
        return

    title = state.get('title', '')
    backend = state.get('backend', '').upper()
    file_path = state.get('file', '')
    started = state.get('started', '')
    mode_label = state.get('mode_label', '')
    stop_at = state.get('stop_at', 0)

    msg = f"[B]Kanał:[/B] {title}\n"
    msg += f"[B]Backend:[/B] {backend}\n"
    if started:
        msg += f"[B]Start:[/B] {started}\n"
    if mode_label:
        msg += f"[B]Tryb:[/B] {mode_label}\n"
    if stop_at:
        try:
            msg += f"[B]Koniec:[/B] {datetime.fromtimestamp(stop_at).strftime('%Y-%m-%d %H:%M:%S')}\n"
        except:
            pass
    msg += f"[B]Plik:[/B]\n{file_path}"

    xbmcgui.Dialog().ok(common.addonname, msg)


def start_recording_tv_program(portal):
    if is_recording_active():
        xbmcgui.Dialog().ok(common.addonname, "Nagrywanie już trwa.\nNajpierw zatrzymaj aktywne nagranie.")
        return

    out_dir = get_media_dir()
    if not out_dir:
        return

    title = common.args.get('title', ['Kanał TV'])[0]
    cmd = common.args.get('cmd', [''])[0]
    start_ts = common.args.get('start_ts', ['0'])[0]
    stop_ts = common.args.get('stop_ts', ['0'])[0]

    try:
        start_ts = int(float(start_ts))
    except:
        start_ts = 0

    try:
        stop_ts = int(float(stop_ts))
    except:
        stop_ts = 0

    now_ts = int(time.time())

    if not cmd:
        xbmcgui.Dialog().notification(common.addonname, "Brak komendy kanału", xbmcgui.NOTIFICATION_ERROR)
        return

    if stop_ts <= 0:
        xbmcgui.Dialog().ok(common.addonname, "Brak danych EPG dla wybranego programu.")
        return

    if start_ts > now_ts:
        xbmcgui.Dialog().ok(common.addonname, "Timer dla przyszłych programów nie jest jeszcze zaimplementowany.")
        return

    remaining_seconds = stop_ts - now_ts
    if remaining_seconds <= 0:
        xbmcgui.Dialog().ok(common.addonname, "Wybrany program już się zakończył.")
        return

    remaining_minutes = max(1, int(remaining_seconds / 60))
    duration_seconds = remaining_seconds
    stop_at = now_ts + duration_seconds
    mode_label = f"do końca programu ({remaining_minutes} min)"

    try:
        stream_url = _get_stream_url(portal, cmd)
    except Exception as e:
        xbmcgui.Dialog().ok(common.addonname, f"Błąd pobierania linku:\n{str(e)}")
        return

    if not stream_url:
        xbmcgui.Dialog().notification(common.addonname, "Nie udało się uzyskać linku streamu", xbmcgui.NOTIFICATION_ERROR)
        return

    if _is_local_proxy_stream(stream_url):
        ok = _wait_for_stream_ready(stream_url, retries=10, delay=1.5)
        if not ok:
            xbmcgui.Dialog().ok(common.addonname, "Stream lokalny / AceStream nie jest jeszcze gotowy do nagrywania.")
            return

    output_path = _build_record_path(title, out_dir)
    ffmpeg_bin = get_ffmpeg_binary()

    try:
        if ffmpeg_bin:
            if _is_local_proxy_stream(stream_url):
                time.sleep(1.0)

            _start_ffmpeg_recording(
                ffmpeg_bin,
                stream_url,
                output_path,
                title,
                portal.get('name', ''),
                duration_seconds,
                mode_label
            )
        else:
            _start_python_recording(
                stream_url,
                output_path,
                title,
                portal.get('name', ''),
                stop_at,
                mode_label
            )

        xbmcgui.Dialog().ok(
            common.addonname,
            f"Ustawiono nagrywanie programu:\n{title}\n\nTryb: {mode_label}\nPlik:\n{output_path}"
        )
        xbmc.executebuiltin('Container.Refresh')
    except Exception as e:
        xbmcgui.Dialog().ok(common.addonname, f"Błąd startu nagrywania:\n{str(e)}")


def _load_scheduled_recordings():
    data = common.read_json_safe(common.scheduled_recordings_file)
    if isinstance(data, list):
        return data
    return []


def _save_scheduled_recordings(data):
    if not isinstance(data, list):
        data = []
    common.write_json_safe(common.scheduled_recordings_file, data)


def add_scheduled_recording(portal):
    title = common.args.get('title', ['Kanał TV'])[0]
    cmd = common.args.get('cmd', [''])[0]
    logo = common.args.get('logo_url', [''])[0]
    start_ts = common.args.get('start_ts', ['0'])[0]
    stop_ts = common.args.get('stop_ts', ['0'])[0]

    try:
        start_ts = int(float(start_ts))
    except:
        start_ts = 0

    try:
        stop_ts = int(float(stop_ts))
    except:
        stop_ts = 0

    if not cmd or not start_ts or not stop_ts or stop_ts <= start_ts:
        xbmcgui.Dialog().ok(common.addonname, "Nieprawidłowe dane timera nagrania.")
        return

    timers = _load_scheduled_recordings()

    entry = {
        'id': f"{cmd}_{start_ts}_{stop_ts}",
        'title': title,
        'cmd': cmd,
        'logo_url': logo,
        'portal': portal,
        'start_ts': start_ts,
        'stop_ts': stop_ts,
        'status': 'scheduled',
        'created': int(time.time())
    }

    for t in timers:
        if t.get('id') == entry['id']:
            xbmcgui.Dialog().ok(common.addonname, "Takie nagranie jest już ustawione.")
            return

    timers.append(entry)
    timers.sort(key=lambda x: x.get('start_ts', 0))
    _save_scheduled_recordings(timers)

    xbmcgui.Dialog().ok(
        common.addonname,
        f"Ustawiono nagranie programu:\n{title}\n\nStart: {datetime.fromtimestamp(start_ts).strftime('%Y-%m-%d %H:%M:%S')}\nKoniec: {datetime.fromtimestamp(stop_ts).strftime('%Y-%m-%d %H:%M:%S')}"
    )


def _start_scheduled_recording_entry(entry):
    if is_recording_active():
        return False

    portal = entry.get('portal', {})
    title = entry.get('title', 'Kanał TV')
    cmd = entry.get('cmd', '')
    stop_ts = int(entry.get('stop_ts', 0))
    now_ts = int(time.time())

    if not cmd or stop_ts <= now_ts:
        return False

    out_dir = get_media_dir()
    if not out_dir:
        return False

    duration_seconds = stop_ts - now_ts
    if duration_seconds <= 0:
        return False

    mode_label = f"timer ({max(1, int(duration_seconds / 60))} min)"
    output_path = _build_record_path(title, out_dir)
    ffmpeg_bin = get_ffmpeg_binary()

    try:
        stream_url = _get_stream_url(portal, cmd)
    except Exception as e:
        xbmc.log(f"[Recorder] scheduled get stream error: {e}", xbmc.LOGERROR)
        return False

    if not stream_url:
        return False

    if _is_local_proxy_stream(stream_url):
        ok = _wait_for_stream_ready(stream_url, retries=10, delay=1.5)
        if not ok:
            xbmc.log("[Recorder] scheduled local proxy stream not ready", xbmc.LOGERROR)
            return False

    try:
        if ffmpeg_bin:
            if _is_local_proxy_stream(stream_url):
                time.sleep(1.0)

            _start_ffmpeg_recording(
                ffmpeg_bin,
                stream_url,
                output_path,
                title,
                portal.get('name', ''),
                duration_seconds,
                mode_label
            )
        else:
            stop_at = now_ts + duration_seconds
            _start_python_recording(
                stream_url,
                output_path,
                title,
                portal.get('name', ''),
                stop_at,
                mode_label
            )

        xbmcgui.Dialog().notification(common.addonname, f'Start timera nagrania: {title}', xbmcgui.NOTIFICATION_INFO, 4000)
        return True
    except Exception as e:
        xbmc.log(f"[Recorder] scheduled start error: {e}", xbmc.LOGERROR)
        return False


def process_scheduled_recordings():
    timers = _load_scheduled_recordings()
    if not timers:
        return

    now_ts = int(time.time())
    changed = False
    new_timers = []

    for entry in timers:
        status = entry.get('status', 'scheduled')
        start_ts = int(entry.get('start_ts', 0))
        stop_ts = int(entry.get('stop_ts', 0))

        if status == 'scheduled':
            if stop_ts <= now_ts:
                entry['status'] = 'expired'
                changed = True
                new_timers.append(entry)
                continue

            if start_ts <= now_ts:
                started = _start_scheduled_recording_entry(entry)
                if started:
                    entry['status'] = 'started'
                    entry['started_at'] = now_ts
                    changed = True
                new_timers.append(entry)
                continue

        elif status == 'started':
            if stop_ts <= now_ts:
                entry['status'] = 'done'
                changed = True

        new_timers.append(entry)

    if changed:
        _save_scheduled_recordings(new_timers)

def ScheduledRecordingsLevel():
    xbmcplugin.setContent(common.addon_handle, 'files')

    timers = _load_scheduled_recordings()

    if not timers:
        li = xbmcgui.ListItem('[COLOR grey]Brak zaplanowanych nagrań[/COLOR]')
        li.setArt({'icon': common.icon4, 'fanart': common.fanart})
        xbmcplugin.addDirectoryItem(handle=common.addon_handle, url='', listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=True)
        return

    status_colors = {
        'scheduled': 'yellow',
        'started': 'orange',
        'done': 'lime',
        'expired': 'grey'
    }

    status_labels = {
        'scheduled': 'ZAPLANOWANE',
        'started': 'URUCHOMIONE',
        'done': 'ZAKOŃCZONE',
        'expired': 'WYGASŁE'
    }

    timers.sort(key=lambda x: x.get('start_ts', 0))

    for item in timers:
        title = item.get('title', 'Kanał TV')
        status = item.get('status', 'scheduled')
        color = status_colors.get(status, 'white')
        status_text = status_labels.get(status, status.upper())

        start_ts = int(item.get('start_ts', 0))
        stop_ts = int(item.get('stop_ts', 0))

        start_txt = datetime.fromtimestamp(start_ts).strftime('%d.%m %H:%M') if start_ts else '?'
        stop_txt = datetime.fromtimestamp(stop_ts).strftime('%d.%m %H:%M') if stop_ts else '?'

        label = f"[B]{title}[/B]\n[COLOR {color}]{status_text}[/COLOR]  {start_txt} - {stop_txt}"

        li = xbmcgui.ListItem(label)
        li.setArt({'icon': common.icon4, 'fanart': common.fanart})
        li.setInfo('video', {
            'title': title,
            'plot': f"Status: {status_text}\nStart: {start_txt}\nKoniec: {stop_txt}"
        })

        delete_params = {
            'mode': 'record_schedule_delete',
            'record_id': item.get('id', '')
        }
        li.addContextMenuItems([
            ('[COLOR red]Usuń z programatora[/COLOR]', f'RunPlugin({common.build_url(delete_params)})')
        ])

        xbmcplugin.addDirectoryItem(handle=common.addon_handle, url='', listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(common.addon_handle, cacheToDisc=True)


def DeleteScheduledRecording():
    record_id = common.args.get('record_id', [''])[0]
    if not record_id:
        return

    timers = _load_scheduled_recordings()
    target = None

    for t in timers:
        if t.get('id') == record_id:
            target = t
            break

    if not target:
        xbmcgui.Dialog().notification(common.addonname, 'Nie znaleziono wpisu programatora', xbmcgui.NOTIFICATION_ERROR)
        return

    title = target.get('title', 'Kanał TV')
    confirm = xbmcgui.Dialog().yesno(common.addonname, f'Usunąć z programatora?\n{title}')
    if not confirm:
        return

    timers = [t for t in timers if t.get('id') != record_id]
    _save_scheduled_recordings(timers)

    xbmcgui.Dialog().notification(common.addonname, 'Usunięto z programatora', xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin('Container.Refresh')

def has_scheduled_recording(cmd, start_ts, stop_ts):
    try:
        start_ts = int(float(start_ts))
    except:
        start_ts = 0

    try:
        stop_ts = int(float(stop_ts))
    except:
        stop_ts = 0

    timers = _load_scheduled_recordings()
    for t in timers:
        if (
            t.get('cmd', '') == cmd and
            int(t.get('start_ts', 0)) == start_ts and
            int(t.get('stop_ts', 0)) == stop_ts and
            t.get('status', 'scheduled') in ['scheduled', 'started']
        ):
            return True
    return False


def delete_scheduled_recording_by_data(cmd, start_ts, stop_ts):
    try:
        start_ts = int(float(start_ts))
    except:
        start_ts = 0

    try:
        stop_ts = int(float(stop_ts))
    except:
        stop_ts = 0

    timers = _load_scheduled_recordings()
    new_timers = []
    removed = False

    for t in timers:
        if (
            not removed and
            t.get('cmd', '') == cmd and
            int(t.get('start_ts', 0)) == start_ts and
            int(t.get('stop_ts', 0)) == stop_ts and
            t.get('status', 'scheduled') in ['scheduled', 'started']
        ):
            removed = True
            continue
        new_timers.append(t)

    if removed:
        _save_scheduled_recordings(new_timers)
    return removed