# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcplugin,json,os,shutil
from resources.lib import common
from resources.lib.core import channels

def _load_cfg():
    data=common.read_json_safe(common.user_sorting_file)
    if not data or not isinstance(data,dict): return channels.DEFAULT_CONFIG_DATA.copy()
    return data

def _save_cfg(data):
    common.write_json_safe(common.user_sorting_file,data)

def PolishSettingsLevel():
    xbmcplugin.setContent(common.addon_handle,'files')

    export_url=common.build_url({'mode':'polish_settings_export'})
    li_export=xbmcgui.ListItem('[B][COLOR yellow]EKSPORTUJ USTAWIENIA POLSKIEJ TV[/COLOR][/B]')
    li_export.setArt({'icon':common.icon4,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=export_url,listitem=li_export,isFolder=False)

    import_url=common.build_url({'mode':'polish_settings_import'})
    li_import=xbmcgui.ListItem('[B][COLOR yellow]IMPORTUJ USTAWIENIA POLSKIEJ TV[/COLOR][/B]')
    li_import.setArt({'icon':common.icon4,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=import_url,listitem=li_import,isFolder=False)

    reset_url=common.build_url({'mode':'polish_settings_reset'})
    li_reset=xbmcgui.ListItem('[B][COLOR red]PRZYWRÓĆ DOMYŚLNE USTAWIENIA POLSKIEJ TV[/COLOR][/B]')
    li_reset.setArt({'icon':common.icon4,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=reset_url,listitem=li_reset,isFolder=False)

    prefixes_url=common.build_url({'mode':'polish_settings_prefixes'})
    li_prefixes=xbmcgui.ListItem('[B]IGNOROWANE PREFIXY[/B]')
    li_prefixes.setArt({'icon':common.icon1,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=prefixes_url,listitem=li_prefixes,isFolder=True)

    suffixes_url=common.build_url({'mode':'polish_settings_suffixes'})
    li_suffixes=xbmcgui.ListItem('[B]IGNOROWANE SUFFIXY[/B]')
    li_suffixes.setArt({'icon':common.icon1,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=suffixes_url,listitem=li_suffixes,isFolder=True)

    fixes_url=common.build_url({'mode':'polish_settings_fixes'})
    li_fixes=xbmcgui.ListItem('[B]WYJĄTKI NAZW[/B]')
    li_fixes.setArt({'icon':common.icon1,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=fixes_url,listitem=li_fixes,isFolder=True)

    group_keywords_url=common.build_url({'mode':'polish_settings_group_keywords'})
    li_group_keywords=xbmcgui.ListItem('[B]SŁOWA KLUCZOWE GRUP POLSKICH[/B]')
    li_group_keywords.setArt({'icon':common.icon1,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=group_keywords_url,listitem=li_group_keywords,isFolder=True)

    xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True)

def export_settings():
    if not os.path.exists(common.user_sorting_file):
        xbmcgui.Dialog().ok(common.addonname,'Brak pliku ustawień do eksportu.');return
    dest=xbmcgui.Dialog().browseSingle(0,'Wybierz folder eksportu','files')
    if not dest: return
    out_file=os.path.join(dest,'user_sorting_backup.json')
    try:
        shutil.copy2(common.user_sorting_file,out_file)
        xbmcgui.Dialog().ok(common.addonname,f'Wyeksportowano ustawienia:\n{out_file}')
    except Exception as e:
        xbmcgui.Dialog().ok(common.addonname,f'Błąd eksportu:\n{str(e)}')

def import_settings():
    file_path=xbmcgui.Dialog().browseSingle(1,'Wybierz plik ustawień Polskiej TV','files','.json')
    if not file_path or not os.path.exists(file_path): return
    try:
        with open(file_path,'r',encoding='utf-8',errors='ignore') as f: data=json.load(f)
        if not isinstance(data,dict):
            xbmcgui.Dialog().ok(common.addonname,'Nieprawidłowy format pliku.');return
        confirm=xbmcgui.Dialog().yesno(common.addonname,'Czy nadpisać obecne ustawienia Polskiej TV?')
        if not confirm: return
        shutil.copy2(file_path,common.user_sorting_file)
        xbmcgui.Dialog().ok(common.addonname,'Zaimportowano ustawienia Polskiej TV.')
        xbmc.executebuiltin('Container.Refresh')
    except Exception as e:
        xbmcgui.Dialog().ok(common.addonname,f'Błąd importu:\n{str(e)}')

def reset_settings():
    confirm=xbmcgui.Dialog().yesno(common.addonname,'Czy przywrócić domyślne ustawienia Polskiej TV?')
    if not confirm: return
    common.write_json_safe(common.user_sorting_file,channels.DEFAULT_CONFIG_DATA)
    sorting.reload_config()
    xbmcgui.Dialog().ok(common.addonname,'Przywrócono ustawienia domyślne.')
    xbmc.executebuiltin('Container.Refresh')

def _list_editor(title,key,mode_add,mode_del):
    xbmcplugin.setContent(common.addon_handle,'files');cfg=_load_cfg();items=cfg.get(key,[])
    add_url=common.build_url({'mode':mode_add})
    li_add=xbmcgui.ListItem('[B][COLOR lime]+ DODAJ[/COLOR][/B]')
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=add_url,listitem=li_add,isFolder=False)
    for idx,val in enumerate(items):
        del_url=common.build_url({'mode':mode_del,'idx':idx})
        li=xbmcgui.ListItem(val)
        li.addContextMenuItems([('[COLOR red]Usuń[/COLOR]',f'RunPlugin({del_url})')])
        xbmcplugin.addDirectoryItem(handle=common.addon_handle,url='',listitem=li,isFolder=False)
    xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True)

def PrefixesLevel(): _list_editor('Prefixy','ignored_prefixes','polish_settings_prefix_add','polish_settings_prefix_del')
def SuffixesLevel(): _list_editor('Suffixy','ignored_suffixes','polish_settings_suffix_add','polish_settings_suffix_del')

def _add_to_list(key):
    cfg=_load_cfg();kb=xbmc.Keyboard('','Dodaj wpis');kb.doModal()
    if not kb.isConfirmed(): return
    val=kb.getText().strip()
    if not val: return
    items=cfg.get(key,[])
    if val not in items: items.append(val)
    cfg[key]=items;_save_cfg(cfg)
    from resources.lib.core import sorting
    sorting.reload_config()
    xbmc.executebuiltin('Container.Refresh')

def _del_from_list(key):
    cfg=_load_cfg();idx=common.args.get('idx',[''])[0]
    if not str(idx).isdigit(): return
    idx=int(idx);items=cfg.get(key,[])
    if 0<=idx<len(items): items.pop(idx)
    cfg[key]=items;_save_cfg(cfg)
    from resources.lib.core import sorting
    sorting.reload_config()
    xbmc.executebuiltin('Container.Refresh')

def AddPrefix(): _add_to_list('ignored_prefixes')
def DeletePrefix(): _del_from_list('ignored_prefixes')
def AddSuffix(): _add_to_list('ignored_suffixes')
def DeleteSuffix(): _del_from_list('ignored_suffixes')

def FixesLevel():
    xbmcplugin.setContent(common.addon_handle,'files');cfg=_load_cfg();fixes=cfg.get('name_fixes',{})
    add_url=common.build_url({'mode':'polish_settings_fix_add'})
    li_add=xbmcgui.ListItem('[B][COLOR lime]+ DODAJ WYJĄTEK[/COLOR][/B]')
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=add_url,listitem=li_add,isFolder=False)
    for bad,good in sorted(fixes.items(),key=lambda x:x[0].lower()):
        li=xbmcgui.ListItem(f'{bad}  ->  {good}')
        del_url=common.build_url({'mode':'polish_settings_fix_del','bad':bad})
        li.addContextMenuItems([('[COLOR red]Usuń[/COLOR]',f'RunPlugin({del_url})')])
        xbmcplugin.addDirectoryItem(handle=common.addon_handle,url='',listitem=li,isFolder=False)
    xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True)

def AddFix():
    cfg=_load_cfg();fixes=cfg.get('name_fixes',{})
    kb=xbmc.Keyboard('','Nazwa błędna');kb.doModal()
    if not kb.isConfirmed(): return
    bad=kb.getText().strip()
    if not bad: return
    kb=xbmc.Keyboard('','Nazwa poprawna');kb.doModal()
    if not kb.isConfirmed(): return
    good=kb.getText().strip()
    if not good: return
    fixes[bad]=good;cfg['name_fixes']=fixes;_save_cfg(cfg);xbmc.executebuiltin('Container.Refresh')

def DeleteFix():
    cfg=_load_cfg();fixes=cfg.get('name_fixes',{});bad=common.args.get('bad',[''])[0]
    if bad in fixes: del fixes[bad]
    cfg['name_fixes']=fixes;_save_cfg(cfg);xbmc.executebuiltin('Container.Refresh')

def GroupKeywordsLevel(): _list_editor('Grupy polskie','group_keywords','polish_settings_group_keyword_add','polish_settings_group_keyword_del')
def AddGroupKeyword(): _add_to_list('group_keywords')
def DeleteGroupKeyword(): _del_from_list('group_keywords')
