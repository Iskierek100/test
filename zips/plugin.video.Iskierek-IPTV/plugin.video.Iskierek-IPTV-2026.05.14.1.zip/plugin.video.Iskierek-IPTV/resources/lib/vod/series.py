# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,json
from resources.lib import common
from resources.lib.providers import provider_api
from resources.lib.navigation import is_adult_visible

def SeriesGenre(portal):
    xbmcplugin.setContent(common.addon_handle,'files');provider=provider_api.get_provider(portal)
    try: data=provider.getSergenres(portal,common.addondir)
    except Exception as e: xbmcgui.Dialog().notification(common.addonname,str(e),xbmcgui.NOTIFICATION_ERROR);return
    genres=data['sergenres'];saved_data=common.read_json_safe(common.selected_groups_file);portal_key=common.get_portal_key(portal);mac_data=saved_data.get(portal_key,{})
    if isinstance(mac_data,list): mac_data={'ser':[]}
    my_selected=mac_data.get('ser',[])
    if not my_selected:
        li=xbmcgui.ListItem("[COLOR yellow]Brak grup Seriali. Kliknij, aby wybrać.[/COLOR]");url=common.build_url({'mode':'manage_groups_list','g_type':'ser','portal':json.dumps(portal)})
        xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url,listitem=li,isFolder=True);xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True);return
    for gid,item in list(genres.items()):
        if gid not in my_selected: continue
        title=str(item.get("title","")).title();title_lower=title.lower()
        if any(w in title_lower for w in provider.ADULT_KEYWORDS) and not is_adult_visible(portal): continue
        url=common.build_url({'mode':'seriescat','genre_name':title,'cat':item["cat"],'portal':json.dumps(portal)});li=xbmcgui.ListItem(title);li.setArt({'icon':common.icon3,'fanart':common.fanart})
        xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url,listitem=li,isFolder=True)
    xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True)

def SeriesLevel(portal):
    provider=provider_api.get_provider(portal);genre_name=str(common.args.get('genre_name',[""])[0]);genre_lower=genre_name.lower()
    if any(w in genre_lower for w in provider.ADULT_KEYWORDS) and not is_adult_visible(portal):
        xbmcgui.Dialog().ok('Blokada','Ta kategoria seriali jest zablokowana.\nUżyj opcji "Odblokuj 18+" w menu portalu.');return
    try:
        if portal.get('type')=='xtream': data=provider.getSeries(portal,common.args['cat'][0])
        else: data=provider.getSeries(portal['mac'],portal['url'],portal['serial'],common.addondir)
    except Exception: return
    cat=common.args['cat'][0];data=data.get('ser'+cat,[])
    for i in data:
        name=i.get("name","Bez tytułu");logo=i.get("logo","")
        if logo:
            if str(logo).startswith('http'): logo_url=logo
            else:
                base=portal['url'].split('/c/')[0] if '/c/' in portal['url'] else portal['url'].rstrip('/')
                logo_url=f"{base}/stalker_portal/misc/logos/320/{logo}"
        else: logo_url='DefaultVideo.png'
        url=common.build_url({'mode':'season','cat':i['cat'],'name':name,'cmd':i.get("cmd",i.get("cat","")),'category':i.get('category',i.get('cat','')),'genre_name':genre_name,'logo_url':logo_url,'portal':json.dumps(portal)})
        li=xbmcgui.ListItem(name);li.setInfo(type='Video',infoLabels={'title':name,'plot':i.get("plot",""),'year':i.get("year",""),'genre':i.get("genre",""),'mediatype':'tvshow'});li.setArt({'icon':logo_url,'thumb':logo_url,'fanart':common.fanart})
        xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url,listitem=li,isFolder=True)
    xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True)

def SeasonLevel(portal):
    provider=provider_api.get_provider(portal);genre_name=str(common.args.get('genre_name',[""])[0]);genre_lower=genre_name.lower()
    if any(w in genre_lower for w in provider.ADULT_KEYWORDS) and not is_adult_visible(portal):
        xbmcgui.Dialog().ok('Blokada','Ta kategoria seriali jest zablokowana.\nUżyj opcji "Odblokuj 18+" w menu portalu.');return
    try:
        if portal.get('type')=='xtream': data=provider.get_seasons(portal,common.args['cat'][0])
        else: data=provider.get_seasons(portal['mac'],portal['url'],portal['serial'],common.addondir)
    except Exception as e:
        xbmcgui.Dialog().notification(common.addonname,str(e),xbmcgui.NOTIFICATION_ERROR);return
    cat=common.args['cat'][0];data=data.get('seasons'+cat,[])
    for i in data:
        name=i.get("name","Sezon");logo=i.get("logo","")
        if logo:
            if str(logo).startswith('http'): logo_url=logo
            else:
                base=portal['url'].split('/c/')[0] if '/c/' in portal['url'] else portal['url'].rstrip('/')
                logo_url=f"{base}/stalker_portal/misc/logos/320/{logo}"
        else: logo_url='DefaultVideo.png'
        url=common.build_url({'mode':'episode','cat':i["cat"],'category':i["category"],'name':name,'cmd':i.get("cmd",""),'genre_name':genre_name,'portal':json.dumps(portal)})
        li=xbmcgui.ListItem(name);li.setInfo(type='Video',infoLabels={'title':name,'plot':i.get('plot',''),'genre':i.get('genre',''),'mediatype':'season'});li.setArt({'icon':logo_url,'thumb':logo_url,'fanart':common.fanart})
        xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url,listitem=li,isFolder=True)
    xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True)

def EpisodeLevel(portal):
    provider=provider_api.get_provider(portal);genre_name=str(common.args.get('genre_name',[""])[0]);genre_lower=genre_name.lower()
    if any(w in genre_lower for w in provider.ADULT_KEYWORDS) and not is_adult_visible(portal):
        xbmcgui.Dialog().ok('Blokada','Ta kategoria seriali jest zablokowana.\nUżyj opcji "Odblokuj 18+" w menu portalu.');return
    cat=common.args['cat'][0]
    if portal.get('type')=='xtream':
        season_num=common.args['category'][0];data=provider.get_episodes(portal,cat,season_num)
    else:
        data=provider.get_episodes(portal['mac'],portal['url'],portal['serial'],common.addondir)
    data=data.get('episodes',[])
    overlay_items=[]
    for i in data:
        if portal.get('type')!='xtream' and common.args.get('cat',[None])[0]!=i["cat"]: continue
        ext=i.get("extension","mp4")
        title=f"{i.get('name','')}" if portal.get('type')=='xtream' else f"{i.get('name','')} - Odc. {i.get('episode','')}"
        url=common.build_url({'mode':'play_series','episode':i.get("episode",i.get("cmd","")),'name':i.get("name",""),'cat':i.get("cat",""),'category':i.get("category",""),'cmd':i.get("cmd",""),'title':title,'portal':json.dumps(portal),'ext':ext})
        display_title=i.get("name","Odcinek") if portal.get('type')=='xtream' else f"Odcinek {i['episode']}" + (f": {i['name']}" if i.get('name') else "")
        li=xbmcgui.ListItem(display_title);li.setInfo(type='Video',infoLabels={'title':i.get("name",""),'episode':int(i['episode']) if str(i.get('episode','')).isdigit() else 0,'mediatype':'episode','plot':i.get('plot','')});li.setArt({'fanart':common.fanart})
        if i.get('logo'): li.setArt({'icon':i['logo'],'thumb':i['logo'],'fanart':common.fanart})
        li.setProperty('IsPlayable','true')
        download_params={'mode':'download_series','episode':i.get("episode",i.get("cmd","")),'name':i.get("name",""),'cat':i.get("cat",""),'category':i.get("category",""),'cmd':i.get("cmd",""),'title':title,'portal':json.dumps(portal),'ext':ext}
        li.addContextMenuItems([('[COLOR yellow]Pobierz odcinek[/COLOR]',f'RunPlugin({common.build_url(download_params)})')])
        xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url,listitem=li,isFolder=False)

        overlay_items.append({
            'title': display_title,
            'plot': i.get('plot',''),
            'logo_url': i.get('logo',''),
            'episode': i.get("episode",i.get("cmd","")),
            'name': i.get("name",""),
            'cat': i.get("cat",""),
            'category': i.get("category",""),
            'cmd': i.get("cmd",""),
            'ext': ext
        })
    common.write_json_safe(common.vod_state_file, {'items': overlay_items, 'current_index': -1, 'portal': portal, 'content_type': 'series'})
    xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True)
