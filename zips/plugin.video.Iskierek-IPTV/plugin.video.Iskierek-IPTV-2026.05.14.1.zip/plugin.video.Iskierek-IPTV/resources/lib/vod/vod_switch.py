# -*- coding: utf-8 -*-
import json, xbmc, xbmcgui
from resources.lib import common

def save_vod_state(items, current_index, portal, content_type='vod'):
    common.write_json_safe(common.vod_state_file, {
        'items': items,
        'current_index': current_index,
        'portal': portal,
        'content_type': content_type
    })

def load_vod_state():
    data = common.read_json_safe(common.vod_state_file)
    if not isinstance(data, dict):
        return {'items': [], 'current_index': -1, 'portal': {}, 'content_type': 'vod'}
    return {
        'items': data.get('items', []),
        'current_index': data.get('current_index', -1),
        'portal': data.get('portal', {}),
        'content_type': data.get('content_type', 'vod')
    }

def play_index(idx):
    state = load_vod_state()
    items = state['items']
    portal = state['portal']
    content_type = state['content_type']

    if not items:
        xbmcgui.Dialog().notification(common.addonname, 'Brak listy VOD', xbmcgui.NOTIFICATION_ERROR)
        return

    if idx < 0 or idx >= len(items):
        xbmcgui.Dialog().notification(common.addonname, 'Brak kolejnej pozycji', xbmcgui.NOTIFICATION_ERROR)
        return

    item = items[idx]
    save_vod_state(items, idx, portal, content_type)

    if content_type == 'series':
        url = common.build_url({
            'mode': 'play_series_indexed',
            'episode': item.get('episode', ''),
            'name': item.get('name', ''),
            'cat': item.get('cat', ''),
            'category': item.get('category', ''),
            'cmd': item.get('cmd', ''),
            'title': item.get('title', ''),
            'logo_url': item.get('logo_url', ''),
            'portal': json.dumps(portal),
            'ext': item.get('ext', 'mp4'),
            'vod_index': idx
        })
    else:
        url = common.build_url({
            'mode': 'play_vod_indexed',
            'cmd': item.get('cmd', ''),
            'title': item.get('title', ''),
            'logo_url': item.get('logo_url', ''),
            'portal': json.dumps(portal),
            'ext': item.get('ext', 'mp4'),
            'vod_index': idx
        })

    xbmc.Player().play(url)

def play_next():
    state = load_vod_state()
    idx = state['current_index']
    if idx < 0:
        xbmcgui.Dialog().notification(common.addonname, 'Nieznana aktualna pozycja VOD', xbmcgui.NOTIFICATION_ERROR)
        return
    play_index(idx + 1)

def play_prev():
    state = load_vod_state()
    idx = state['current_index']
    if idx < 0:
        xbmcgui.Dialog().notification(common.addonname, 'Nieznana aktualna pozycja VOD', xbmcgui.NOTIFICATION_ERROR)
        return
    play_index(idx - 1)
