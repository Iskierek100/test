# -*- coding: utf-8 -*-
import xbmc, xbmcgui, json
from resources.lib import common
from resources.lib.vod import vod_switch


class VodOverlay(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__()
        self.state = common.read_json_safe(common.vod_state_file)
        self.items = self.state.get('items', [])
        self.filtered_items = self.items[:]
        self.current_index = self.state.get('current_index', -1)
        self.content_type = self.state.get('content_type', 'vod')
        self.search_text = ''

    def onInit(self):
        self.list = self.getControl(11)
        self.fill_list()

    def _apply_filter(self):
        if not self.search_text:
            self.filtered_items = self.items[:]
            return

        q = self.search_text.lower().strip()
        self.filtered_items = [
            item for item in self.items
            if q in str(item.get('title', '')).lower() or q in str(item.get('plot', '')).lower()
        ]

    def fill_list(self):
        self._apply_filter()
        self.list.reset()
        items = []
        selected_pos = 0

        for idx, item in enumerate(self.filtered_items):
            title = item.get('title', 'Pozycja')
            plot = item.get('plot', '')
            logo = item.get('logo_url', '')

            original_index = -1
            for oi, full in enumerate(self.items):
                if full == item:
                    original_index = oi
                    break

            label = f"{original_index + 1}.   {title}" if original_index >= 0 else title
            if original_index == self.current_index:
                label = f"[COLOR red]{label}[/COLOR]"
                selected_pos = idx

            li = xbmcgui.ListItem(label)
            li.setArt({'icon': logo, 'thumb': logo})
            li.setProperty('Program', plot)
            li.setProperty('NextTitle', '')
            li.setProperty('Progress', '0')
            items.append(li)

        self.list.addItems(items)
        if items and 0 <= selected_pos < len(items):
            self.list.selectItem(selected_pos)

        try:
            base_label = 'FILMY' if self.content_type == 'vod' else 'ODCINKI'
            if self.search_text:
                self.getControl(21).setLabel(f'{base_label}  •  SZUKAJ: {self.search_text}')
            else:
                self.getControl(21).setLabel(base_label)
        except:
            pass

    def _search(self):
        kb = xbmc.Keyboard(self.search_text, 'Szukaj')
        kb.doModal()
        if not kb.isConfirmed():
            return
        self.search_text = kb.getText().strip()
        self.fill_list()

    def _clear_search(self):
        if not self.search_text:
            return
        self.search_text = ''
        self.fill_list()

    def onAction(self, action):
        aid = action.getId()
        if aid in [9, 10, 13, 92]:
            self.close()
            return
        if aid == 117:
            self._context_menu()

    def onClick(self, controlId):
        if controlId != 11:
            return

        pos = self.list.getSelectedPosition()
        if pos < 0 or pos >= len(self.filtered_items):
            return

        item = self.filtered_items[pos]
        original_index = -1
        for oi, full in enumerate(self.items):
            if full == item:
                original_index = oi
                break

        if original_index < 0:
            return

        vod_switch.play_index(original_index)
        self.close()

    def _context_menu(self):
        pos = self.list.getSelectedPosition()
        if pos < 0 or pos >= len(self.filtered_items):
            return

        item = self.filtered_items[pos]
        portal = self.state.get('portal', {})
        title = item.get('title', 'Pozycja')

        options = ['Szukaj', 'Wyczyść szukanie', 'Pobrane i nagrane', 'Ustawienia']
        choice = xbmcgui.Dialog().select(title, options)
        if choice < 0:
            return

        if choice == 0:
            self._search()
        elif choice == 1:
            self._clear_search()
        elif choice == 2:
            self.close()
            xbmc.sleep(200)
            xbmc.executebuiltin(f'ActivateWindow(Videos,{common.build_url({"mode": "media_manager"})},return)')
        elif choice == 3:
            self.close()
            xbmc.sleep(200)
            xbmc.executebuiltin(f'ActivateWindow(Videos,{common.build_url({"mode": "provider_settings", "portal": json.dumps(portal)})},return)')


def open_overlay():
    state = common.read_json_safe(common.vod_state_file)
    items = state.get('items', [])
    if not items:
        xbmcgui.Dialog().notification(common.addonname, 'Brak zapisanej listy VOD', xbmcgui.NOTIFICATION_ERROR)
        return
    win = VodOverlay('vod_overlay.xml', common.addon_path, 'default', '1080i')
    win.doModal()
    del win