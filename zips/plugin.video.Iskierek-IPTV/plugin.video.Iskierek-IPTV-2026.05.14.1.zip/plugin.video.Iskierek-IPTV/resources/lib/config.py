# -*- coding: utf-8 -*-
from resources.lib import common


def get_all_portals():
    providers = common.read_providers()
    result = []

    for p in providers:
        if not isinstance(p, dict):
            continue

        if not p.get('enabled', True):
            continue

        ptype = p.get('type')

        if ptype == 'stalker':
            if p.get('url') and p.get('mac'):
                result.append(p)

        elif ptype == 'xtream':
            if p.get('url') and p.get('username') and p.get('password'):
                result.append(p)

        elif ptype == 'm3u':
            if p.get('source_type') == 'file':
                if p.get('file_path'):
                    result.append(p)
            else:
                if p.get('url'):
                    result.append(p)

    return result


def portalConfig(number):
    portals = get_all_portals()
    idx = int(number) - 1
    if 0 <= idx < len(portals):
        return portals[idx]
    return None
