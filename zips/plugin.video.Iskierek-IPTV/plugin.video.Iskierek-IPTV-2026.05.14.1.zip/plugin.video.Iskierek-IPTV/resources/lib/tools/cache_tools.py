# -*- coding: utf-8 -*-
import os,shutil,xbmc,xbmcgui
from resources.lib import common

def refresh_gui(): xbmc.executebuiltin('Container.Refresh')

def ClearLevel():
    pd=xbmcgui.DialogProgressBG()
    try:
        pd.create(common.addonname,'Czyszczenie cache...')
        if os.path.exists(common.cachedir): shutil.rmtree(common.cachedir);os.makedirs(common.cachedir)
        if os.path.exists(common.epgdir):
            for f in os.listdir(common.epgdir):
                try: os.remove(os.path.join(common.epgdir,f))
                except: pass

        pd.update(30,common.addonname,'Cache wyczyszczony, odświeżanie EPG...')
        try:
            from resources.lib import config
            from resources.lib.providers import provider_api
            portals=config.get_all_portals()
            if portals:
                provider=provider_api.get_provider(portals[0])
                provider.update_epg_database(common.addondir)
        except Exception as e:
            xbmc.log(f"[CACHE CLEAR] EPG refresh error: {e}",xbmc.LOGERROR)

        pd.update(100,common.addonname,'Gotowe')
        pd.close()
        xbmcgui.Dialog().notification(common.addonname,'Cache wyczyszczone',common.icon0,2000)
        refresh_gui()
    except Exception as e:
        try: pd.close()
        except: pass
        xbmcgui.Dialog().notification(common.addonname,'Błąd: '+str(e),xbmcgui.NOTIFICATION_ERROR)
