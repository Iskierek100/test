# -*- coding: utf-8 -*-
import xbmc,xbmcplugin,xbmcgui,json
from resources.lib import common

def ProvidersManagerLevel():
    xbmcplugin.setContent(common.addon_handle,'files')

    url_dummy=common.build_url({'mode':'refresh_list'})
    li_sep=xbmcgui.ListItem('[B][COLOR red] <><>[/COLOR][COLOR deepskyblue]------------------ NARZĘDZIA ------------------[/COLOR][COLOR red]<><>[/COLOR][/B]')
    li_sep.setArt({'icon':common.icon11,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_dummy,listitem=li_sep,isFolder=False)

    add_url=common.build_url({'mode':'provider_add'})
    li_add=xbmcgui.ListItem('[B][COLOR lime]+ DODAJ DOSTAWCĘ[/COLOR][/B]')
    li_add.setArt({'icon':common.icon1,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=add_url,listitem=li_add,isFolder=False)

    parental_url=common.build_url({'mode':'parental_manager'})
    li_parental=xbmcgui.ListItem('[B][COLOR orange]KONTROLA RODZICIELSKA[/COLOR][/B]')
    li_parental.setArt({'icon':common.icon4,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=parental_url,listitem=li_parental,isFolder=True)

    export_url=common.build_url({'mode':'providers_export'})
    li_export=xbmcgui.ListItem('[B][COLOR yellow]EKSPORTUJ DOSTAWCÓW[/COLOR][/B]')
    li_export.setArt({'icon':common.icon4,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=export_url,listitem=li_export,isFolder=False)

    import_url=common.build_url({'mode':'providers_import'})
    li_import=xbmcgui.ListItem('[B][COLOR yellow]IMPORTUJ DOSTAWCÓW[/COLOR][/B]')
    li_import.setArt({'icon':common.icon4,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=import_url,listitem=li_import,isFolder=False)

    sorting_export_url=common.build_url({'mode':'providers_sorting_export'})
    li_sorting_export=xbmcgui.ListItem('[B][COLOR yellow]EKSPORTUJ UKŁAD POLSKICH GRUP[/COLOR][/B]')
    li_sorting_export.setArt({'icon':common.icon4,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=sorting_export_url,listitem=li_sorting_export,isFolder=False)

    sorting_import_url=common.build_url({'mode':'providers_sorting_import'})
    li_sorting_import=xbmcgui.ListItem('[B][COLOR yellow]IMPORTUJ UKŁAD POLSKICH GRUP[/COLOR][/B]')
    li_sorting_import.setArt({'icon':common.icon4,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=sorting_import_url,listitem=li_sorting_import,isFolder=False)

    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_dummy,listitem=li_sep,isFolder=False)

    providers=common.read_providers()
    if not providers:
        li=xbmcgui.ListItem('[COLOR grey]Brak zapisanych dostawców[/COLOR]')
        li.setArt({'icon':common.icon0,'fanart':common.fanart})
        xbmcplugin.addDirectoryItem(handle=common.addon_handle,url='',listitem=li,isFolder=False)
    else:
        for p in providers:
            ptype=p.get('type','unknown').upper()
            status='[COLOR lime]WŁ[/COLOR]' if p.get('enabled',True) else '[COLOR red]WYŁ[/COLOR]'
            name=p.get('name','Bez nazwy')
            label=f"[B]{status}[/B] [{ptype}] {name}"
            url=common.build_url({'mode':'provider_edit_menu','provider_id':p.get('id','')})

            li=xbmcgui.ListItem(label)
            li.setArt({'icon':common.icon0,'fanart':common.fanart})

            context_items=[
                ('[COLOR yellow]Info o koncie[/COLOR]', f'ActivateWindow(Videos,{common.build_url({"mode":"account_info","portal":json.dumps(p)})},return)'),
                ('[COLOR yellow]Włącz / Wyłącz[/COLOR]', f'RunPlugin({common.build_url({"mode":"provider_toggle_enabled","provider_id":p.get("id","")})})'),
                ('[COLOR yellow]Edytuj dostawcę[/COLOR]', f'ActivateWindow(Videos,{common.build_url({"mode":"provider_edit_menu","provider_id":p.get("id","")})},return)'),
                ('[COLOR red]Usuń dostawcę[/COLOR]', f'RunPlugin({common.build_url({"mode":"provider_delete","provider_id":p.get("id","")})})')
            ]
            li.addContextMenuItems(context_items)

            xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url,listitem=li,isFolder=True)

    xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True)

def _save_provider(updated_provider):
    providers=common.read_providers()
    new_list=[]
    for p in providers:
        new_list.append(updated_provider if p.get('id')==updated_provider.get('id') else p)
    common.write_providers(new_list)

def AddProvider():
    providers=common.read_providers()
    ptype_idx=xbmcgui.Dialog().select('Wybierz typ dostawcy',['Stalker','Xtream','M3U'])
    if ptype_idx<0: return
    ptype='stalker' if ptype_idx==0 else 'xtream' if ptype_idx==1 else 'm3u'

    kb=xbmc.Keyboard('','Nazwa dostawcy / listy')
    kb.doModal()
    if not kb.isConfirmed(): return
    name=kb.getText().strip()
    if not name: return

    provider={
        'id':common.generate_provider_id(),
        'enabled':True,
        'type':ptype,
        'name':name,
        'use_f4m':False
    }

    if ptype=='stalker':
        kb=xbmc.Keyboard('','Adres URL')
        kb.doModal()
        if not kb.isConfirmed(): return
        provider['url']=kb.getText().strip()

        kb=xbmc.Keyboard('','Adres MAC')
        kb.doModal()
        if not kb.isConfirmed(): return
        provider['mac']=kb.getText().strip()
        provider['serial']=None

        send_serial=xbmcgui.Dialog().yesno('Serial','Czy wysyłać Serial Number?')
        if send_serial:
            custom_serial=xbmcgui.Dialog().yesno('Custom Serial','Czy użyć własnego seriala?')
            if custom_serial:
                kb=xbmc.Keyboard('','Serial Number')
                kb.doModal()
                if not kb.isConfirmed(): return
                sn=kb.getText().strip()

                kb=xbmc.Keyboard('','Device ID 1')
                kb.doModal()
                if not kb.isConfirmed(): return
                device_id=kb.getText().strip()

                kb=xbmc.Keyboard('','Device ID 2')
                kb.doModal()
                if not kb.isConfirmed(): return
                device_id2=kb.getText().strip()

                kb=xbmc.Keyboard('','Signature')
                kb.doModal()
                if not kb.isConfirmed(): return
                signature=kb.getText().strip()

                if sn and device_id and device_id2 and signature:
                    provider['serial']={'custom':True,'sn':sn,'device_id':device_id,'device_id2':device_id2,'signature':signature}
            else:
                provider['serial']={'custom':False}

    elif ptype=='xtream':
        kb=xbmc.Keyboard('','Adres URL')
        kb.doModal()
        if not kb.isConfirmed(): return
        provider['url']=kb.getText().strip()

        kb=xbmc.Keyboard('','Username')
        kb.doModal()
        if not kb.isConfirmed(): return
        provider['username']=kb.getText().strip()

        kb=xbmc.Keyboard('','Password')
        kb.setHiddenInput(True)
        kb.doModal()
        if not kb.isConfirmed(): return
        provider['password']=kb.getText()

    else:
        source_idx=xbmcgui.Dialog().select('Źródło listy M3U',['URL','Plik lokalny'])
        if source_idx<0: return
        if source_idx==0:
            provider['source_type']='url'
            kb=xbmc.Keyboard('','Adres URL listy M3U')
            kb.doModal()
            if not kb.isConfirmed(): return
            provider['url']=kb.getText().strip()
        else:
            provider['source_type']='file'
            selected=xbmcgui.Dialog().browseSingle(1,'Wybierz plik M3U','files','.m3u|.m3u8')
            if not selected: return
            provider['file_path']=selected

    providers.append(provider)
    common.write_providers(providers)
    xbmc.executebuiltin('Container.Refresh')

def ProviderEditMenu():
    provider_id=common.args.get('provider_id',[''])[0]
    provider=common.get_provider_by_id(provider_id)
    if not provider: return

    xbmcplugin.setContent(common.addon_handle,'files')

    enabled_state='[COLOR lime]WŁ[/COLOR]' if provider.get('enabled',True) else '[COLOR red]WYŁ[/COLOR]'
    f4m_state='[COLOR lime]WŁ[/COLOR]' if provider.get('use_f4m',False) else '[COLOR red]WYŁ[/COLOR]'

    items=[
        ('account_info','[B]Info o koncie[/B]'),
        ('provider_toggle_enabled',f'[B]Dostawca aktywny: {enabled_state}[/B]'),
        ('provider_edit_name','[B]Zmień nazwę[/B]'),
        ('provider_edit_url','[B]Zmień URL[/B]'),
        ('provider_edit_f4m',f'[B]Proxy / f4mTester: {f4m_state}[/B]'),
        ('provider_delete','[B][COLOR red]Usuń dostawcę[/COLOR][/B]')
    ]

    if provider.get('type')=='stalker':
        items.insert(4,('provider_edit_mac','[B]Zmień MAC[/B]'))
        items.insert(5,('provider_edit_serial','[B]Edytuj Serial[/B]'))
    elif provider.get('type')=='xtream':
        items.insert(4,('provider_edit_username','[B]Zmień Username[/B]'))
        items.insert(5,('provider_edit_password','[B]Zmień Password[/B]'))
    else:
        source_label=provider.get('source_type','url').upper()
        items.insert(4,('provider_edit_m3u_source_type',f'[B]Źródło M3U: [COLOR yellow]{source_label}[/COLOR][/B]'))
        items.insert(5,('provider_edit_m3u_path','[B]Edytuj URL / plik M3U[/B]'))

    for mode_key,label in items:
        if mode_key=='account_info':
            url=common.build_url({'mode':'account_info','portal':json.dumps(provider)})
        else:
            url=common.build_url({'mode':mode_key,'provider_id':provider_id})
        li=xbmcgui.ListItem(label)
        li.setArt({'icon':common.icon0,'fanart':common.fanart})
        xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url,listitem=li,isFolder=False)

    xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True)

def ToggleProviderEnabled():
    provider_id=common.args.get('provider_id',[''])[0]
    provider=common.get_provider_by_id(provider_id)
    if not provider: return

    provider['enabled']=not provider.get('enabled',True)
    _save_provider(provider)

    state='włączony' if provider.get('enabled',True) else 'wyłączony'
    xbmcgui.Dialog().notification(common.addonname,f'Dostawca {state}',xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin('Container.Refresh')

def EditProviderName():
    provider_id=common.args.get('provider_id',[''])[0]
    provider=common.get_provider_by_id(provider_id)
    if not provider: return

    kb=xbmc.Keyboard(provider.get('name',''),'Nazwa dostawcy')
    kb.doModal()
    if kb.isConfirmed():
        provider['name']=kb.getText().strip()
        _save_provider(provider)
        xbmc.executebuiltin('Container.Refresh')

def EditProviderUrl():
    provider_id=common.args.get('provider_id',[''])[0]
    provider=common.get_provider_by_id(provider_id)
    if not provider: return

    kb=xbmc.Keyboard(provider.get('url',''),'Adres URL')
    kb.doModal()
    if kb.isConfirmed():
        provider['url']=kb.getText().strip()
        _save_provider(provider)
        xbmc.executebuiltin('Container.Refresh')

def EditProviderMac():
    provider_id=common.args.get('provider_id',[''])[0]
    provider=common.get_provider_by_id(provider_id)
    if not provider: return

    kb=xbmc.Keyboard(provider.get('mac',''),'Adres MAC')
    kb.doModal()
    if kb.isConfirmed():
        provider['mac']=kb.getText().strip()
        _save_provider(provider)
        xbmc.executebuiltin('Container.Refresh')

def EditProviderUsername():
    provider_id=common.args.get('provider_id',[''])[0]
    provider=common.get_provider_by_id(provider_id)
    if not provider: return

    kb=xbmc.Keyboard(provider.get('username',''),'Username')
    kb.doModal()
    if kb.isConfirmed():
        provider['username']=kb.getText().strip()
        _save_provider(provider)
        xbmc.executebuiltin('Container.Refresh')

def EditProviderPassword():
    provider_id=common.args.get('provider_id',[''])[0]
    provider=common.get_provider_by_id(provider_id)
    if not provider: return

    kb=xbmc.Keyboard(provider.get('password',''),'Password')
    kb.setHiddenInput(True)
    kb.doModal()
    if kb.isConfirmed():
        provider['password']=kb.getText()
        _save_provider(provider)
        xbmc.executebuiltin('Container.Refresh')

def EditProviderF4M():
    provider_id=common.args.get('provider_id',[''])[0]
    provider=common.get_provider_by_id(provider_id)
    if not provider: return

    provider['use_f4m']=not provider.get('use_f4m',False)
    _save_provider(provider)

    state='ON' if provider.get('use_f4m',False) else 'OFF'
    xbmcgui.Dialog().notification(common.addonname,f'Proxy / f4mTester: {state}',xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin('Container.Refresh')

def EditProviderSerial():
    provider_id=common.args.get('provider_id',[''])[0]
    provider=common.get_provider_by_id(provider_id)
    if not provider: return

    send_serial=xbmcgui.Dialog().yesno('Serial','Czy wysyłać Serial Number?')
    if not send_serial:
        provider['serial']=None
        _save_provider(provider)
        xbmc.executebuiltin('Container.Refresh')
        return

    custom_serial=xbmcgui.Dialog().yesno('Custom Serial','Czy użyć własnego seriala?')
    if not custom_serial:
        provider['serial']={'custom':False}
        _save_provider(provider)
        xbmc.executebuiltin('Container.Refresh')
        return

    kb=xbmc.Keyboard('','Serial Number')
    kb.doModal()
    if not kb.isConfirmed(): return
    sn=kb.getText().strip()

    kb=xbmc.Keyboard('','Device ID 1')
    kb.doModal()
    if not kb.isConfirmed(): return
    device_id=kb.getText().strip()

    kb=xbmc.Keyboard('','Device ID 2')
    kb.doModal()
    if not kb.isConfirmed(): return
    device_id2=kb.getText().strip()

    kb=xbmc.Keyboard('','Signature')
    kb.doModal()
    if not kb.isConfirmed(): return
    signature=kb.getText().strip()

    provider['serial']={'custom':True,'sn':sn,'device_id':device_id,'device_id2':device_id2,'signature':signature}
    _save_provider(provider)
    xbmc.executebuiltin('Container.Refresh')

def EditProviderM3UPath():
    provider_id=common.args.get('provider_id',[''])[0]
    provider=common.get_provider_by_id(provider_id)
    if not provider: return

    source_type=provider.get('source_type','url')
    if source_type=='file':
        selected=xbmcgui.Dialog().browseSingle(1,'Wybierz plik M3U','files','.m3u|.m3u8')
        if selected:
            provider['file_path']=selected
            _save_provider(provider)
            xbmc.executebuiltin('Container.Refresh')
    else:
        kb=xbmc.Keyboard(provider.get('url',''),'Adres URL listy M3U')
        kb.doModal()
        if kb.isConfirmed():
            provider['url']=kb.getText().strip()
            _save_provider(provider)
            xbmc.executebuiltin('Container.Refresh')

def EditProviderM3USourceType():
    provider_id=common.args.get('provider_id',[''])[0]
    provider=common.get_provider_by_id(provider_id)
    if not provider: return

    idx=xbmcgui.Dialog().select('Źródło listy M3U',['URL','Plik lokalny'])
    if idx<0: return
    if idx==0:
        provider['source_type']='url'
        provider.pop('file_path',None)
        provider.setdefault('url','')
    else:
        provider['source_type']='file'
        provider.pop('url',None)
        provider.setdefault('file_path','')

    _save_provider(provider)
    xbmc.executebuiltin('Container.Refresh')

def DeleteProvider():
    provider_id=common.args.get('provider_id',[''])[0]
    provider=common.get_provider_by_id(provider_id)
    if not provider: return

    confirm=xbmcgui.Dialog().yesno('Usuń dostawcę',f"Czy usunąć: {provider.get('name','Bez nazwy')}?")
    if not confirm: return

    providers=common.read_providers()
    providers=[p for p in providers if p.get('id')!=provider_id]
    common.write_providers(providers)
    xbmc.executebuiltin('Container.Refresh')

def ParentalManagerLevel():
    from resources.lib import navigation

    xbmcplugin.setContent(common.addon_handle,'files')

    global_state='[COLOR lime]WŁ[/COLOR]' if common.is_parental_enabled() else '[COLOR red]WYŁ[/COLOR]'
    pin_state='[COLOR lime]USTAWIONY[/COLOR]' if common.has_parental_pin() else '[COLOR red]BRAK[/COLOR]'

    url_toggle=common.build_url({'mode':'parental_toggle_global'})
    li_toggle=xbmcgui.ListItem(f'[B]Kontrola rodzicielska globalnie: {global_state}[/B]')
    li_toggle.setArt({'icon':common.icon4,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_toggle,listitem=li_toggle,isFolder=False)

    url_pin=common.build_url({'mode':'parental_change_pin'})
    li_pin=xbmcgui.ListItem(f'[B]Zmień PIN rodzicielski ({pin_state})[/B]')
    li_pin.setArt({'icon':common.icon4,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_pin,listitem=li_pin,isFolder=False)

    xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True)

def ToggleGlobalParental():
    from resources.lib import navigation

    if common.is_parental_enabled():
        if not navigation.verify_parental_access():
            return
        common.set_parental_enabled(False)
        xbmcgui.Dialog().notification(common.addonname,'Kontrola rodzicielska: WYŁ',xbmcgui.NOTIFICATION_INFO)
    else:
        if not navigation.ensure_parental_pin():
            return
        common.set_parental_enabled(True)
        xbmcgui.Dialog().notification(common.addonname,'Kontrola rodzicielska: WŁ',xbmcgui.NOTIFICATION_INFO)

    xbmc.executebuiltin('Container.Refresh')