# -*- coding: utf-8 -*-
import os,json,shutil,xbmcgui,xbmc
from resources.lib import common
from resources.lib.core import sorting

def export_providers():
    providers=common.read_providers()
    if not providers:
        xbmcgui.Dialog().ok(common.addonname,'Brak dostawców do eksportu.');return
    dest=xbmcgui.Dialog().browseSingle(0,'Wybierz folder eksportu','files')
    if not dest: return
    out_file=os.path.join(dest,'providers_backup.json')
    try:
        with open(out_file,'w',encoding='utf-8',errors='ignore') as f: json.dump(providers,f,indent=4,ensure_ascii=False)
        xbmcgui.Dialog().ok(common.addonname,f'Wyeksportowano dostawców:\n{out_file}')
    except Exception as e:
        xbmcgui.Dialog().ok(common.addonname,f'Błąd eksportu:\n{str(e)}')

def import_providers():
    file_path=xbmcgui.Dialog().browseSingle(1,'Wybierz plik backupu','files','.json')
    if not file_path or not os.path.exists(file_path): return
    try:
        with open(file_path,'r',encoding='utf-8',errors='ignore') as f: data=json.load(f)
        if not isinstance(data,list):
            xbmcgui.Dialog().ok(common.addonname,'Nieprawidłowy format pliku.');return
        confirm=xbmcgui.Dialog().yesno(common.addonname,'Czy nadpisać obecną listę dostawców?')
        if not confirm: return
        common.write_providers(data)
        xbmcgui.Dialog().ok(common.addonname,'Zaimportowano dostawców.')
        xbmc.executebuiltin('Container.Refresh')
    except Exception as e:
        xbmcgui.Dialog().ok(common.addonname,f'Błąd importu:\n{str(e)}')

def export_sorting():
    if not os.path.exists(common.user_sorting_file):
        xbmcgui.Dialog().ok(common.addonname,'Brak pliku user_sorting.json do eksportu.');return
    dest=xbmcgui.Dialog().browseSingle(0,'Wybierz folder eksportu','files')
    if not dest: return
    out_file=os.path.join(dest,'user_sorting_backup.json')
    try:
        shutil.copy2(common.user_sorting_file,out_file)
        xbmcgui.Dialog().ok(common.addonname,f'Wyeksportowano układ grup:\n{out_file}')
    except Exception as e:
        xbmcgui.Dialog().ok(common.addonname,f'Błąd eksportu:\n{str(e)}')

def import_sorting():
    file_path=xbmcgui.Dialog().browseSingle(1,'Wybierz plik układu grup','files','.json')
    if not file_path or not os.path.exists(file_path): return
    try:
        with open(file_path,'r',encoding='utf-8',errors='ignore') as f: data=json.load(f)
        if not isinstance(data,dict):
            xbmcgui.Dialog().ok(common.addonname,'Nieprawidłowy format pliku.');return
        confirm=xbmcgui.Dialog().yesno(common.addonname,'Czy nadpisać obecny układ grup i fixy nazw?')
        if not confirm: return
        shutil.copy2(file_path,common.user_sorting_file)
        sorting.reload_config()
        xbmcgui.Dialog().ok(common.addonname,'Zaimportowano układ grup.')
        xbmc.executebuiltin('Container.Refresh')
    except Exception as e:
        xbmcgui.Dialog().ok(common.addonname,f'Błąd importu:\n{str(e)}')
