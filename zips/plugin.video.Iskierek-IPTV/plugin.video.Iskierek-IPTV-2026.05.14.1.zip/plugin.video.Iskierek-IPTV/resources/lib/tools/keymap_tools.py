# -*- coding: utf-8 -*-
import os,xbmc,xbmcgui,xbmcvfs
from resources.lib import common

def _get_keymap_dir(): return xbmcvfs.translatePath('special://profile/keymaps/')
def _get_keymap_file(): return os.path.join(_get_keymap_dir(),'iskierek_nextprev.xml')

def _build_xml(overlay_key):
    return f'''<keymap>
    <FullscreenVideo>
        <keyboard>
            <{overlay_key}>RunPlugin(plugin://plugin.video.Iskierek-IPTV/?mode=open_channel_overlay)</{overlay_key}>
            <pageup>RunPlugin(plugin://plugin.video.Iskierek-IPTV/?mode=play_prev_channel)</pageup>
            <pagedown>RunPlugin(plugin://plugin.video.Iskierek-IPTV/?mode=play_next_channel)</pagedown>
        </keyboard>
        <mouse>
            <middleclick>RunPlugin(plugin://plugin.video.Iskierek-IPTV/?mode=open_channel_overlay)</middleclick>
        </mouse>
    </FullscreenVideo>
</keymap>
'''

def install_keymap():
    idx=xbmcgui.Dialog().select('Wybierz klawisz dla listy kanałów',['O','0','F8','Tylko środkowy klik myszy'])
    if idx<0: return
    overlay_key='o' if idx==0 else 'zero' if idx==1 else 'f8' if idx==2 else 'noop'
    keymap_dir=_get_keymap_dir();keymap_file=_get_keymap_file()
    if not os.path.exists(keymap_dir): os.makedirs(keymap_dir)

    if overlay_key=='noop':
        xml='''<keymap>
    <FullscreenVideo>
        <keyboard>
            <pageup>RunPlugin(plugin://plugin.video.Iskierek-IPTV/?mode=play_prev_channel)</pageup>
            <pagedown>RunPlugin(plugin://plugin.video.Iskierek-IPTV/?mode=play_next_channel)</pagedown>
        </keyboard>
        <mouse>
            <middleclick>RunPlugin(plugin://plugin.video.Iskierek-IPTV/?mode=open_channel_overlay)</middleclick>
        </mouse>
    </FullscreenVideo>
</keymap>
'''
    else:
        xml=_build_xml(overlay_key)

    try:
        with open(keymap_file,'w',encoding='utf-8',errors='ignore') as f: f.write(xml)
        xbmc.executebuiltin('Action(reloadkeymaps)')
        xbmcgui.Dialog().ok(common.addonname,'Zainstalowano keymapę.\n\nOverlay: wybrany klawisz lub środkowy klik myszy\nPageUp/PageDown = prev/next')
    except Exception as e:
        xbmcgui.Dialog().ok(common.addonname,f'Błąd instalacji keymapy:\n{str(e)}')

def remove_keymap():
    keymap_file=_get_keymap_file()
    try:
        if os.path.exists(keymap_file): os.remove(keymap_file)
        xbmc.executebuiltin('Action(reloadkeymaps)')
        xbmcgui.Dialog().ok(common.addonname,'Usunięto keymapę overlay/next/prev.')
    except Exception as e:
        xbmcgui.Dialog().ok(common.addonname,f'Błąd usuwania keymapy:\n{str(e)}')