# -*- coding: utf-8 -*-
from resources.lib.providers import stalker,xtream,m3u

def get_provider(portal):
    if portal and portal.get('type')=='xtream': return xtream
    if portal and portal.get('type')=='m3u': return m3u
    return stalker
