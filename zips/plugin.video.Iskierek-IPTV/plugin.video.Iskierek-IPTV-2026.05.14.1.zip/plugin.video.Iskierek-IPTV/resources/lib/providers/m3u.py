# -*- coding: utf-8 -*-
import os
import re
import hashlib
import urllib.request
import xbmc
from resources.lib import common

USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
ADULT_KEYWORDS = ['adult', 'xxx', '18+', 'erotic', 'porno', 'doros', 'hard', 'night', 'redlight', 'pornbox', 'sex', 'brazzers', 'hustler']


def _read_m3u_source(portal):
    source_type = portal.get('source_type', 'url')
    xbmc.log(f"[M3U] source_type={source_type}", xbmc.LOGINFO)

    if source_type == 'file':
        path = portal.get('file_path', '')
        xbmc.log(f"[M3U] file_path={path}", xbmc.LOGINFO)

        if not path or not os.path.exists(path):
            xbmc.log("[M3U] file does not exist", xbmc.LOGERROR)
            return ''

        try:
            with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                data = f.read()
                xbmc.log(f"[M3U] file loaded, len={len(data)}", xbmc.LOGINFO)
                return data
        except Exception as e:
            xbmc.log(f"[M3U] file read error: {e}", xbmc.LOGERROR)
            return ''

    url = portal.get('url', '')
    xbmc.log(f"[M3U] url={url}", xbmc.LOGINFO)

    if not url:
        xbmc.log("[M3U] empty URL", xbmc.LOGERROR)
        return ''

    try:
        req = urllib.request.Request(url, headers={'User-Agent': USER_AGENT})
        with urllib.request.urlopen(req, timeout=20) as response:
            data = response.read().decode('utf-8', errors='ignore')
            xbmc.log(f"[M3U] url loaded, len={len(data)}", xbmc.LOGINFO)
            return data
    except Exception as e:
        xbmc.log(f"[M3U] URL read error: {e}", xbmc.LOGERROR)
        return ''


def _parse_m3u(portal):
    raw = _read_m3u_source(portal)
    if not raw:
        xbmc.log("[M3U] raw content empty", xbmc.LOGERROR)
        return [], {}

    lines = [line.strip() for line in raw.splitlines() if line.strip()]
    xbmc.log(f"[M3U] parsed lines={len(lines)}", xbmc.LOGINFO)

    channels = []
    groups = {}

    current_info = None

    for line in lines:
        if line.startswith('#EXTINF:'):
            current_info = line
            continue

        if line.startswith('#'):
            continue

        if current_info:
            stream_url = line
            extinf = current_info

            name_match = re.search(r',(.+)$', extinf)
            name = name_match.group(1).strip() if name_match else "Kanał"

            logo_match = re.search(r'tvg-logo="([^"]*)"', extinf)
            logo = logo_match.group(1).strip() if logo_match else ""

            group_match = re.search(r'group-title="([^"]*)"', extinf)
            group_title = group_match.group(1).strip() if group_match else "Inne"

            tvg_id_match = re.search(r'tvg-id="([^"]*)"', extinf)
            tvg_id = tvg_id_match.group(1).strip() if tvg_id_match else ""

            gid = common.clean_channel_name(group_title)
            if not gid:
                gid = "inne"

            if gid not in groups:
                groups[gid] = {
                    'title': group_title or 'Inne',
                    'cat': gid
                }

            ch_id = hashlib.md5((name + stream_url).encode('utf-8')).hexdigest()

            channels.append({
                'id': ch_id,
                'number': 0,
                'name': common.clean_bad_chars(name),
                'logo': logo,
                'genre_id': gid,
                'cmd': stream_url,
                'tvg_id': tvg_id,
                'group_title': group_title
            })

            current_info = None

    xbmc.log(f"[M3U] channels={len(channels)} groups={len(groups)}", xbmc.LOGINFO)
    return channels, groups


def getAllChannels(portal, *args):
    xbmc.log("[M3U] getAllChannels()", xbmc.LOGINFO)
    channels, _ = _parse_m3u(portal)
    return {'channels': channels}


def getGenres(portal, *args):
    xbmc.log("[M3U] getGenres()", xbmc.LOGINFO)
    _, groups = _parse_m3u(portal)
    return {'genres': groups}


def getVoDgenres(portal, *args):
    return {'vodgenres': {}}


def getVoD(portal, *args):
    return {'vod': []}


def getSergenres(portal, *args):
    return {'sergenres': {}}


def getSeries(portal, *args):
    return {'ser': []}


def get_seasons(portal, *args):
    return {'seasons': []}


def get_episodes(portal, *args):
    return {'episodes': []}


def getLinkTV(portal, cmd):
    xbmc.log(f"[M3U] getLinkTV cmd={cmd}", xbmc.LOGINFO)
    return cmd


def getLinkVoD(portal, cmd, extension='mp4'):
    return cmd


def getLinkSeries(portal, cmd, extension='mp4'):
    return cmd


def getAccountInfo(portal):
    return {
        'status': 'M3U',
        'username': 'Brak',
        'exp_date': '',
        'active_cons': '',
        'max_connections': ''
    }


def get_external_epg(path):
    from resources.lib.providers import xtream
    return xtream.get_external_epg(path)


def update_epg_database(path):
    from resources.lib.providers import xtream
    return xtream.update_epg_database(path)
