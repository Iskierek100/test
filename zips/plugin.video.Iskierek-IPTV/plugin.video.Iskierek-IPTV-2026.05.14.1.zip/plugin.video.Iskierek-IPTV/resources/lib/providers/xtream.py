# -*- coding: utf-8 -*-
import json
import os
import re
import time
import urllib.request
import ssl
import gzip
import shutil
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
import xbmc
import xbmcaddon
from resources.lib import common

USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
ADULT_KEYWORDS = ['adult', 'xxx', '18+', 'erotic', 'porno', 'doros', 'hard', 'night', 'redlight', 'pornbox', 'sex', 'brazzers', 'hustler']


def get_auth_params(portal):
    return portal.get('url', ''), portal.get('username', ''), portal.get('password', '')


def api_call(url):
    try:
        req = urllib.request.Request(url, headers={'User-Agent': USER_AGENT})
        context = ssl._create_unverified_context()
        with urllib.request.urlopen(req, timeout=30, context=context) as response:
            data = response.read()
            try:
                return json.loads(data)
            except:
                return []
    except:
        return []


def getAllChannels(portal, *args):
    host, user, password = get_auth_params(portal)
    if not host or not user:
        return {'channels': []}

    safe_host = re.sub(r'[^a-zA-Z0-9]', '', host)
    cache_file = os.path.join(common.cachedir, f"xtream_{safe_host}_channels.json")

    if os.path.exists(cache_file):
        if (time.time() - os.path.getmtime(cache_file)) < 7200:
            return common.read_json_safe(cache_file)

    api_url = f"{host.rstrip('/')}/player_api.php?username={user}&password={password}&action=get_live_streams"
    data = api_call(api_url)

    channels = []
    if isinstance(data, list):
        for i in data:
            channels.append({
                'id': str(i.get('stream_id')),
                'number': i.get('num', 0),
                'num': i.get('num', 0),
                'name': common.clean_bad_chars(i.get('name')),
                'logo': i.get('stream_icon'),
                'genre_id': str(i.get('category_id')),
                'cmd': str(i.get('stream_id')),
                'stream_type': i.get('stream_type')
            })

    result = {'channels': channels}
    if channels:
        common.write_json_safe(cache_file, result)
    return result


def getGenres(portal, *args):
    return _get_categories(portal, 'get_live_categories', 'genres')


def getVoDgenres(portal, *args):
    return _get_categories(portal, 'get_vod_categories', 'vodgenres')


def getSergenres(portal, *args):
    return _get_categories(portal, 'get_series_categories', 'sergenres')


def _get_categories(portal, action, key_name):
    host, user, password = get_auth_params(portal)
    safe_host = re.sub(r'[^a-zA-Z0-9]', '', host)
    cache_file = os.path.join(common.cachedir, f"xtream_{safe_host}_{key_name}.json")

    if os.path.exists(cache_file):
        if (time.time() - os.path.getmtime(cache_file)) < 86400:
            return common.read_json_safe(cache_file)

    api_url = f"{host.rstrip('/')}/player_api.php?username={user}&password={password}&action={action}"
    data = api_call(api_url)

    cats = {}
    if isinstance(data, list):
        for i in data:
            cid = str(i.get('category_id'))
            name = i.get('category_name', 'Inne')
            cats[cid] = {'title': common.clean_bad_chars(name), 'cat': cid}
    elif isinstance(data, dict):
        for cid, val in data.items():
            if isinstance(val, dict):
                name = val.get('category_name', 'Inne')
                cats[cid] = {'title': common.clean_bad_chars(name), 'cat': str(cid)}

    result = {key_name: cats}
    common.write_json_safe(cache_file, result)
    return result


def getVoD(portal, cat_id):
    host, user, password = get_auth_params(portal)
    safe_host = re.sub(r'[^a-zA-Z0-9]', '', host)
    cache_file = os.path.join(common.cachedir, f"xtream_{safe_host}_vod_{cat_id}.json")

    if os.path.exists(cache_file):
        if (time.time() - os.path.getmtime(cache_file)) < 43200:
            return common.read_json_safe(cache_file)

    api_url = f"{host.rstrip('/')}/player_api.php?username={user}&password={password}&action=get_vod_streams&category_id={cat_id}"
    data = api_call(api_url)

    vods = []
    if isinstance(data, list):
        for i in data:
            vods.append({
                'name': common.clean_bad_chars(i.get('name')),
                'cmd': str(i.get('stream_id')),
                'logo': i.get('stream_icon'),
                'plot': '',
                'year': '',
                'genre': '',
                'extension': i.get('container_extension', 'mp4')
            })

    result = {'vod' + str(cat_id): vods}
    if vods:
        common.write_json_safe(cache_file, result)
    return result


def getSeries(portal, cat_id):
    host, user, password = get_auth_params(portal)
    safe_host = re.sub(r'[^a-zA-Z0-9]', '', host)
    cache_file = os.path.join(common.cachedir, f"xtream_{safe_host}_ser_{cat_id}.json")

    if os.path.exists(cache_file):
        if (time.time() - os.path.getmtime(cache_file)) < 43200:
            return common.read_json_safe(cache_file)

    api_url = f"{host.rstrip('/')}/player_api.php?username={user}&password={password}&action=get_series&category_id={cat_id}"
    data = api_call(api_url)

    sers = []
    if isinstance(data, list):
        for i in data:
            sers.append({
                'name': common.clean_bad_chars(i.get('name')),
                'cat': str(i.get('series_id')),
                'category': str(i.get('series_id')),
                'cmd': str(i.get('series_id')),
                'logo': i.get('cover'),
                'plot': i.get('plot'),
                'genre': i.get('genre'),
                'year': i.get('releaseDate')
            })

    result = {'ser' + str(cat_id): sers}
    common.write_json_safe(cache_file, result)
    return result


def get_seasons(portal, series_id):
    host, user, password = get_auth_params(portal)
    api_url = f"{host.rstrip('/')}/player_api.php?username={user}&password={password}&action=get_series_info&series_id={series_id}"
    data = api_call(api_url)

    seasons_data = data.get('seasons', [])
    episodes_data = data.get('episodes', {})
    seasons_list = []

    if isinstance(seasons_data, list):
        for s in seasons_data:
            s_num = str(s.get('season_number'))
            seasons_list.append({
                'name': f"Sezon {s_num}",
                'cat': series_id,
                'category': s_num,
                'plot': s.get('overview', ''),
                'logo': s.get('cover'),
                'cmd': ''
            })

    elif not seasons_data and episodes_data:
        for s_num in episodes_data.keys():
            seasons_list.append({
                'name': f"Sezon {s_num}",
                'cat': series_id,
                'category': s_num,
                'plot': '',
                'logo': '',
                'cmd': ''
            })

    try:
        seasons_list.sort(key=lambda x: int(x['category']))
    except:
        pass

    cache_file = os.path.join(common.cachedir, f"xtream_episodes_{series_id}.json")
    common.write_json_safe(cache_file, episodes_data)

    return {'seasons' + str(series_id): seasons_list}


def get_episodes(portal, series_id, season_num):
    cache_file = os.path.join(common.cachedir, f"xtream_episodes_{series_id}.json")
    episodes_data = common.read_json_safe(cache_file)
    season_eps = episodes_data.get(str(season_num), [])

    eps_list = []
    for e in season_eps:
        eps_list.append({
            'name': common.clean_bad_chars(e.get('title')),
            'episode': str(e.get('episode_num')),
            'cmd': str(e.get('id')),
            'logo': e.get('info', {}).get('movie_image'),
            'plot': '',
            'cat': series_id,
            'category': season_num,
            'extension': e.get('container_extension', 'mp4')
        })

    return {'episodes': eps_list}


def getLinkTV(portal, cmd):
    host, user, password = get_auth_params(portal)
    return f"{host.rstrip('/')}/live/{user}/{password}/{cmd}.ts"


def getLinkVoD(portal, cmd, extension='mp4'):
    host, user, password = get_auth_params(portal)
    ext = extension.lstrip('.')
    return f"{host.rstrip('/')}/movie/{user}/{password}/{cmd}.{ext}"


def getLinkSeries(portal, cmd, extension='mp4'):
    host, user, password = get_auth_params(portal)
    ext = extension.lstrip('.')
    return f"{host.rstrip('/')}/series/{user}/{password}/{cmd}.{ext}"


def getAccountInfo(portal):
    host, user, password = get_auth_params(portal)
    api_url = f"{host.rstrip('/')}/panel_api.php?username={user}&password={password}"
    data = api_call(api_url)
    return data.get('user_info', {})


def get_external_epg(path):
    json_epg_path = common.epg_raw_file
    final_epg = {}
    now = time.time()

    need_update = False
    if not os.path.exists(json_epg_path):
        need_update = True
    else:
        try:
            if (now - os.path.getmtime(json_epg_path)) > 43200:
                need_update = True
            if os.path.getsize(json_epg_path) < 100:
                need_update = True
        except:
            need_update = True

    if need_update:
        update_epg_database(path)

    raw_data = common.read_json_safe(json_epg_path)
    if raw_data:
        try:
            for ch_name, events in raw_data.items():
                future_events = [e for e in events if e['stop'] > now]
                if not future_events:
                    continue

                future_events.sort(key=lambda x: x['start'])
                upcoming = future_events[:3]
                if not upcoming:
                    continue

                full_info = ""
                short_on_list = ""
                current_title = ""
                next_title = ""
                start_ts = 0
                stop_ts = 0
                current_prog_img = ""
                chan_logo = ""

                for i, evt in enumerate(upcoming):
                    s_dt = datetime.fromtimestamp(evt['start'])
                    e_dt = datetime.fromtimestamp(evt['stop'])
                    start_h = s_dt.strftime('%H:%M')
                    stop_h = e_dt.strftime('%H:%M')

                    if i == 0:
                        short_on_list = f"{start_h} : {evt['title']}"
                        current_title = evt['title']
                        start_ts = evt['start']
                        stop_ts = evt['stop']
                        current_prog_img = evt.get('img', '')
                        chan_logo = evt.get('chan_logo', '')
                        full_info += f"[B][COLOR yellow]{start_h} - {stop_h} : {evt['title']}[/COLOR][/B]\n"
                        if evt.get('desc'):
                            full_info += f"{evt['desc']}\n"
                        full_info += "\n[COLOR blue]Następnie:[/COLOR]\n"
                    else:
                        if i == 1:
                            next_title = f"{start_h} {evt['title']}"
                        full_info += f"[COLOR white]{start_h}[/COLOR] {evt['title']}\n"

                final_epg[ch_name] = {
                    'plot': full_info.strip(),
                    'prog_img': current_prog_img,
                    'chan_logo': chan_logo,
                    'short_info': short_on_list,
                    'epg_current': current_title,
                    'epg_next': next_title,
                    'start_ts': start_ts,
                    'stop_ts': stop_ts
                }
            return final_epg
        except:
            pass

    return {}


def update_epg_database(path):
    common.check_folders()
    TIME_SHIFT = 0
    epg_urls = []

    try:
        my_addon = xbmcaddon.Addon()
        shift_str = my_addon.getSetting('epg_timeshift')
        if shift_str:
            TIME_SHIFT = int(shift_str)
        for i in range(1, 4):
            val = my_addon.getSetting(f'epg_url_{i}')
            if val and len(val) > 4:
                epg_urls.append(val.strip())
    except:
        pass

    if not epg_urls:
        epg_urls.append("https://epg.ovh/pl.gz")

    raw_db = {}
    cutoff_time = time.time() - 7200

    for idx, url in enumerate(epg_urls):
        xml_filename = f'epg_cache_{idx}.xml'
        gz_filename = f'epg_cache_{idx}.gz'
        xml_path = os.path.join(common.epgdir, xml_filename)
        gz_path = os.path.join(common.epgdir, gz_filename)

        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            context = ssl._create_unverified_context()
            with urllib.request.urlopen(req, timeout=60, context=context) as response:
                with open(gz_path if url.endswith('.gz') else xml_path, 'wb') as f:
                    shutil.copyfileobj(response, f)

            if url.endswith('.gz'):
                with gzip.open(gz_path, 'rb') as f_in:
                    with open(xml_path, 'wb') as f_out:
                        shutil.copyfileobj(f_in, f_out)
                try:
                    os.remove(gz_path)
                except:
                    pass
        except:
            continue

        if os.path.exists(xml_path):
            try:
                context = ET.iterparse(xml_path, events=("start", "end"))
                context = iter(context)
                event, root = next(context)

                channels_map = {}
                logos_map = {}
                temp_events = {}

                for event, elem in context:
                    if event == "end" and elem.tag == "channel":
                        cid = elem.get('id')
                        dname = elem.find('display-name')
                        icon = elem.find('icon')

                        if dname is not None and dname.text:
                            channels_map[cid] = common.clean_channel_name(dname.text)
                        if icon is not None:
                            logos_map[cid] = icon.get('src')
                        root.clear()

                    elif event == "end" and elem.tag == "programme":
                        try:
                            raw_start = elem.get('start')[:14]
                            raw_stop = elem.get('stop')[:14]
                            dt_start = datetime.strptime(raw_start, '%Y%m%d%H%M%S')
                            dt_stop = datetime.strptime(raw_stop, '%Y%m%d%H%M%S')

                            if TIME_SHIFT != 0:
                                dt_start += timedelta(hours=TIME_SHIFT)
                                dt_stop += timedelta(hours=TIME_SHIFT)

                            ts_start = dt_start.timestamp()
                            ts_stop = dt_stop.timestamp()

                            if ts_stop < cutoff_time:
                                root.clear()
                                continue

                            cid = elem.get('channel')
                            if cid not in temp_events:
                                temp_events[cid] = []

                            title_elem = elem.find('title')
                            title = title_elem.text if title_elem is not None else "Bez tytułu"
                            title = title.replace('&amp;', '&').replace('&quot;', '"').replace('&apos;', "'")

                            desc_elem = elem.find('desc')
                            desc = desc_elem.text if desc_elem is not None else ""
                            desc = desc.replace('&amp;', '&').replace('&quot;', '"').replace('&apos;', "'")

                            icon = elem.find('icon')
                            prog_img = icon.get('src') if icon is not None else ""

                            temp_events[cid].append({
                                'start': ts_start,
                                'stop': ts_stop,
                                'title': title,
                                'desc': desc,
                                'img': prog_img
                            })
                        except:
                            pass
                        root.clear()

                for cid, events in temp_events.items():
                    if cid in channels_map:
                        norm_key = channels_map[cid]
                        chan_logo = logos_map.get(cid, "")
                        for e in events:
                            e['chan_logo'] = chan_logo

                        if norm_key not in raw_db:
                            raw_db[norm_key] = []
                        raw_db[norm_key].extend(events)
            except:
                pass

    common.write_json_safe(common.epg_raw_file, raw_db)
    return raw_db
