# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,json
from resources.lib import common,config

def homeLevel():
    xbmcplugin.setContent(common.addon_handle,'files');xbmcplugin.setPluginCategory(common.addon_handle,'Dostawcy IPTV')
    portals=config.get_all_portals()
    if not portals:
        li=xbmcgui.ListItem('[COLOR grey]Brak aktywnych dostawców[/COLOR]')
        li.setArt({'icon':common.icon0,'fanart':common.fanart})
        xbmcplugin.addDirectoryItem(handle=common.addon_handle,url='',listitem=li,isFolder=False)
    else:
        for p in portals:
            try:
                label=p.get('name','Portal')
                if p.get('type')=='stalker': label=f"[MAC] {label}"
                elif p.get('type')=='xtream': label=f"[XTREAM] {label}"
                elif p.get('type')=='m3u': label=f"[M3U] {label}"
                url=common.build_url({'mode':'sel','portal':json.dumps(p)})
                li=xbmcgui.ListItem(label)
                li.setArt({'icon':common.icon0,'fanart':common.fanart})
                xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url,listitem=li,isFolder=True)
            except: pass

    url_dummy=common.build_url({'mode':'refresh_list'})
    li_sep=xbmcgui.ListItem('[B][COLOR red] <><>[/COLOR][COLOR deepskyblue]---------------------------------------[/COLOR][COLOR red]<><>[/COLOR][/B]')
    li_sep.setArt({'icon':common.icon11,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_dummy,listitem=li_sep,isFolder=False)

    url_manage=common.build_url({'mode':'providers_manager'})
    li_manage=xbmcgui.ListItem('[B][COLOR yellow]ZARZĄDZAJ DOSTAWCAMI[/COLOR][/B]')
    li_manage.setArt({'icon':common.icon_info,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_manage,listitem=li_manage,isFolder=True)

    url_polish=common.build_url({'mode':'polish_settings'})
    li_polish=xbmcgui.ListItem('[B][COLOR orange]USTAWIENIA POLSKIEJ TV[/COLOR][/B]')
    li_polish.setArt({'icon':common.icon4,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_polish,listitem=li_polish,isFolder=True)

    xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True)
