# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,json
from resources.lib import common
from resources.lib.recording import recorder

def ProviderSettingsLevel(portal):
    current_portal=common.get_provider_by_id(portal.get('id','')) or portal
    xbmcplugin.setContent(common.addon_handle,'files');xbmcplugin.setPluginCategory(common.addon_handle,f"{current_portal.get('name','')} / Ustawienia")

    url_groups=common.build_url({'mode':'provider_settings_groups','portal':json.dumps(current_portal)})
    li_groups=xbmcgui.ListItem('[B]GRUPY I KANAŁY[/B]');li_groups.setArt({'icon':common.icon1,'fanart':common.fanart});xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_groups,listitem=li_groups,isFolder=True)

    url_parental=common.build_url({'mode':'provider_settings_parental','portal':json.dumps(current_portal)})
    li_parental=xbmcgui.ListItem('[B]KONTROLA RODZICIELSKA[/B]');li_parental.setArt({'icon':common.icon4,'fanart':common.fanart});xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_parental,listitem=li_parental,isFolder=True)

    url_recording=common.build_url({'mode':'provider_settings_recording','portal':json.dumps(current_portal)})
    li_recording=xbmcgui.ListItem('[B]NAGRYWANIE I POBIERANIE[/B]');li_recording.setArt({'icon':common.icon4,'fanart':common.fanart});xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_recording,listitem=li_recording,isFolder=True)

    url_tools=common.build_url({'mode':'provider_settings_tools','portal':json.dumps(current_portal)})
    li_tools=xbmcgui.ListItem('[B]NARZĘDZIA[/B]');li_tools.setArt({'icon':common.icon4,'fanart':common.fanart});xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_tools,listitem=li_tools,isFolder=True)

    xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True)


def ProviderSettingsLevel(portal):
    current_portal=common.get_provider_by_id(portal.get('id','')) or portal
    xbmcplugin.setContent(common.addon_handle,'files')
    xbmcplugin.setPluginCategory(common.addon_handle,f"{current_portal.get('name','')} / Ustawienia")

    url_groups=common.build_url({'mode':'provider_settings_groups','portal':json.dumps(current_portal)})
    li_groups=xbmcgui.ListItem('[B]GRUPY I KANAŁY[/B]')
    li_groups.setArt({'icon':common.icon1,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_groups,listitem=li_groups,isFolder=True)

    url_parental=common.build_url({'mode':'provider_settings_parental','portal':json.dumps(current_portal)})
    li_parental=xbmcgui.ListItem('[B]KONTROLA RODZICIELSKA[/B]')
    li_parental.setArt({'icon':common.icon4,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_parental,listitem=li_parental,isFolder=True)

    url_recording=common.build_url({'mode':'provider_settings_recording','portal':json.dumps(current_portal)})
    li_recording=xbmcgui.ListItem('[B]NAGRYWANIE I POBIERANIE[/B]')
    li_recording.setArt({'icon':common.icon4,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_recording,listitem=li_recording,isFolder=True)

    url_tools=common.build_url({'mode':'provider_settings_tools','portal':json.dumps(current_portal)})
    li_tools=xbmcgui.ListItem('[B]NARZĘDZIA[/B]')
    li_tools.setArt({'icon':common.icon4,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_tools,listitem=li_tools,isFolder=True)

    xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True)

def GroupsSettingsLevel(portal):
    current_portal=common.get_provider_by_id(portal.get('id','')) or portal
    xbmcplugin.setContent(common.addon_handle,'files')

    url_edit_pl=common.build_url({'mode':'edit_pl_supergroup','portal':json.dumps(current_portal)})
    li_edit_pl=xbmcgui.ListItem('[B]Edytuj Wszystkie Polskie[/B]');li_edit_pl.setArt({'icon':common.icon1,'fanart':common.fanart});xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_edit_pl,listitem=li_edit_pl,isFolder=False)

    url_hidden=common.build_url({'mode':'hidden_manager','portal':json.dumps(current_portal)})
    li_hidden=xbmcgui.ListItem('[B]Zarządzaj ukrytymi kanałami[/B]');li_hidden.setArt({'icon':common.icon4,'fanart':common.fanart});xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_hidden,listitem=li_hidden,isFolder=True)

    url_groups_tv=common.build_url({'mode':'open_group_select','g_type':'tv','portal':json.dumps(current_portal)})
    li_groups_tv=xbmcgui.ListItem('[B]Zarządzaj grupami TV[/B]');li_groups_tv.setArt({'icon':common.icon1,'fanart':common.fanart});xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_groups_tv,listitem=li_groups_tv,isFolder=False)

    url_groups_vod=common.build_url({'mode':'open_group_select','g_type':'vod','portal':json.dumps(current_portal)})
    li_groups_vod=xbmcgui.ListItem('[B]Zarządzaj grupami VOD[/B]');li_groups_vod.setArt({'icon':common.icon2,'fanart':common.fanart});xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_groups_vod,listitem=li_groups_vod,isFolder=False)

    url_groups_ser=common.build_url({'mode':'open_group_select','g_type':'ser','portal':json.dumps(current_portal)})
    li_groups_ser=xbmcgui.ListItem('[B]Zarządzaj grupami Seriali[/B]');li_groups_ser.setArt({'icon':common.icon3,'fanart':common.fanart});xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_groups_ser,listitem=li_groups_ser,isFolder=False)

    xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True)

def ProviderSettingsLevel(portal):
    current_portal=common.get_provider_by_id(portal.get('id','')) or portal
    xbmcplugin.setContent(common.addon_handle,'files')
    xbmcplugin.setPluginCategory(common.addon_handle,f"{current_portal.get('name','')} / Ustawienia")

    url_groups=common.build_url({'mode':'provider_settings_groups','portal':json.dumps(current_portal)})
    li_groups=xbmcgui.ListItem('[B]GRUPY I KANAŁY[/B]')
    li_groups.setArt({'icon':common.icon1,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_groups,listitem=li_groups,isFolder=True)

    url_recording=common.build_url({'mode':'provider_settings_recording','portal':json.dumps(current_portal)})
    li_recording=xbmcgui.ListItem('[B]NAGRYWANIE I POBIERANIE[/B]')
    li_recording.setArt({'icon':common.icon4,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_recording,listitem=li_recording,isFolder=True)

    url_tools=common.build_url({'mode':'provider_settings_tools','portal':json.dumps(current_portal)})
    li_tools=xbmcgui.ListItem('[B]NARZĘDZIA[/B]')
    li_tools.setArt({'icon':common.icon4,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_tools,listitem=li_tools,isFolder=True)

    xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True)

def RecordingSettingsLevel(portal):
    current_portal=common.get_provider_by_id(portal.get('id','')) or portal
    xbmcplugin.setContent(common.addon_handle,'files')

    recording_status=recorder.get_recording_status()
    if recording_status.get('active'):
        li_status=xbmcgui.ListItem(f'[B]Nagrywanie: [COLOR orange]{recording_status.get("label","ON")}[/COLOR][/B]')
        li_status.setArt({'icon':common.icon4,'fanart':common.fanart})
        xbmcplugin.addDirectoryItem(handle=common.addon_handle,url='',listitem=li_status,isFolder=False)

        url_info=common.build_url({'mode':'recording_info'})
        li_info=xbmcgui.ListItem('[B]Info o nagrywaniu[/B]')
        li_info.setArt({'icon':common.icon_info,'fanart':common.fanart})
        xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_info,listitem=li_info,isFolder=False)

        url_stop=common.build_url({'mode':'record_tv_stop'})
        li_stop=xbmcgui.ListItem('[B][COLOR red]Stop nagrywania[/COLOR][/B]')
        li_stop.setArt({'icon':common.icon4,'fanart':common.fanart})
        xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_stop,listitem=li_stop,isFolder=False)
    else:
        li_status=xbmcgui.ListItem('[B]Nagrywanie: [COLOR grey]OFF[/COLOR][/B]')
        li_status.setArt({'icon':common.icon4,'fanart':common.fanart})
        xbmcplugin.addDirectoryItem(handle=common.addon_handle,url='',listitem=li_status,isFolder=False)

    url_schedule=common.build_url({'mode':'record_schedule_manager'})
    li_schedule=xbmcgui.ListItem('[B]Programator nagrań[/B]')
    li_schedule.setArt({'icon':common.icon4,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_schedule,listitem=li_schedule,isFolder=True)

    url_media=common.build_url({'mode':'media_manager'})
    li_media=xbmcgui.ListItem('[B]Pobrane i nagrane[/B]')
    li_media.setArt({'icon':common.icon1,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_media,listitem=li_media,isFolder=True)

    url_export=common.build_url({'mode':'export_polish_m3u','portal':json.dumps(current_portal)})
    li_export=xbmcgui.ListItem('[B]Eksportuj Wszystkie Polskie do M3U[/B]')
    li_export.setArt({'icon':common.icon1,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_export,listitem=li_export,isFolder=False)

    xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True)

def ToolsSettingsLevel(portal):
    current_portal=common.get_provider_by_id(portal.get('id','')) or portal;provider_id=current_portal.get('id','')
    xbmcplugin.setContent(common.addon_handle,'files')

    url_keymap_install=common.build_url({'mode':'install_keymap'})
    li_keymap_install=xbmcgui.ListItem('[B]Skrót klawiszowy nast/poprz. kanał[/B]')
    li_keymap_install.setArt({'icon':common.icon4,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_keymap_install,listitem=li_keymap_install,isFolder=False)

    url_keymap_remove=common.build_url({'mode':'remove_keymap'})
    li_keymap_remove=xbmcgui.ListItem('[B]Usuń skrót klawiszowy[/B]')
    li_keymap_remove.setArt({'icon':common.icon4,'fanart':common.fanart})
    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_keymap_remove,listitem=li_keymap_remove,isFolder=False)

    url_cache=common.build_url({'mode':'cache','portal':json.dumps(current_portal)})
    li_cache=xbmcgui.ListItem('[B][COLOR red]SKASUJ CACHE[/COLOR][/B]');li_cache.setArt({'icon':common.icon4,'fanart':common.fanart});xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_cache,listitem=li_cache,isFolder=False)

    xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True)
