# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,json
from resources.lib import common

def set_portal_title(portal,section=''):
    try:
        portal_name=portal.get('name','IPTV');xbmcplugin.setPluginCategory(common.addon_handle,f"{portal_name} / {section}" if section else portal_name)
    except: pass

def SelectLevel(portal):
    set_portal_title(portal,'Menu');xbmcplugin.setContent(common.addon_handle,'files')
    url_dummy=common.build_url({'mode':'refresh_list'})
    li_sep=xbmcgui.ListItem('[B][COLOR red] <><>[/COLOR][COLOR red]---------------------------------------[/COLOR][COLOR red]<><>[/COLOR][/B]')
    li_sep.setArt({'icon':common.icon11,'fanart':common.fanart});xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_dummy,listitem=li_sep,isFolder=False)

    url_pl=common.build_url({'mode':'channels','custom_order':'true','filter_group':'ALL_POLISH','portal':json.dumps(portal),'genre_name':'Wszystkie Polskie'})
    li_pl=xbmcgui.ListItem('[B][COLOR deepskyblue] <><>[/COLOR] [COLOR lime]             POLSKA TV             [/COLOR] [COLOR deepskyblue]<><>[/COLOR][/B]')
    li_pl.setArt({'icon':common.icon1,'fanart':common.fanart});xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_pl,listitem=li_pl,isFolder=True)

    url_groups=common.build_url({'mode':'polish_groups_menu','portal':json.dumps(portal)})
    li_groups=xbmcgui.ListItem('[B][COLOR deepskyblue] <><>[/COLOR] [COLOR yellow]                 GRUPY                  [/COLOR] [COLOR deepskyblue]<><>[/COLOR][/B]')
    li_groups.setArt({'icon':common.icon4,'fanart':common.fanart});xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_groups,listitem=li_groups,isFolder=True)

    if portal.get('type')!='m3u':
        url_vod=common.build_url({'mode':'vodgen','portal':json.dumps(portal)})
        li_vod=xbmcgui.ListItem('[B][COLOR deepskyblue] <><>[/COLOR] [COLOR yellow]                 FILMY                   [/COLOR] [COLOR deepskyblue]<><>[/COLOR][/B]')
        li_vod.setArt({'icon':common.icon2,'fanart':common.fanart});xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_vod,listitem=li_vod,isFolder=True)

        url_ser=common.build_url({'mode':'sergen','portal':json.dumps(portal)})
        li_ser=xbmcgui.ListItem('[B][COLOR deepskyblue] <><>[/COLOR] [COLOR yellow]               SERIALE                 [/COLOR] [COLOR deepskyblue]<><>[/COLOR][/B]')
        li_ser.setArt({'icon':common.icon3,'fanart':common.fanart});xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_ser,listitem=li_ser,isFolder=True)

    
    if portal.get('type')=='m3u':
        url_raw=common.build_url({'mode':'channels','genre_id':'*','genre_name':'M3U','portal':json.dumps(portal)})
        li_raw=xbmcgui.ListItem('[B][COLOR deepskyblue] <><>[/COLOR] [COLOR yellow]                   M3U                     [/COLOR] [COLOR deepskyblue]<><>[/COLOR][/B]')
    else:
        url_raw=common.build_url({'mode':'my_groups_view','portal':json.dumps(portal)})
        li_raw=xbmcgui.ListItem('[B][COLOR deepskyblue] <><>[/COLOR] [COLOR yellow]         ZAGRANICZNA          [/COLOR] [COLOR deepskyblue]<><>[/COLOR][/B]')
    li_raw.setArt({'icon':common.icon1,'fanart':common.fanart});xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_raw,listitem=li_raw,isFolder=True)

    xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_dummy,listitem=li_sep,isFolder=False)

    url_search=common.build_url({'mode':'global_search'})
    li_search=xbmcgui.ListItem('[B][COLOR deepskyblue] <><>[/COLOR] [COLOR lime]                SZUKAJ                 [/COLOR] [COLOR deepskyblue]<><>[/COLOR][/B]')
    li_search.setArt({'icon':common.icon2,'fanart':common.fanart});xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_search,listitem=li_search,isFolder=True)

    url_guide=common.build_url({'mode':'tv_guide','custom_order':'true','filter_group':'ALL_POLISH','portal':json.dumps(portal),'genre_name':'Wszystkie Polskie'})
    li_guide=xbmcgui.ListItem('[B][COLOR deepskyblue] <><>[/COLOR] [COLOR orange]            PRZEWODNIK TV            [/COLOR] [COLOR deepskyblue]<><>[/COLOR][/B]')
    li_guide.setArt({'icon':common.icon4,'fanart':common.fanart});xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_guide,listitem=li_guide,isFolder=False)

    url_settings=common.build_url({'mode':'provider_settings','portal':json.dumps(portal)})
    li_settings=xbmcgui.ListItem('[B][COLOR deepskyblue] <><>[/COLOR] [COLOR orange]           USTAWIENIA            [/COLOR] [COLOR deepskyblue]<><>[/COLOR][/B]')
    li_settings.setArt({'icon':common.icon4,'fanart':common.fanart});xbmcplugin.addDirectoryItem(handle=common.addon_handle,url=url_settings,listitem=li_settings,isFolder=True)

    xbmcplugin.endOfDirectory(common.addon_handle,cacheToDisc=True)
