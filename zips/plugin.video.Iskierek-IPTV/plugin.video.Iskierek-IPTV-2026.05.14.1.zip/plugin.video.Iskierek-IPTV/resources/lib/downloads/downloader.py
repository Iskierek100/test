# -*- coding: utf-8 -*-
import os
import re
import urllib.request
import ssl
import xbmc
import xbmcgui
from resources.lib import common
from resources.lib.providers import provider_api


def safe_filename(name):
    if not name:
        return "plik"
    name = re.sub(r'[\\/:*?"<>|]+', '_', str(name))
    name = name.strip().strip('.')
    return name or "plik"


def choose_download_dir():
    default_dir = common.addon.getSetting('recordings_dir').strip()
    if default_dir and os.path.exists(default_dir):
        return default_dir

    path = xbmcgui.Dialog().browseSingle(
        0,
        'Wybierz folder docelowy',
        'files'
    )
    return path


def _open_url(url, start_byte=0):
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    headers = {'User-Agent': 'Mozilla/5.0'}
    if start_byte > 0:
        headers['Range'] = f'bytes={start_byte}-'

    req = urllib.request.Request(url, headers=headers)
    return urllib.request.urlopen(req, context=ctx, timeout=60)


def _download_file(url, output_path):
    temp_path = output_path + '.part'
    existing_size = 0

    if os.path.exists(temp_path):
        try:
            existing_size = os.path.getsize(temp_path)
        except:
            existing_size = 0

    dp = xbmcgui.DialogProgress()
    dp.create(common.addonname, f"Pobieranie:\n{os.path.basename(output_path)}")

    try:
        response = _open_url(url, existing_size)

        total_size = response.headers.get('Content-Length')
        try:
            total_size = int(total_size)
        except:
            total_size = 0

        content_range = response.headers.get('Content-Range')
        supports_resume = bool(content_range) or existing_size == 0

        if existing_size > 0 and not supports_resume:
            # serwer nie wspiera resume, zaczynamy od nowa
            try:
                os.remove(temp_path)
            except:
                pass
            existing_size = 0
            response = _open_url(url, 0)
            total_size = response.headers.get('Content-Length')
            try:
                total_size = int(total_size)
            except:
                total_size = 0

        mode = 'ab' if existing_size > 0 else 'wb'
        bytes_read = existing_size
        full_size = (existing_size + total_size) if total_size > 0 else 0
        chunk_size = 1024 * 512

        with open(temp_path, mode) as f:
            while True:
                if dp.iscanceled():
                    dp.close()
                    return False

                chunk = response.read(chunk_size)
                if not chunk:
                    break

                f.write(chunk)
                bytes_read += len(chunk)

                if full_size > 0:
                    percent = int((bytes_read * 100) / full_size)
                    mb_read = bytes_read / (1024 * 1024)
                    mb_total = full_size / (1024 * 1024)
                    dp.update(percent, f"Pobrano {mb_read:.1f} MB / {mb_total:.1f} MB")
                else:
                    mb_read = bytes_read / (1024 * 1024)
                    dp.update(0, f"Pobrano {mb_read:.1f} MB")

        if os.path.exists(output_path):
            os.remove(output_path)
        os.rename(temp_path, output_path)

        dp.close()
        return True

    except Exception as e:
        dp.close()
        raise e


def download_vod(portal):
    provider = provider_api.get_provider(portal)

    title = common.args.get('title', ['Film'])[0]
    cmd = common.args.get('cmd', [''])[0]
    ext = common.args.get('ext', ['mp4'])[0]

    download_dir = choose_download_dir()
    if not download_dir:
        return

    filename = safe_filename(title) + '.' + ext.lstrip('.')
    output_path = os.path.join(download_dir, filename)

    try:
        if portal.get('type') == 'xtream':
            stream_url = provider.getLinkVoD(portal, cmd, ext)
        elif portal.get('type') == 'm3u':
            stream_url = cmd
        else:
            stream_url = provider.getLinkVoD(portal['mac'], portal['url'], portal['serial'], cmd)

        if not stream_url:
            xbmcgui.Dialog().notification(common.addonname, "Nie udało się pobrać linku", xbmcgui.NOTIFICATION_ERROR)
            return

        ok = _download_file(stream_url, output_path)
        if ok:
            xbmcgui.Dialog().ok(common.addonname, f"Pobrano plik:\n{output_path}")

    except Exception as e:
        xbmcgui.Dialog().ok(common.addonname, f"Błąd pobierania filmu:\n{str(e)}")


def download_series(portal):
    provider = provider_api.get_provider(portal)

    title = common.args.get('title', ['Odcinek'])[0]
    cmd = common.args.get('cmd', [''])[0]
    ext = common.args.get('ext', ['mp4'])[0]
    episode = common.args.get('episode', ['1'])[0]

    download_dir = choose_download_dir()
    if not download_dir:
        return

    filename = safe_filename(title) + '.' + ext.lstrip('.')
    output_path = os.path.join(download_dir, filename)

    try:
        if portal.get('type') == 'xtream':
            stream_url = provider.getLinkSeries(portal, cmd, ext)
        elif portal.get('type') == 'm3u':
            stream_url = cmd
        else:
            stream_url = provider.getLinkSeries(portal['mac'], portal['url'], portal['serial'], cmd, episode)

        if not stream_url:
            xbmcgui.Dialog().notification(common.addonname, "Nie udało się pobrać linku", xbmcgui.NOTIFICATION_ERROR)
            return

        ok = _download_file(stream_url, output_path)
        if ok:
            xbmcgui.Dialog().ok(common.addonname, f"Pobrano plik:\n{output_path}")

    except Exception as e:
        xbmcgui.Dialog().ok(common.addonname, f"Błąd pobierania odcinka:\n{str(e)}")
