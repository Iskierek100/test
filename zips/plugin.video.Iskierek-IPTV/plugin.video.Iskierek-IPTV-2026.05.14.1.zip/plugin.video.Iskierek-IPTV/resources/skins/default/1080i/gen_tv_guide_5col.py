# -*- coding: utf-8 -*-

OUT_PATH = "/home/iskra/Flatpak/tv.kodi.Kodi/Kodi/addons/plugin.video.Iskierek-IPTV/resources/skins/default/1080i/tv_guide.xml"

ROWS = 8
EVENT_POOL = 12

WINDOW_W = 1920
WINDOW_H = 1080

CHANNEL_X = 35
CHANNEL_W = 300

GRID_X = 360
GRID_W = 1515

TOP_Y = 125
ROW_H = 102
CELL_H = 72
CELL_Y_PAD = 8

BOTTOM_Y = 750
BOTTOM_H = 250

HEADER_BAR_Y = 20
HEADER_BAR_H = 52

COLORS = {
    "bg": "FF191C1E",
    "frame": "1200FFAA",
    "panel": "22000000",
}


def ind(level, text):
    pad = "    " * level
    return "\n".join((pad + line if line.strip() else line) for line in text.splitlines())


def make_header():
    out = []

    out.append(f"""
<control type="label">
    <left>40</left>
    <top>26</top>
    <width>1540</width>
    <height>34</height>
    <font>font24_title</font>
    <textcolor>lime</textcolor>
    <align>center</align>
    <label>PRZEWODNIK TV</label>
</control>
""".strip())

    out.append(f"""
<control type="label" id="46">
    <left>1220</left>
    <top>30</top>
    <width>470</width>
    <height>24</height>
    <font>font12</font>
    <textcolor>white</textcolor>
    <align>right</align>
    <label>17.03.2026   08:00 - 12:00</label>
</control>
""".strip())

    out.append(f"""
<control type="button" id="31">
    <left>1710</left>
    <top>24</top>
    <width>70</width>
    <height>40</height>
    <font>font24_title</font>
    <textcolor>white</textcolor>
    <focusedcolor>black</focusedcolor>
    <align>center</align>
    <texturefocus colordiffuse="FF33CC33">colors/white.png</texturefocus>
    <texturenofocus colordiffuse="22000000">colors/white.png</texturenofocus>
    <label>◄</label>
</control>
""".strip())

    out.append(f"""
<control type="button" id="32">
    <left>1790</left>
    <top>24</top>
    <width>70</width>
    <height>40</height>
    <font>font24_title</font>
    <textcolor>white</textcolor>
    <focusedcolor>black</focusedcolor>
    <align>center</align>
    <texturefocus colordiffuse="FF33CC33">colors/white.png</texturefocus>
    <texturenofocus colordiffuse="22000000">colors/white.png</texturenofocus>
    <label>►</label>
</control>
""".strip())

    out.append(f"""
<control type="label">
    <left>{CHANNEL_X}</left>
    <top>82</top>
    <width>{CHANNEL_W}</width>
    <height>28</height>
    <font>font13</font>
    <textcolor>white</textcolor>
    <label>[B]KANAŁ[/B]</label>
</control>
""".strip())

    labels = ["TERAZ", "NASTĘPNY", "PÓŹNIEJ", "DALEJ", "DALEJ"]
    colors = ["yellow", "white", "grey", "grey", "grey"]

    col_w = GRID_W // 5
    for i in range(5):
        x = GRID_X + i * col_w
        out.append(f"""
<control type="label" id="{60+i}">
    <left>{x}</left>
    <top>82</top>
    <width>{col_w}</width>
    <height>28</height>
    <font>font13</font>
    <textcolor>{colors[i]}</textcolor>
    <align>center</align>
    <label>[B]{labels[i]}[/B]</label>
</control>
""".strip())

    return "\n\n".join(out)


def make_row(row):
    y = TOP_Y + row * ROW_H
    out = []

    out.append(f"""
<control type="button" id="{100 + row}">
    <left>{CHANNEL_X}</left>
    <top>{y + 6}</top>
    <width>{CHANNEL_W}</width>
    <height>84</height>
    <font>font13</font>
    <textcolor>white</textcolor>
    <focusedcolor>lime</focusedcolor>
    <aligny>center</aligny>
    <texturefocus colordiffuse="22000000">colors/white.png</texturefocus>
    <texturenofocus colordiffuse="00FFFFFF">colors/white.png</texturenofocus>
    <label>{row+1}. Kanał</label>
</control>
""".strip())

    out.append(f"""
<control type="image" id="{200 + row}">
    <left>{CHANNEL_X + 10}</left>
    <top>{y + 24}</top>
    <width>72</width>
    <height>38</height>
    <aspectratio>keep</aspectratio>
    <texture>DefaultVideo.png</texture>
</control>
""".strip())

    out.append(f"""
<control type="progress" id="{300 + row}">
    <left>{CHANNEL_X + 92}</left>
    <top>{y + 52}</top>
    <width>120</width>
    <height>10</height>
    <info>Window.Property(Guide.Row{row}.Progress)</info>
    <texturebg border="3">pvr/texturebg_border_white.png</texturebg>
    <midtexture colordiffuse="FF00CC00" border="3">pvr/texturebg_white.png</midtexture>
</control>
""".strip())

    out.append(f"""
<control type="image">
    <left>30</left>
    <top>{y + ROW_H - 1}</top>
    <width>1860</width>
    <height>1</height>
    <texture>separator_horizontal.png</texture>
    <colordiffuse>grey</colordiffuse>
</control>
""".strip())

    for i in range(EVENT_POOL):
        bg_id = 2000 + row * 100 + i
        btn_id = 1000 + row * 100 + i
        time_id = 3000 + row * 100 + i
        title_id = 4000 + row * 100 + i

        out.append(f"""
<control type="image" id="{bg_id}">
    <left>{GRID_X}</left>
    <top>{y + CELL_Y_PAD}</top>
    <width>40</width>
    <height>{CELL_H}</height>
    <texture colordiffuse="FF2B2B2B">colors/white.png</texture>
    <visible>false</visible>
</control>
""".strip())

        out.append(f"""
<control type="button" id="{btn_id}">
    <left>{GRID_X}</left>
    <top>{y + CELL_Y_PAD}</top>
    <width>40</width>
    <height>{CELL_H}</height>
    <font>font12</font>
    <textcolor>white</textcolor>
    <focusedcolor>white</focusedcolor>
    <textoffsetx>0</textoffsetx>
    <textoffsety>0</textoffsety>
    <align>left</align>
    <aligny>center</aligny>
    <texturefocus colordiffuse="00FFFFFF">colors/white.png</texturefocus>
    <texturenofocus colordiffuse="00FFFFFF">colors/white.png</texturenofocus>
    <label></label>
    <visible>false</visible>
</control>
""".strip())

        out.append(f"""
<control type="label" id="{time_id}">
    <left>{GRID_X + 10}</left>
    <top>{y + CELL_Y_PAD + 2}</top>
    <width>120</width>
    <height>20</height>
    <font>font10</font>
    <textcolor>yellow</textcolor>
    <label>00:00-00:00</label>
    <visible>false</visible>
</control>
""".strip())

        out.append(f"""
<control type="textbox" id="{title_id}">
    <left>{GRID_X + 10}</left>
    <top>{y + CELL_Y_PAD + 24}</top>
    <width>120</width>
    <height>38</height>
    <font>font12</font>
    <textcolor>white</textcolor>
    <label>Tytuł</label>
    <autoscroll>false</autoscroll>
    <visible>false</visible>
</control>
""".strip())

    return "\n\n".join(out)


def build_xml():
    header_block = make_header()
    rows_block = "\n\n".join(make_row(r) for r in range(ROWS))

    xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<window type="dialog">
    <defaultcontrol always="true">1000</defaultcontrol>
    <controls>
        <control type="group">
            <animation effect="fade" start="0" end="100" time="180">WindowOpen</animation>
            <animation effect="fade" start="100" end="0" time="180">WindowClose</animation>

            <left>0</left>
            <top>0</top>

            <control type="image">
                <left>0</left>
                <top>0</top>
                <width>{WINDOW_W}</width>
                <height>{WINDOW_H}</height>
                <texture colordiffuse="{COLORS["bg"]}">colors/white.png</texture>
            </control>

            <control type="image">
                <left>18</left>
                <top>14</top>
                <width>1884</width>
                <height>1048</height>
                <texture colordiffuse="{COLORS["frame"]}">colors/white.png</texture>
            </control>

            <control type="image">
                <left>30</left>
                <top>{HEADER_BAR_Y}</top>
                <width>1860</width>
                <height>{HEADER_BAR_H}</height>
                <texture colordiffuse="18000000">colors/white.png</texture>
            </control>

{ind(3, header_block)}

            <control type="image">
                <left>24</left>
                <top>116</top>
                <width>1872</width>
                <height>1</height>
                <texture>separator_horizontal.png</texture>
                <colordiffuse>grey</colordiffuse>
            </control>

{ind(3, rows_block)}

            <control type="image">
                <left>30</left>
                <top>{BOTTOM_Y}</top>
                <width>1860</width>
                <height>{BOTTOM_H}</height>
                <texture colordiffuse="22000000">colors/white.png</texture>
            </control>

            <control type="image">
                <left>30</left>
                <top>{BOTTOM_Y}</top>
                <width>1860</width>
                <height>1</height>
                <texture>separator_horizontal.png</texture>
                <colordiffuse>grey</colordiffuse>
            </control>

            <control type="label" id="40">
                <left>50</left>
                <top>778</top>
                <width>760</width>
                <height>28</height>
                <font>font13</font>
                <textcolor>lime</textcolor>
                <label>Kanał</label>
            </control>

            <control type="label" id="41">
                <left>50</left>
                <top>812</top>
                <width>760</width>
                <height>24</height>
                <font>font12</font>
                <textcolor>yellow</textcolor>
                <label>Data / godzina</label>
            </control>

            <control type="label" id="42">
                <left>50</left>
                <top>846</top>
                <width>1020</width>
                <height>34</height>
                <font>font14_bold</font>
                <textcolor>white</textcolor>
                <label>Tytuł programu</label>
            </control>

            <control type="label" id="43">
                <left>50</left>
                <top>884</top>
                <width>1020</width>
                <height>24</height>
                <font>font12</font>
                <textcolor>orange</textcolor>
                <label>Następny program</label>
            </control>

            <control type="textbox" id="44">
                <left>50</left>
                <top>920</top>
                <width>1020</width>
                <height>72</height>
                <font>font12</font>
                <textcolor>white</textcolor>
                <label>Opis programu</label>
                <autoscroll>false</autoscroll>
            </control>

            <control type="image" id="45">
                <left>1110</left>
                <top>770</top>
                <width>310</width>
                <height>180</height>
                <aspectratio>scale</aspectratio>
                <texture>DefaultVideo.png</texture>
            </control>

            <control type="image">
                <left>1450</left>
                <top>770</top>
                <width>400</width>
                <height>180</height>
                <texture colordiffuse="15000000">colors/white.png</texture>
            </control>

            <control type="button" id="51">
                <left>1470</left>
                <top>780</top>
                <width>360</width>
                <height>38</height>
                <font>font13</font>
                <textcolor>white</textcolor>
                <focusedcolor>black</focusedcolor>
                <align>center</align>
                <texturefocus colordiffuse="FF33CC33">colors/white.png</texturefocus>
                <texturenofocus colordiffuse="33000000">colors/white.png</texturenofocus>
                <label>Odtwórz kanał</label>
            </control>

            <control type="button" id="52">
                <left>1470</left>
                <top>828</top>
                <width>360</width>
                <height>38</height>
                <font>font13</font>
                <textcolor>white</textcolor>
                <focusedcolor>black</focusedcolor>
                <align>center</align>
                <texturefocus colordiffuse="FF33CC33">colors/white.png</texturefocus>
                <texturenofocus colordiffuse="33000000">colors/white.png</texturenofocus>
                <label>Info o nagrywaniu</label>
            </control>

            <control type="button" id="53">
                <left>1470</left>
                <top>876</top>
                <width>360</width>
                <height>38</height>
                <font>font13</font>
                <textcolor>white</textcolor>
                <focusedcolor>black</focusedcolor>
                <align>center</align>
                <texturefocus colordiffuse="FF33CC33">colors/white.png</texturefocus>
                <texturenofocus colordiffuse="33000000">colors/white.png</texturenofocus>
                <label>Programator nagrań</label>
            </control>

            <control type="button" id="54">
                <left>1470</left>
                <top>924</top>
                <width>360</width>
                <height>38</height>
                <font>font13</font>
                <textcolor>white</textcolor>
                <focusedcolor>black</focusedcolor>
                <align>center</align>
                <texturefocus colordiffuse="FF33CC33">colors/white.png</texturefocus>
                <texturenofocus colordiffuse="33000000">colors/white.png</texturenofocus>
                <label>Ustawienia</label>
            </control>

            <control type="label">
                <left>40</left>
                <top>1030</top>
                <width>1840</width>
                <height>28</height>
                <font>font10</font>
                <textcolor>grey</textcolor>
                <align>center</align>
                <label>Najazd myszą = szczegóły na dole  |  Klik kanału = odtwarzanie  |  Klik programu = timer / nagrywanie  |  Lewo/Prawo = przesuw czasu</label>
            </control>
        </control>
    </controls>
</window>
"""
    return xml


if __name__ == "__main__":
    xml = build_xml()
    with open(OUT_PATH, "w", encoding="utf-8") as f:
        f.write(xml)
    print(f"Zapisano: {OUT_PATH}")
